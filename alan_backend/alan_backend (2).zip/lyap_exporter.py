#!/usr/bin/env python3
"""
Lyapunov Exponent Exporter for EigenSentry Integration
Serializes spectral stability data for real-time monitoring
"""

import json
import time
import numpy as np
from pathlib import Path
from typing import Dict, Any, Optional
import logging

import sys
sys.path.append(str(Path(__file__).parent.parent))

from python.core.bdg_solver import (
    assemble_bdg, compute_spectrum, extract_lyapunov_exponents
)

logger = logging.getLogger(__name__)

class LyapunovExporter:
    """Export Lyapunov spectrum for real-time monitoring"""
    
    def __init__(self, export_path: str = "lyapunov_watchlist.json"):
        self.export_path = Path(export_path)
        self.history = []
        self.update_count = 0
        
    def update_spectrum(self, soliton_state: np.ndarray, 
                       params: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
        """
        Compute and export Lyapunov spectrum
        
        Args:
            soliton_state: Current dark soliton field (2D array)
            params: Physics parameters (g, dx, etc.)
        """
        params = params or {'g': 1.0, 'dx': 1.0}
        
        # Build BdG operator
        H_BdG = assemble_bdg(soliton_state, **params)
        
        # Compute spectrum
        eigenvalues, _ = compute_spectrum(H_BdG, k=16)
        lyapunov = extract_lyapunov_exponents(eigenvalues)
        
        # Prepare export data
        export_data = {
            'timestamp': time.time(),
            'update_count': self.update_count,
            'lambda_max': float(np.max(lyapunov)),
            'lambda_min': float(np.min(lyapunov)),
            'spectrum': [float(l) for l in lyapunov],
            'unstable_count': int(np.sum(lyapunov > 0)),
            'params': params
        }
        
        # Add to history
        self.history.append(export_data)
        self.update_count += 1
        
        # Export to JSON
        self._export_json(export_data)
        
        return export_data
        
    def _export_json(self, data: Dict[str, Any]):
        """Export to JSON file"""
        try:
            with open(self.export_path, 'w') as f:
                json.dump(data, f, indent=2)
            logger.debug(f"Exported Lyapunov spectrum to {self.export_path}")
        except Exception as e:
            logger.error(f"Failed to export Lyapunov data: {e}")
            
    def get_stability_metrics(self) -> Dict[str, float]:
        """Get current stability metrics"""
        if not self.history:
            return {'lambda_max': 0.0, 'stable': True}
            
        latest = self.history[-1]
        return {
            'lambda_max': latest['lambda_max'],
            'unstable_modes': latest['unstable_count'],
            'stable': latest['lambda_max'] <= 0,
            'timestamp': latest['timestamp']
        }
