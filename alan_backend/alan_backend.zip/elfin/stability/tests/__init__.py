"""
Test module for the ELFIN stability framework.

This module contains tests for the neural Lyapunov training and certification
components of the ELFIN stability framework.
"""
