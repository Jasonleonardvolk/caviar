"""
Tests for the ELFIN Language Server.
"""
