"""
pipeline/pipeline.py

Main pipeline orchestration for PDF ingestion.
Coordinates all modules for complete processing flow.
"""

# Standard library imports - must come first
import asyncio
import atexit
import contextvars
import json
import logging
import os
import sys
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Callable, Any, Union

# ------------------------------------------------------------------
# logging (must precede any references to `logger`)
# ------------------------------------------------------------------
# Configure logging level from environment
log_level = os.environ.get('LOG_LEVEL', 'INFO').upper()
if log_level not in ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']:
    log_level = 'INFO'

# Use hierarchical logger name for better organization
logger = logging.getLogger("tori.ingest_pdf.pipeline")

# Prevent duplicate handlers and propagation issues
if not logger.hasHandlers():
    _h = logging.StreamHandler(stream=sys.stdout)
    _h.setFormatter(logging.Formatter(
        "%(asctime)s | %(name)-30s | %(levelname)-8s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"))
    logger.addHandler(_h)
    logger.setLevel(getattr(logging, log_level))
    # Prevent propagation to avoid duplicate logs
    logger.propagate = False

# Configurable emoji logging (disable for production log collectors)
ENABLE_EMOJI_LOGS = os.environ.get('ENABLE_EMOJI_LOGS', 'false').lower() == 'true'  # Default OFF for production

# Configurable size limits from environment
MAX_PDF_SIZE_MB = int(os.environ.get('MAX_PDF_SIZE_MB', '100'))
MAX_UNCOMPRESSED_SIZE_MB = int(os.environ.get('MAX_UNCOMPRESSED_SIZE_MB', '500'))
MAX_PDF_PAGES = int(os.environ.get('MAX_PDF_PAGES', '5000'))

# Additional imports have been moved to the top of the file

# Third-party imports
import PyPDF2

# Local imports - Type definitions
from .type_definitions import (
    PdfMetadata, ConceptDict, IngestResponse, ErrorResponse,
    ChunkDict, ExtractionParams, ConceptList, ChunkList,
    ProgressCallback, SafetyCheckResult
)

# Local imports - Utilities
from .utils import (
    safe_num, safe_divide, safe_percentage,
    safe_round, safe_get, sanitize_dict
)

# Local imports - Core modules
from .concurrency_manager import (
    ConcurrencyManager, ConcurrencyConfig, get_concurrency_manager,
    run_cpu_bound, run_io_bound
)
from .error_handling import (
    PipelineError, IOError as PipelineIOError, PDFParseError, ExtractionError,
    ValidationError, ConfigurationError, ErrorContext,
    ErrorResponseBuilder, with_retry, ErrorSeverity
)
from .execution_helpers import run_sync
from .optimized_io import hash_file_cached

# Try to import tqdm for better progress display
try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False

# Progress tracking utilities
class ProgressTracker:
    """Thread-safe progress tracker with percentage and time-based throttling.
    
    Prevents log spam by only reporting when:
    1. Percentage change exceeds min_change
    2. Time since last report exceeds min_seconds
    
    Optionally uses tqdm for better CLI display if available.
    """
    
    def __init__(self, total: int, min_change: float = 1.0, min_seconds: float = 0.0,
                 description: str = "Progress", use_tqdm: bool = None):
        self.total = total
        self.current = 0
        self.last_reported_pct = -1
        self.last_reported_time = 0.0
        self.min_change = min_change  # Minimum % change to report
        self.min_seconds = min_seconds  # Minimum seconds between reports
        self.description = description
        
        # Use RLock for thread safety (works in both sync and async contexts)
        self._lock = threading.RLock()
        
        # Determine if we should use tqdm
        if use_tqdm is None:
            # Auto-detect: use tqdm if available and we're in a TTY
            self.use_tqdm = TQDM_AVAILABLE and sys.stdout.isatty()
        else:
            self.use_tqdm = use_tqdm and TQDM_AVAILABLE
            
        # Initialize tqdm if using it
        self.tqdm_bar = None
        if self.use_tqdm:
            self.tqdm_bar = tqdm(total=total, desc=description, unit="items")
    
    def update(self, increment: int = 1) -> Optional[float]:
        """Update progress (thread-safe, works in both sync and async contexts)"""
        with self._lock:
            return self._update_internal(increment)
    
    # Alias for backward compatibility
    update_sync = update
    
    async def update_async(self, increment: int = 1) -> Optional[float]:
        """Async-compatible update (just calls sync version since we use threading.RLock)"""
        return self.update(increment)
    
    def _update_internal(self, increment: int) -> Optional[float]:
        """Internal update logic (not thread-safe, must be called with lock)"""
        self.current += increment
        if self.total <= 0:
            return None
            
        pct = (self.current / self.total) * 100
        current_time = time.time()
        
        # Update tqdm if using it
        if self.tqdm_bar and increment > 0:
            self.tqdm_bar.update(increment)
        
        # Check both percentage and time thresholds for logging
        pct_change_ok = abs(pct - self.last_reported_pct) >= self.min_change
        time_change_ok = (current_time - self.last_reported_time) >= self.min_seconds
        
        # Only report if both conditions are met (or if min_seconds is 0)
        if pct_change_ok and (self.min_seconds == 0 or time_change_ok):
            self.last_reported_pct = pct
            self.last_reported_time = current_time
            
            # Log if not using tqdm (to avoid duplicate output)
            if not self.tqdm_bar:
                logger.info(f"{self.description}: {pct:.0f}%")
            
            return pct
        return None
    
    def set_description(self, desc: str):
        """Update the progress description"""
        self.description = desc
        if self.tqdm_bar:
            self.tqdm_bar.set_description(desc)
    
    def get_state(self) -> Dict[str, Any]:
        """Get current progress state (useful for polling)"""
        with self._lock:
            pct = (self.current / self.total * 100) if self.total > 0 else 0
            return {
                "current": self.current,
                "total": self.total,
                "percentage": round(pct, 1),
                "is_complete": self.current >= self.total,
                "last_reported_pct": round(self.last_reported_pct, 1) if self.last_reported_pct >= 0 else None,
                "description": self.description
            }
    
    def close(self):
        """Close the progress tracker (important for tqdm)"""
        if self.tqdm_bar:
            self.tqdm_bar.close()
    
    def __enter__(self):
        """Context manager entry"""
        if pct := self.update(0):
            if not self.tqdm_bar:
                logger.info(f"{self.description} started: {pct:.0f}%")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        if self.current >= self.total:
            self.last_reported_pct = -1  # Force report
            if pct := self.update(0):
                if not self.tqdm_bar:
                    logger.info(f"{self.description} complete: {pct:.0f}%")
        self.close()
    
    # Async context manager support
    async def __aenter__(self):
        """Async context manager entry"""
        return self.__enter__()
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        return self.__exit__(exc_type, exc_val, exc_tb)


# === Context-local concept DB ===
_current_db = contextvars.ContextVar("concept_db")

@dataclass
class ConceptDB:
    storage: List[Dict] = field(default_factory=list)
    scores: Dict[str, float] = field(default_factory=dict)
    names: List[str] = field(default_factory=list)
    
    @lru_cache(maxsize=1024)
    def _search_concepts_cached(self, chunk_text_lower: str, max_results: int = 25) -> Tuple[Tuple[str, float], ...]:
        """Cached concept search for repeated queries."""
        results = []
        
        for concept in self.storage[:300]:  # Limit for performance
            if len(results) >= max_results:
                break
            
            name = concept.get("name", "")
            if len(name) < 4:
                continue
            
            if name.lower() in chunk_text_lower:
                base_score = self.scores.get(name, 0.5)
                boost = concept.get("boost_multiplier", 1.2)
                score = min(0.98, base_score * boost)
                results.append((name, score))
        
        return tuple(results)  # Tuple for hashability

    def __hash__(self):
        """Make ConceptDB hashable using its content"""
        # Use the length of storage as a simple hash
        # Since ConceptDB is context-local, this should be unique enough
        return hash((len(self.storage), len(self.names)))
    
    def __eq__(self, other):
        """Equality comparison for ConceptDB"""
        if not isinstance(other, ConceptDB):
            return False
        # Compare by content length (since full comparison would be expensive)
        return (len(self.storage) == len(other.storage) and 
                len(self.names) == len(other.names))


    def search_concepts(self, chunk_text: str, max_results: int = 25) -> List[Dict]:
        """Thread-safe concept search with caching"""
        chunk_lower = chunk_text.lower()
        cached_results = self._search_concepts_cached(chunk_lower, max_results)
        
        return [
            {
                "name": name,
                "score": score,
                "method": "file_storage_boosted",
                "source": {"file_storage_matched": True},
                "metadata": {"category": "general"}
            }
            for name, score in cached_results
        ]

def get_db() -> ConceptDB:
    try:
        return _current_db.get()
    except LookupError:
        # Load concepts from files on first access
        db = _load_concept_database()
        _current_db.set(db)
        return db


# === Concept Database Path Resolution ===
def find_concept_data_files() -> Optional[Tuple[Path, Path]]:
    """Find concept database files using multiple strategies.
    
    Returns:
        Tuple of (main_concepts_path, universal_seeds_path) if found, None otherwise
    """
    # Strategy 1: Try importlib.resources first (Python 3.9+)
    try:
        import importlib.resources as resources
        data_dir = resources.files('ingest_pdf.data')
        concept_file = data_dir / 'concept_file_storage.json'
        seed_file = data_dir / 'concept_seed_universal.json'
        
        # Check if files exist by trying to read them
        try:
            concept_file.read_text(encoding='utf-8')
            seed_file.read_text(encoding='utf-8')
            logger.debug("Found concept files via importlib.resources")
            return (concept_file, seed_file)
        except Exception:
            pass
    except (ImportError, AttributeError, ModuleNotFoundError):
        pass
    
    # Strategy 2: Try namespace package
    try:
        import importlib
        pkg_name = __package__.split('.')[0] if __package__ else 'ingest_pdf'
        pkg = importlib.import_module(pkg_name)
        data_path = Path(pkg.__file__).parent / 'data'
        
        concept_path = data_path / "concept_file_storage.json"
        seed_path = data_path / "concept_seed_universal.json"
        
        if concept_path.exists() and seed_path.exists():
            logger.debug(f"Found concept files via namespace package at {data_path}")
            return (concept_path, seed_path)
    except Exception:
        pass
    
    # Strategy 3: Relative path fallback
    for base in [Path(__file__).resolve().parent.parent, Path(__file__).resolve().parent]:
        data_path = base / "data"
        concept_path = data_path / "concept_file_storage.json"
        seed_path = data_path / "concept_seed_universal.json"
        
        if concept_path.exists():
            logger.debug(f"Found concept files via relative path at {data_path}")
            return (concept_path, seed_path)
    
    return None


def load_json_file(file_path: Path, description: str) -> List[Dict]:
    """Load JSON file with consistent error handling.
    
    Args:
        file_path: Path to JSON file
        description: Description for logging
        
    Returns:
        List of loaded items, empty list on error
    """
    try:
        # Handle both Path objects and importlib.resources paths
        if hasattr(file_path, 'read_text'):
            content = file_path.read_text(encoding='utf-8')
        else:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        
        data = json.loads(content)
        logger.info(f"Loaded {len(data)} {description}")
        return data
    except Exception as e:
        logger.warning(f"Failed to load {description} from {file_path}: {e}")
        return []


@lru_cache(maxsize=1)
def _load_concept_database() -> ConceptDB:
    """Load concept database with centralized path resolution and caching."""
    logger.info("Loading concept database...")
    start_time = time.time()
    
    # Find data files
    file_paths = find_concept_data_files()
    
    if not file_paths:
        logger.error(
            "Failed to find concept database files! "
            "Concept extraction will be limited. "
            "Expected locations:\n"
            "1. Python package: ingest_pdf.data/\n"
            "2. Relative to module: ../data/ or ./data/\n"
            "Please ensure concept_file_storage.json and concept_seed_universal.json exist."
        )
        return ConceptDB(storage=[], scores={}, names=[])
    
    concept_path, seed_path = file_paths
    
    # Load main concepts
    all_concepts = load_json_file(concept_path, "main concepts")
    
    # Load and merge universal seeds if available
    if seed_path and (seed_path.exists() if hasattr(seed_path, 'exists') else True):
        seeds = load_json_file(seed_path, "universal seed concepts")
        
        # Merge unique seeds
        if seeds and all_concepts:
            existing = {c["name"].lower() for c in all_concepts}
            new_seeds = [s for s in seeds if s["name"].lower() not in existing]
            all_concepts.extend(new_seeds)
            if new_seeds:
                logger.info(f"Added {len(new_seeds)} unique seed concepts")
    
    # Build ConceptDB
    names = [c["name"] for c in all_concepts]
    scores = {c["name"]: c.get("priority", 0.5) for c in all_concepts}
    
    elapsed = time.time() - start_time
    logger.info(f"Concept database loaded: {len(all_concepts)} total concepts in {elapsed:.2f}s")
    
    if ENABLE_EMOJI_LOGS:
        logger.info(f"✅ Concept database ready with {len(all_concepts)} concepts")
    
    return ConceptDB(storage=all_concepts, scores=scores, names=names)


def preload_concept_database():
    """Preload concept database to avoid cold-start latency.
    
    Call this during application startup to load concepts in the background:
    
    # Sync startup
    preload_concept_database()
    
    # Async startup (non-blocking)
    await asyncio.to_thread(preload_concept_database)
    
    # FastAPI startup event
    @app.on_event("startup")
    async def startup_event():
        await asyncio.to_thread(preload_concept_database)
    """
    logger.info("Preloading concept database...")
    start_time = time.time()
    
    # Force load
    db = get_db()
    
    elapsed = time.time() - start_time
    logger.info(f"Concept database preloaded: {len(db.storage)} concepts in {elapsed:.2f}s")
    
    return db


async def preload_concept_database_async():
    """Async version of preload_concept_database for non-blocking startup."""
    return await asyncio.to_thread(preload_concept_database)

# Thread-local storage for concept tracking
_thread_local_frequency = contextvars.ContextVar('frequency_counter', default=None)

# === Thread-safe frequency tracking ===
def track_concept_frequency(name: str):
    """Thread-safe frequency tracking using contextvars"""
    freq_counter = _thread_local_frequency.get() or {}
    freq_counter[name] = freq_counter.get(name, 0) + 1
    _thread_local_frequency.set(freq_counter)

def get_concept_frequency(name: str) -> Dict[str, int]:
    """Get frequency from thread-local storage"""
    freq_counter = _thread_local_frequency.get()
    if freq_counter is None:
        return {"count": 0}
    return {"count": freq_counter.get(name, 0)}

def reset_frequency_counter():
    """Reset thread-local frequency counter"""
    _thread_local_frequency.set({})

# Local imports
from .config import (
    ENABLE_CONTEXT_EXTRACTION, ENABLE_FREQUENCY_TRACKING, 
    ENABLE_ENTROPY_PRUNING, ENABLE_ENHANCED_MEMORY_STORAGE,
    ENABLE_PARALLEL_PROCESSING, FILE_SIZE_LIMITS, MAX_PARALLEL_WORKERS,
    ENTROPY_CONFIG, ENABLE_OCR_FALLBACK, SECTION_WEIGHTS
)

# Import IO module
from .io import (
    extract_pdf_metadata as _extract_pdf_metadata_original,
    preprocess_with_ocr, extract_chunks,
    extract_title_abstract_safe, detect_section_type
)

# Import quality module
from .quality import (
    analyze_concept_purity as _analyze_concept_purity_original,
    extract_and_boost_concepts as _extract_and_boost_concepts_original
)

from .pruning import apply_entropy_pruning
from .enhanced_pruning import create_enhanced_pruner, DocumentType, create_prune_visualization
from .storage import inject_concept_diff

# === Extract PDF metadata with optimized caching ===
@with_retry(max_retries=3, delay=0.5, recoverable_errors=[PipelineIOError])
def extract_pdf_metadata(pdf_path: str, sample_pages: bool = False) -> PdfMetadata:
    """Extract metadata with optimized caching for SHA-256.
    
    Args:
        pdf_path: Path to the PDF file
        sample_pages: If True, sample pages to estimate uncompressed size more accurately
        
    Returns:
        PdfMetadata dictionary containing file metadata
        
    Raises:
        PipelineIOError: If file cannot be read
        PDFParseError: If PDF is corrupted
    """
    metadata: PdfMetadata = {
        "filename": Path(pdf_path).name,
        "file_path": str(pdf_path),
        "extraction_timestamp": datetime.now().isoformat(),
        "extractor_version": "tori_production",
        "file_size_bytes": 0,
        "sha256": "unknown",
        "file_size_mb": 0.0,
        "page_count": 1,
        "estimated_uncompressed_mb": 0.5,
        "pdf_metadata": None,
        "ocr_used": None
    }
    
    try:
        # Use cached hash function for SHA-256
        sha256_hash = hash_file_cached(pdf_path)
        
        # Get file size
        file_size = Path(pdf_path).stat().st_size
        
        metadata.update({
            "file_size_bytes": file_size,
            "sha256": sha256_hash
        })
    except FileNotFoundError:
        raise PipelineIOError(f"PDF file not found: {pdf_path}", path=pdf_path, recoverable=False)
    except PermissionError:
        raise PipelineIOError(f"Permission denied reading: {pdf_path}", path=pdf_path, recoverable=False)
    except OSError as e:
        raise PipelineIOError(f"OS error reading file: {e}", path=pdf_path, recoverable=True)
    except Exception as e:
        logger.warning(f"Unexpected error extracting file info: {e}")
        # Keep defaults
    
    # Extract additional PDF metadata
    if pdf_path.lower().endswith('.pdf'):
        try:
            with open(pdf_path, "rb") as f:
                pdf = PyPDF2.PdfReader(f)
                
                # Extract PDF metadata
                if pdf.metadata:
                    metadata["pdf_metadata"] = {
                        k.lower().replace('/', ''): str(v)
                        for k, v in pdf.metadata.items() if k and v
                    }
                
                page_count = len(pdf.pages)
                metadata["page_count"] = page_count
                
                # Estimate uncompressed size
                if sample_pages and page_count > 0:
                    # Sample up to 5 pages evenly distributed
                    sample_size = min(5, page_count)
                    sample_indices = [
                        int(i * (page_count - 1) / (sample_size - 1)) 
                        for i in range(sample_size)
                    ] if sample_size > 1 else [0]
                    
                    total_sample_size = 0
                    for idx in sample_indices:
                        try:
                            page = pdf.pages[idx]
                            # Get text length as rough estimate
                            text = page.extract_text() or ""
                            # Estimate: text + ~20% overhead for formatting/images
                            total_sample_size += len(text.encode('utf-8')) * 1.2
                        except Exception as e:
                            logger.debug(f"Failed to extract text from page {idx}: {e}")
                            # If extraction fails, use default estimate
                            total_sample_size += 512 * 1024  # 512KB default
                    
                    # Average size per page from samples
                    avg_page_size = total_sample_size / len(sample_indices)
                    metadata["estimated_uncompressed_mb"] = round(
                        (avg_page_size * page_count) / (1024 * 1024), 2
                    )
                else:
                    # Use heuristic: 0.5MB per page
                    metadata["estimated_uncompressed_mb"] = round(page_count * 0.5, 2)
                    
        except PyPDF2.errors.PdfReadError as e:
            raise PDFParseError(f"Invalid or corrupted PDF: {e}", recoverable=False)
        except Exception as e:
            logger.warning(f"Could not extract PDF metadata: {e}")
            # Keep defaults
    
    metadata["file_size_mb"] = round(metadata["file_size_bytes"] / (1024 * 1024), 2)
    
    return metadata

# === PDF Safety Checks with better estimates ===
def check_pdf_safety(pdf_path: str, sample_for_size: bool = True) -> Tuple[bool, str, PdfMetadata]:
    """Check PDF for size limits and potential issues.
    
    Args:
        pdf_path: Path to the PDF file
        sample_for_size: If True, sample pages for better size estimation
        
    Returns:
        Tuple of (is_safe, message, metadata)
    """
    # Get metadata with optimized extraction
    metadata = extract_pdf_metadata(pdf_path, sample_pages=sample_for_size)
    file_size_mb = metadata.get("file_size_mb", 0)
    
    if file_size_mb > MAX_PDF_SIZE_MB:
        return False, f"PDF too large: {file_size_mb:.1f}MB > {MAX_PDF_SIZE_MB}MB limit", metadata
    
    # Check estimated uncompressed size
    est_uncompressed = metadata.get("estimated_uncompressed_mb", 0)
    if est_uncompressed > MAX_UNCOMPRESSED_SIZE_MB:
        return False, f"PDF potentially too large when extracted: ~{est_uncompressed:.0f}MB", metadata
    
    # Additional safety checks
    page_count = metadata.get("page_count", 0)
    if page_count > MAX_PDF_PAGES:
        return False, f"PDF has too many pages: {page_count} > {MAX_PDF_PAGES} limit", metadata
    
    return True, "OK", metadata

# === Extract and boost concepts with thread-safe database ===
def extract_and_boost_concepts(chunk: str, threshold: float = 0.0, 
                              chunk_index: int = 0, chunk_section: str = "body", 
                              title_text: str = "", abstract_text: str = "") -> ConceptList:
    """Extract and boost with thread-safe concept database.
    
    Args:
        chunk: Text chunk to process
        threshold: Minimum score threshold
        chunk_index: Index of the chunk
        chunk_section: Section type (title, abstract, body, etc.)
        title_text: Document title for context
        abstract_text: Document abstract for context
        
    Returns:
        List of extracted concepts
    """
    # Use the original function but with thread-safe boosting
    concepts = _extract_and_boost_concepts_original(
        chunk, threshold, chunk_index, chunk_section, title_text, abstract_text
    )
    
    # Add thread-safe database boosting
    db = get_db()
    boosted = db.search_concepts(chunk)
    
    # Combine and track frequency
    all_concepts = concepts + boosted
    for concept in all_concepts:
        name = concept.get('name', '')
        if name:
            track_concept_frequency(name)
            
            # Ensure metadata exists
            if 'metadata' not in concept:
                concept['metadata'] = {}
            
            # Add frequency data
            freq_data = get_concept_frequency(name)
            concept['metadata']['frequency'] = freq_data['count']
    
    return all_concepts

# === Analyze concept purity with quality scoring ===
def analyze_concept_purity(all_concepts: ConceptList, doc_name: str = "", 
                          title_text: str = "", abstract_text: str = "", 
                          doc_context: Optional[Dict] = None) -> ConceptList:
    """Analyze concept purity with quality scoring.
    
    Args:
        all_concepts: All extracted concepts
        doc_name: Document name
        title_text: Document title
        abstract_text: Document abstract
        doc_context: Additional document context
        
    Returns:
        List of pure concepts with quality scores
    """
    # Use original purity analysis
    pure_concepts = _analyze_concept_purity_original(
        all_concepts, doc_name, title_text, abstract_text, doc_context
    )
    
    # Add quality scoring
    for concept in pure_concepts:
        # Calculate enhanced quality score
        score = safe_num(concept.get('score', 0.5))
        metadata = concept.get('metadata', {})
        frequency = metadata.get('frequency', 1)
        in_title = metadata.get('in_title', False)
        in_abstract = metadata.get('in_abstract', False)
        section = metadata.get('section', 'body')
        
        # Use configurable section weights
        
        # Calculate quality
        quality = score * SECTION_WEIGHTS.get(section, 1.0)
        quality *= (1 + min(frequency, 5) * 0.1)  # Frequency boost, capped
        quality *= (1.3 if in_title else 1.0)
        quality *= (1.2 if in_abstract else 1.0)
        
        concept['quality_score'] = min(quality, 1.0)
    
    # Sort by quality score
    pure_concepts.sort(key=lambda x: safe_num(x.get('quality_score', x.get('score', 0))), reverse=True)
    
    return pure_concepts

# === Memory storage functions ===
async def store_concepts_in_soliton(concepts: ConceptList, doc_metadata: PdfMetadata) -> None:
    """Store concepts with relationship mapping.
    
    Args:
        concepts: List of concepts to store
        doc_metadata: Document metadata
        
    Returns:
        None
    """
    try:
        from .storage import store_concepts_in_soliton as _store_original
        await _store_original(concepts, doc_metadata)
    except ImportError:
        logger.warning("Memory storage module not available")

def store_concepts_sync(concepts: ConceptList, meta: PdfMetadata) -> None:
    """Sync wrapper for async store_concepts_in_soliton.
    
    Args:
        concepts: List of concepts to store
        meta: Document metadata
        
    Returns:
        None
    """
    return run_sync(store_concepts_in_soliton(concepts, meta))

@lru_cache(maxsize=128)
def get_dynamic_limits(file_size_mb: float) -> Tuple[int, int]:
    """
    Get dynamic processing limits based on file size.
    
    Args:
        file_size_mb: File size in megabytes
        
    Returns:
        Tuple of (max_chunks, max_concepts)
    """
    # Sort by threshold to ensure consistent ordering
    sorted_limits = sorted(FILE_SIZE_LIMITS.values(), key=lambda x: x[0])
    
    for threshold, max_chunks, max_concepts in sorted_limits:
        if file_size_mb < threshold:
            return max_chunks, max_concepts
    
    # Return xlarge limits if nothing matches
    _, max_chunks, max_concepts = FILE_SIZE_LIMITS['xlarge']
    return max_chunks, max_concepts

# === Core processing functions using ConcurrencyManager ===
def process_chunks_sync(chunks: ChunkList, extraction_params: ExtractionParams, 
                       max_concepts: Optional[int] = None, progress_callback: ProgressCallback = None) -> ConceptList:
    """Process chunks synchronously using ConcurrencyManager.
    
    Args:
        chunks: List of text chunks to process
        extraction_params: Parameters for extraction
        max_concepts: Maximum number of concepts to extract
        progress_callback: Optional progress callback
        
    Returns:
        List of extracted concepts
    """
    # Get the concurrency manager
    manager = get_concurrency_manager()
    
    # Create an async function to run
    async def _process_chunks_internal():
        all_concepts = []
        batch_size = int(os.environ.get('CHUNK_BATCH_SIZE', '10'))
        
        # Process chunks in batches
        with ProgressTracker(len(chunks), description="Processing chunks") as tracker:
            for i in range(0, len(chunks), batch_size):
                batch = chunks[i:i + batch_size]
                
                # Process batch using chunk executor
                batch_tasks = []
                for chunk_data in batch:
                    if isinstance(chunk_data, dict):
                        chunk_text = chunk_data.get("text", "")
                        chunk_index = chunk_data.get("index", i)
                        chunk_section = chunk_data.get("section", "body")
                    else:
                        chunk_text = str(chunk_data)
                        chunk_index = i
                        chunk_section = "body"
                    
                    # Run in chunk executor
                    task = manager.run_chunk(
                        extract_and_boost_concepts,
                        chunk_text,
                        extraction_params['threshold'],
                        chunk_index,
                        chunk_section,
                        extraction_params['title'],
                        extraction_params['abstract']
                    )
                    batch_tasks.append(task)
                
                # Wait for batch to complete
                batch_results = await asyncio.gather(*batch_tasks, return_exceptions=True)
                
                # Process results
                for result in batch_results:
                    if isinstance(result, Exception):
                        logger.error(f"Error processing chunk: {result}")
                        continue
                    all_concepts.extend(result)
                
                # Update progress
                tracker.update(len(batch))
                if progress_callback:
                    progress_callback("concepts", 
                                    min(60, 40 + int((i / len(chunks)) * 20)), 
                                    f"Processed {i + len(batch)}/{len(chunks)} chunks")
                
                # Check concept limit
                if max_concepts and len(all_concepts) >= max_concepts:
                    logger.info(f"Concept limit reached: {len(all_concepts)}")
                    break
        
        # Log stats
        if logger.isEnabledFor(logging.DEBUG):
            stats = manager.get_stats()
            logger.debug(f"Chunk processing stats: {stats}")
        
        return all_concepts[:max_concepts] if max_concepts else all_concepts
    
    # Run in new event loop
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(_process_chunks_internal())
    finally:
        loop.close()


async def process_chunks_async(chunks: ChunkList, extraction_params: ExtractionParams,
                             max_concepts: Optional[int] = None, progress_callback: ProgressCallback = None) -> ConceptList:
    """Process chunks asynchronously using ConcurrencyManager.
    
    Args:
        chunks: List of text chunks to process
        extraction_params: Parameters for extraction
        max_concepts: Maximum number of concepts to extract
        progress_callback: Optional progress callback
        
    Returns:
        List of extracted concepts
    """
    manager = get_concurrency_manager()
    
    # Determine executor type based on workload
    if len(chunks) > 100:
        # For large workloads, use batching
        all_concepts = []
        batch_size = int(os.environ.get('CHUNK_BATCH_SIZE', '10'))
        
        async with ProgressTracker(len(chunks), description="Processing chunks") as tracker:
            # Process function for each chunk
            async def process_single_chunk(chunk_data):
                if isinstance(chunk_data, dict):
                    chunk_text = chunk_data.get("text", "")
                    chunk_index = chunk_data.get("index", 0)
                    chunk_section = chunk_data.get("section", "body")
                else:
                    chunk_text = str(chunk_data)
                    chunk_index = 0
                    chunk_section = "body"
                
                return await manager.run_chunk(
                    extract_and_boost_concepts,
                    chunk_text,
                    extraction_params['threshold'],
                    chunk_index,
                    chunk_section,
                    extraction_params['title'],
                    extraction_params['abstract']
                )
            
            # Process in batches
            for i in range(0, len(chunks), batch_size):
                batch = chunks[i:i + batch_size]
                
                # Process batch concurrently
                batch_results = await asyncio.gather(
                    *[process_single_chunk(chunk) for chunk in batch],
                    return_exceptions=True
                )
                
                # Collect results
                for result in batch_results:
                    if isinstance(result, Exception):
                        logger.error(f"Error processing chunk: {result}")
                        continue
                    all_concepts.extend(result)
                
                # Update progress
                await tracker.update_async(len(batch))
                if progress_callback:
                    progress_callback("concepts", 
                                    min(60, 40 + int((i / len(chunks)) * 20)), 
                                    f"Processed {i + len(batch)}/{len(chunks)} chunks")
                
                # Check limit
                if max_concepts and len(all_concepts) >= max_concepts:
                    logger.info(f"Concept limit reached: {len(all_concepts)}")
                    break
                    
                # Yield control periodically
                if i % (batch_size * 10) == 0:
                    await asyncio.sleep(0)
    else:
        # For small workloads, use map_chunks
        def extract_chunk(chunk_data):
            if isinstance(chunk_data, dict):
                return extract_and_boost_concepts(
                    chunk_data.get("text", ""),
                    extraction_params['threshold'],
                    chunk_data.get("index", 0),
                    chunk_data.get("section", "body"),
                    extraction_params['title'],
                    extraction_params['abstract']
                )
            else:
                return extract_and_boost_concepts(
                    str(chunk_data),
                    extraction_params['threshold'],
                    0,
                    "body",
                    extraction_params['title'],
                    extraction_params['abstract']
                )
        
        # Process all chunks
        results = await manager.map_chunks(extract_chunk, chunks)
        all_concepts = []
        for result in results:
            all_concepts.extend(result)
    
    # Log stats
    if logger.isEnabledFor(logging.DEBUG):
        stats = manager.get_stats()
        logger.debug(f"Async chunk processing stats: {stats}")
    
    return all_concepts[:max_concepts] if max_concepts else all_concepts

def ingest_pdf_core(pdf_path: str, 
                   doc_id: Optional[str] = None,
                   extraction_threshold: float = 0.0,
                   admin_mode: bool = False,
                   use_ocr: Optional[bool] = None,
                   progress_callback: ProgressCallback = None) -> IngestResponse:
    """
    Core synchronous PDF ingestion logic.
    This is the main processing function that can be wrapped for async usage.
    
    Args:
        pdf_path: Path to the PDF file
        doc_id: Optional document ID
        extraction_threshold: Minimum concept score threshold
        admin_mode: Enable admin mode for unlimited concepts
        use_ocr: Force OCR usage (None = use config default)
        progress_callback: Optional progress callback function
        
    Returns:
        IngestResponse with extraction results
    """
    start_time = datetime.now()
    
    # Initialize
    if doc_id is None:
        doc_id = Path(pdf_path).stem
    
    if use_ocr is None:
        use_ocr = ENABLE_OCR_FALLBACK
    
    # Helper for progress updates
    def update_progress(stage: str, pct: int, msg: str):
        if progress_callback:
            try:
                progress_callback(stage, pct, msg)
            except Exception as e:
                logger.debug(f"Progress callback error: {e}")
    
    update_progress("init", 0, "Starting PDF processing...")
    
    # Safety check
    safe, msg, metadata = check_pdf_safety(pdf_path)
    if not safe:
        logger.error(f"PDF safety check failed: {msg}")
        return _create_error_response(pdf_path, msg, start_time, admin_mode)
    
    file_size_mb = metadata.get("file_size_mb", 0)
    sha256 = metadata.get("sha256", "unknown")
    
    # Log with SHA-256 for deduplication
    if ENABLE_EMOJI_LOGS:
        logger.info(f"🛡️ Ingesting: {Path(pdf_path).name} ({file_size_mb:.1f}MB, SHA256: {sha256[:8]}...)")
    else:
        logger.info(f"Ingesting: {Path(pdf_path).name} ({file_size_mb:.1f}MB, SHA256: {sha256[:8]}...)")
    
    # Get dynamic limits
    MAX_CHUNKS, MAX_TOTAL_CONCEPTS = get_dynamic_limits(file_size_mb)
    
    logger.info(f"File size: {file_size_mb:.1f} MB, Limits: {MAX_CHUNKS} chunks, {MAX_TOTAL_CONCEPTS} concepts")
    
    # Log chunk processing configuration if debug enabled
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug(f"Chunk processing config: parallel={ENABLE_PARALLEL_PROCESSING}, "
                    f"workers={MAX_PARALLEL_WORKERS}, batch_size={os.environ.get('CHUNK_BATCH_SIZE', '4')}")
    
    try:
        # Extract metadata safely (already done in safety check)
        doc_metadata = metadata
        
        # Try OCR preprocessing if enabled
        update_progress("ocr", 10, "Checking OCR requirements...")
        ocr_text = None
        if use_ocr:
            ocr_text = preprocess_with_ocr(pdf_path)
            if ocr_text:
                doc_metadata['ocr_used'] = True
        
        # Reset frequency counter safely
        update_progress("frequency", 15, "Resetting frequency counter...")
        if ENABLE_FREQUENCY_TRACKING:
            try:
                reset_frequency_counter()
                logger.debug("Frequency counter reset successfully")
            except Exception as e:
                logger.warning(f"Frequency counter reset failed: {e}")
        
        # Extract chunks safely
        update_progress("chunks", 20, "Extracting text chunks...")
        if ocr_text:
            # Create chunks from OCR text
            chunks = []
            ocr_lines = ocr_text.split('\n')
            chunk_size = 50  # lines per chunk
            for i in range(0, len(ocr_lines), chunk_size):
                chunk_text = '\n'.join(ocr_lines[i:i+chunk_size])
                chunks.append({
                    'text': chunk_text,
                    'index': len(chunks),
                    'section': detect_section_type(chunk_text)
                })
            if ENABLE_EMOJI_LOGS:
                logger.info(f"📄 Created {len(chunks)} chunks from OCR text")
            else:
                logger.info(f"Created {len(chunks)} chunks from OCR text")
        else:
            chunks = extract_chunks(pdf_path)
        
        update_progress("chunks", 30, f"Extracted {len(chunks) if chunks else 0} text chunks")
        
        if not chunks:
            logger.warning(f"No chunks extracted from {pdf_path}")
            return _create_empty_response(pdf_path, start_time, admin_mode)
        
        # Enhance chunks with section detection
        for chunk in chunks:
            if isinstance(chunk, dict) and 'section' not in chunk:
                chunk['section'] = detect_section_type(chunk.get('text', ''))
        
        # Extract title and abstract safely
        update_progress("context", 35, "Extracting document context...")
        title_text, abstract_text = "", ""
        if ENABLE_CONTEXT_EXTRACTION:
            title_text, abstract_text = extract_title_abstract_safe(chunks, pdf_path)
        
        # Process chunks
        update_progress("concepts", 40, "Starting concept extraction...")
        chunks_to_process = chunks[:MAX_CHUNKS]
        
        extraction_params = {
            'threshold': extraction_threshold,
            'title': title_text,
            'abstract': abstract_text
        }
        
        # Process chunks with proper handling  
        if ENABLE_PARALLEL_PROCESSING:
            all_extracted_concepts = process_chunks_sync(
                chunks_to_process, extraction_params, MAX_TOTAL_CONCEPTS, update_progress
            )
        else:
            # Sequential processing
            all_extracted_concepts = []
            for i, chunk_data in enumerate(chunks_to_process):
                if isinstance(chunk_data, dict):
                    chunk_text = chunk_data.get("text", "")
                    chunk_index = chunk_data.get("index", i)
                    chunk_section = chunk_data.get("section", "body")
                else:
                    chunk_text = str(chunk_data)
                    chunk_index = i
                    chunk_section = "body"
                
                if not chunk_text:
                    continue
                
                # Extract concepts
                concepts = extract_and_boost_concepts(
                    chunk_text, extraction_params['threshold'], 
                    chunk_index, chunk_section, 
                    extraction_params['title'], extraction_params['abstract']
                )
                all_extracted_concepts.extend(concepts)
                
                # Update progress
                if progress_callback and i % 10 == 0:
                    progress_callback("concepts", 
                                    min(60, 40 + int((i / len(chunks_to_process)) * 20)), 
                                    f"Processing chunk {i+1}/{len(chunks_to_process)}")
                
                # Check limit
                if MAX_TOTAL_CONCEPTS and len(all_extracted_concepts) >= MAX_TOTAL_CONCEPTS:
                    logger.info(f"Concept limit reached: {len(all_extracted_concepts)}")
                    break
        
        if not all_extracted_concepts:
            logger.error("No concepts extracted!")
            return _create_empty_response(pdf_path, start_time, admin_mode, status="no_concepts")
        
        # Count concepts by method
        semantic_count = sum(1 for c in all_extracted_concepts if "universal" in safe_get(c, "method", ""))
        boosted_count = sum(1 for c in all_extracted_concepts 
                          if "file_storage_boosted" in safe_get(c, "method", "") or "boost" in safe_get(c, "method", ""))
        
        # Apply purity filtering with enhanced quality scoring
        update_progress("analysis", 65, "Scoring concepts...")
        doc_context = {
            'title': title_text,
            'abstract': abstract_text,
            'filename': Path(pdf_path).name
        }
        pure_concepts = analyze_concept_purity(
            all_extracted_concepts, 
            Path(pdf_path).name, 
            title_text, 
            abstract_text, 
            doc_context
        )
        update_progress("analysis", 70, "Analyzing concept purity...")
        update_progress("analysis", 75, f"Purity analysis complete: {len(pure_concepts)} concepts")
        
        original_pure_count = len(pure_concepts)
        concept_count = len(pure_concepts)
        prune_stats = None
        
        # Apply entropy pruning if enabled
        update_progress("pruning", 80, "Applying entropy pruning...")
        if ENABLE_ENTROPY_PRUNING and concept_count > 0:
            # Determine document type from metadata
            doc_type = DocumentType.GENERAL
            if 'research' in Path(pdf_path).name.lower() or abstract_text:
                doc_type = DocumentType.RESEARCH
            elif any(tech in Path(pdf_path).name.lower() for tech in ['technical', 'manual', 'spec']):
                doc_type = DocumentType.TECHNICAL
                
            # Use enhanced pruning if available
            use_enhanced = os.environ.get('USE_ENHANCED_PRUNING', 'true').lower() == 'true'
            
            if use_enhanced:
                # Create enhanced pruner
                pruner = create_enhanced_pruner(ENTROPY_CONFIG, doc_type.value)
                pure_concepts, prune_stats_obj = pruner.prune_concepts(
                    pure_concepts, 
                    max_concepts=None if admin_mode else ENTROPY_CONFIG.get("max_diverse_concepts"),
                    admin_mode=admin_mode
                )
                # Convert stats object to dict
                prune_stats = prune_stats_obj.to_dict()
                
                # Create visualization if requested
                if os.environ.get('CREATE_PRUNE_VIZ', '').lower() == 'true':
                    viz_path = f"prune_viz_{Path(pdf_path).stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
                    create_prune_visualization(pruner.decisions, viz_path)
            else:
                # Use original pruning
                pure_concepts, prune_stats = apply_entropy_pruning(pure_concepts, admin_mode)
                
            concept_count = len(pure_concepts)
            update_progress("pruning", 85, f"Entropy pruning complete: {concept_count} diverse concepts")
            if ENABLE_EMOJI_LOGS:
                logger.info(f"✅ Entropy pruning: {concept_count} concepts from {original_pure_count}")
            else:
                logger.info(f"Entropy pruning: {concept_count} concepts from {original_pure_count}")
        
        # Store concepts if enabled (sync version)
        update_progress("storage", 90, "Storing concepts...")
        if ENABLE_ENHANCED_MEMORY_STORAGE and concept_count > 0:
            try:
                store_concepts_sync(pure_concepts, doc_metadata)
                update_progress("storage", 95, "Memory storage complete")
            except Exception as e:
                logger.warning(f"Memory storage failed: {e}")
        
        # Inject concepts into cognitive interface
        if concept_count > 0:
            inject_concept_diff(pure_concepts, doc_metadata, Path(pdf_path).name)
            update_progress("finalize", 98, "Finalizing concept integration...")
        
        update_progress("complete", 100, "Processing complete!")
        
        # Build response
        return _build_response(
            pdf_path, pure_concepts, all_extracted_concepts, 
            chunks, chunks_to_process, semantic_count, boosted_count,
            title_text, abstract_text, doc_metadata, prune_stats,
            original_pure_count, admin_mode, start_time
        )
        
    except Exception as e:
        logger.error(f"PDF ingestion failed: {e}", exc_info=True)
        return _create_error_response(pdf_path, str(e), start_time, admin_mode)


async def ingest_pdf_async(pdf_path: str, 
                          doc_id: Optional[str] = None, 
                          extraction_threshold: float = 0.0, 
                          admin_mode: bool = False, 
                          use_ocr: Optional[bool] = None,
                          progress_callback: ProgressCallback = None) -> IngestResponse:
    """
    Async PDF ingestion - use this from async contexts (FastAPI routes).
    Uses ConcurrencyManager for efficient async processing.
    
    Args:
        pdf_path: Path to the PDF file
        doc_id: Optional document ID
        extraction_threshold: Minimum concept score threshold
        admin_mode: Enable admin mode for unlimited concepts
        use_ocr: Force OCR usage (None = use config default)
        progress_callback: Optional progress callback function
        
    Returns:
        IngestResponse with extraction results
    """
    start_time = datetime.now()
    error_context = ErrorContext(operation="pdf_ingestion", file_path=pdf_path)
    manager = get_concurrency_manager()
    
    # Initialize
    if doc_id is None:
        doc_id = Path(pdf_path).stem
    
    if use_ocr is None:
        use_ocr = ENABLE_OCR_FALLBACK
    
    # Helper for progress updates
    def update_progress(stage: str, pct: int, msg: str):
        if progress_callback:
            try:
                progress_callback(stage, pct, msg)
            except Exception as e:
                logger.debug(f"Progress callback error: {e}")
    
    update_progress("init", 0, "Starting PDF processing...")
    
    try:
        # Input validation
        if not pdf_path:
            raise ValidationError("PDF path cannot be empty", field="pdf_path")
        
        if not Path(pdf_path).exists():
            raise PipelineIOError(f"PDF file not found: {pdf_path}", path=pdf_path)
            
        if not pdf_path.lower().endswith('.pdf'):
            raise ValidationError(f"File must be a PDF: {pdf_path}", field="pdf_path")
        
        # Safety check using I/O executor
        error_context.operation = "safety_check"
        safe, msg, metadata = await manager.run_io(check_pdf_safety, pdf_path)
        if not safe:
            raise ValidationError(f"PDF safety check failed: {msg}", field="pdf_size")
        
        file_size_mb = metadata.get("file_size_mb", 0)
        sha256 = metadata.get("sha256", "unknown")
        
        # Log with SHA-256 for deduplication
        if ENABLE_EMOJI_LOGS:
            logger.info(f"🔐 Ingesting: {Path(pdf_path).name} ({file_size_mb:.1f}MB, SHA256: {sha256[:8]}...)")
        else:
            logger.info(f"Ingesting: {Path(pdf_path).name} ({file_size_mb:.1f}MB, SHA256: {sha256[:8]}...)")
        
        # Get dynamic limits
        MAX_CHUNKS, MAX_TOTAL_CONCEPTS = get_dynamic_limits(file_size_mb)
        
        logger.info(f"File size: {file_size_mb:.1f} MB, Limits: {MAX_CHUNKS} chunks, {MAX_TOTAL_CONCEPTS} concepts")
        
        # Extract metadata
        doc_metadata = metadata
        
        # Try OCR preprocessing if enabled
        error_context.operation = "ocr_processing"
        update_progress("ocr", 10, "Checking OCR requirements...")
        ocr_text = None
        if use_ocr:
            try:
                ocr_text = await manager.run_io(preprocess_with_ocr, pdf_path)
                if ocr_text:
                    doc_metadata['ocr_used'] = True
            except Exception as e:
                logger.warning(f"OCR processing failed: {e}")
                # OCR failure is not critical
        
        # Reset frequency counter
        error_context.operation = "frequency_reset"
        update_progress("frequency", 15, "Resetting frequency counter...")
        if ENABLE_FREQUENCY_TRACKING:
            try:
                reset_frequency_counter()
                logger.debug("Frequency counter reset successfully")
            except Exception as e:
                logger.warning(f"Frequency counter reset failed: {e}")
        
        # Extract chunks using I/O executor
        error_context.operation = "chunk_extraction"
        update_progress("chunks", 20, "Extracting text chunks...")
        
        try:
            if ocr_text:
                # Create chunks from OCR text
                chunks = []
                ocr_lines = ocr_text.split('\n')
                chunk_size = 50  # lines per chunk
                for i in range(0, len(ocr_lines), chunk_size):
                    chunk_text = '\n'.join(ocr_lines[i:i+chunk_size])
                    chunks.append({
                        'text': chunk_text,
                        'index': len(chunks),
                        'section': detect_section_type(chunk_text)
                    })
                if ENABLE_EMOJI_LOGS:
                    logger.info(f"📄 Created {len(chunks)} chunks from OCR text")
                else:
                    logger.info(f"Created {len(chunks)} chunks from OCR text")
            else:
                chunks = await manager.run_io(extract_chunks, pdf_path)
        except PDFParseError:
            raise  # Re-raise parse errors
        except Exception as e:
            raise ExtractionError(f"Failed to extract chunks: {e}", recoverable=False)
        
        update_progress("chunks", 30, f"Extracted {len(chunks) if chunks else 0} text chunks")
        
        if not chunks:
            logger.warning(f"No chunks extracted from {pdf_path}")
            return _create_empty_response(pdf_path, start_time, admin_mode)
        
        # Enhance chunks with section detection
        for chunk in chunks:
            if isinstance(chunk, dict) and 'section' not in chunk:
                chunk['section'] = detect_section_type(chunk.get('text', ''))
        
        # Extract title and abstract
        error_context.operation = "context_extraction"
        update_progress("context", 35, "Extracting document context...")
        title_text, abstract_text = "", ""
        if ENABLE_CONTEXT_EXTRACTION:
            try:
                title_text, abstract_text = await manager.run_io(
                    extract_title_abstract_safe, chunks, pdf_path
                )
            except Exception as e:
                logger.warning(f"Context extraction failed: {e}")
                # Context extraction failure is not critical
        
        # Process chunks
        error_context.operation = "concept_extraction"
        update_progress("concepts", 40, "Starting concept extraction...")
        chunks_to_process = chunks[:MAX_CHUNKS]
        
        extraction_params = {
            'threshold': extraction_threshold,
            'title': title_text,
            'abstract': abstract_text
        }
        
        # Process chunks with async processing
        try:
            all_extracted_concepts = await process_chunks_async(
                chunks_to_process, extraction_params, MAX_TOTAL_CONCEPTS, update_progress
            )
        except ExtractionError:
            raise  # Re-raise extraction errors
        except Exception as e:
            raise ExtractionError(f"Chunk processing failed: {e}", recoverable=False)
        
        if not all_extracted_concepts:
            logger.error("No concepts extracted!")
            return _create_empty_response(pdf_path, start_time, admin_mode, status="no_concepts")
        
        # Rest of the processing continues as in the sync version...
        # Count concepts by method
        semantic_count = sum(1 for c in all_extracted_concepts if "universal" in safe_get(c, "method", ""))
        boosted_count = sum(1 for c in all_extracted_concepts 
                          if "file_storage_boosted" in safe_get(c, "method", "") or "boost" in safe_get(c, "method", ""))
        
        # Apply purity filtering
        error_context.operation = "purity_analysis"
        update_progress("analysis", 65, "Scoring concepts...")
        doc_context = {
            'title': title_text,
            'abstract': abstract_text,
            'filename': Path(pdf_path).name
        }
        pure_concepts = await manager.run_cpu(
            analyze_concept_purity,
            all_extracted_concepts, 
            Path(pdf_path).name, 
            title_text, 
            abstract_text, 
            doc_context
        )
        update_progress("analysis", 70, "Analyzing concept purity...")
        update_progress("analysis", 75, f"Purity analysis complete: {len(pure_concepts)} concepts")
        
        original_pure_count = len(pure_concepts)
        concept_count = len(pure_concepts)
        prune_stats = None
        
        # Apply entropy pruning if enabled
        error_context.operation = "entropy_pruning"
        update_progress("pruning", 80, "Applying entropy pruning...")
        if ENABLE_ENTROPY_PRUNING and concept_count > 0:
            try:
                # Determine document type
                doc_type = DocumentType.GENERAL
                if 'research' in Path(pdf_path).name.lower() or abstract_text:
                    doc_type = DocumentType.RESEARCH
                elif any(tech in Path(pdf_path).name.lower() for tech in ['technical', 'manual', 'spec']):
                    doc_type = DocumentType.TECHNICAL
                    
                # Use enhanced pruning if available
                use_enhanced = os.environ.get('USE_ENHANCED_PRUNING', 'true').lower() == 'true'
                
                if use_enhanced:
                    # Create enhanced pruner
                    pruner = create_enhanced_pruner(ENTROPY_CONFIG, doc_type.value)
                    result = await manager.run_cpu(
                        pruner.prune_concepts,
                        pure_concepts, 
                        None if admin_mode else ENTROPY_CONFIG.get("max_diverse_concepts"),
                        admin_mode
                    )
                    pure_concepts, prune_stats_obj = result
                    # Convert stats object to dict
                    prune_stats = prune_stats_obj.to_dict()
                    
                    # Create visualization if requested
                    if os.environ.get('CREATE_PRUNE_VIZ', '').lower() == 'true':
                        viz_path = f"prune_viz_{Path(pdf_path).stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
                        await manager.run_io(create_prune_visualization, pruner.decisions, viz_path)
                else:
                    # Use original pruning
                    result = await manager.run_cpu(
                        apply_entropy_pruning, pure_concepts, admin_mode
                    )
                    pure_concepts, prune_stats = result
                    
                concept_count = len(pure_concepts)
                update_progress("pruning", 85, f"Entropy pruning complete: {concept_count} diverse concepts")
                if ENABLE_EMOJI_LOGS:
                    logger.info(f"✅ Entropy pruning: {concept_count} concepts from {original_pure_count}")
                else:
                    logger.info(f"Entropy pruning: {concept_count} concepts from {original_pure_count}")
            except Exception as e:
                logger.warning(f"Entropy pruning failed: {e}")
                # Pruning failure is not critical
        
        # Store concepts if enabled
        error_context.operation = "concept_storage"
        update_progress("storage", 90, "Storing concepts...")
        if ENABLE_ENHANCED_MEMORY_STORAGE and concept_count > 0:
            try:
                await store_concepts_in_soliton(pure_concepts, doc_metadata)
                update_progress("storage", 95, "Memory storage complete")
            except Exception as e:
                logger.warning(f"Memory storage failed: {e}")
                # Storage failure is not critical
        
        # Inject concepts into cognitive interface
        if concept_count > 0:
            try:
                await manager.run_io(
                    inject_concept_diff, pure_concepts, doc_metadata, Path(pdf_path).name
                )
                update_progress("finalize", 98, "Finalizing concept integration...")
            except Exception as e:
                logger.warning(f"Concept injection failed: {e}")
        
        update_progress("complete", 100, "Processing complete!")
        
        # Build response
        return _build_response(
            pdf_path, pure_concepts, all_extracted_concepts, 
            chunks, chunks_to_process, semantic_count, boosted_count,
            title_text, abstract_text, doc_metadata, prune_stats,
            original_pure_count, admin_mode, start_time
        )
        
    except PipelineError as e:
        # Handle pipeline-specific errors
        logger.error(f"Pipeline error in {error_context.operation}: {e}")
        return ErrorResponseBuilder.build_error_response(
            pdf_path, e, error_context, start_time.timestamp(), admin_mode
        )
    except Exception as e:
        # Convert unexpected errors
        pipeline_error = PipelineError(
            f"Unexpected error: {e}",
            severity=ErrorSeverity.HIGH,
            details={"exception_type": type(e).__name__}
        )
        logger.error(f"Unexpected error in {error_context.operation}: {e}", exc_info=True)
        return ErrorResponseBuilder.build_error_response(
            pdf_path, pipeline_error, error_context, start_time.timestamp(), admin_mode
        )


def ingest_pdf_clean(pdf_path: str, 
                    doc_id: Optional[str] = None, 
                    extraction_threshold: float = 0.0, 
                    admin_mode: bool = False, 
                    use_ocr: Optional[bool] = None,
                    progress_callback: ProgressCallback = None) -> IngestResponse:
    """
    Clean synchronous entry point.
    Simply calls the core sync function directly.
    
    Args:
        pdf_path: Path to the PDF file
        doc_id: Optional document ID
        extraction_threshold: Minimum concept score threshold
        admin_mode: Enable admin mode for unlimited concepts
        use_ocr: Force OCR usage (None = use config default)
        progress_callback: Optional progress callback function
        
    Returns:
        IngestResponse with extraction results
    """
    return ingest_pdf_core(
        pdf_path,
        doc_id,
        extraction_threshold,
        admin_mode,
        use_ocr,
        progress_callback
    )


def _create_empty_response(pdf_path: str, start_time: datetime, 
                          admin_mode: bool, status: str = "empty") -> IngestResponse:
    """Create response for empty extraction.
    
    Args:
        pdf_path: Path to the PDF file
        start_time: Processing start time
        admin_mode: Whether admin mode is enabled
        status: Response status
        
    Returns:
        IngestResponse with empty results
    """
    response: IngestResponse = {
        "filename": Path(pdf_path).name,
        "concept_count": 0,
        "concepts": [],
        "concept_names": [],
        "status": status,  # type: ignore
        "admin_mode": admin_mode,
        "processing_time_seconds": safe_divide((datetime.now() - start_time).total_seconds(), 1, 0.1),
        # Required fields with defaults
        "purity_based": True,
        "entropy_pruned": False,
        "equal_access": True,
        "performance_limited": True,
        "chunks_processed": 0,
        "chunks_available": 0,
        "semantic_extracted": 0,
        "file_storage_boosted": 0,
        "average_concept_score": 0.0,
        "high_confidence_concepts": 0,
        "high_quality_concepts": 0,
        "total_extraction_time": safe_divide((datetime.now() - start_time).total_seconds(), 1, 0.1),
        "domain_distribution": {},
        "section_distribution": {},
        "title_found": False,
        "abstract_found": False,
        "ocr_used": False,
        "parallel_processing": ENABLE_PARALLEL_PROCESSING,
        "enhanced_memory_storage": ENABLE_ENHANCED_MEMORY_STORAGE,
        "sha256": "unknown",
        "purity_analysis": {
            "raw_concepts": 0,
            "pure_concepts": 0,
            "final_concepts": 0,
            "purity_efficiency_percent": 0.0,
            "diversity_efficiency_percent": 0.0,
            "top_concepts": []
        },
        "entropy_analysis": {
            "enabled": False,
            "reason": "no_concepts"
        },
        "error_message": None,
        "error": None,
        "warnings": None,
        "metadata": None
    }
    return response


def _create_error_response(pdf_path: str, error: str, start_time: datetime, 
                          admin_mode: bool) -> ErrorResponse:
    """Create response for error case.
    
    Args:
        pdf_path: Path to the PDF file
        error: Error message
        start_time: Processing start time
        admin_mode: Whether admin mode is enabled
        
    Returns:
        ErrorResponse with error details
    """
    response: ErrorResponse = {
        "filename": Path(pdf_path).name,
        "concept_count": 0,
        "concept_names": [],
        "concepts": [],
        "status": "error",
        "error_message": error,
        "admin_mode": admin_mode,
        "processing_time_seconds": safe_divide((datetime.now() - start_time).total_seconds(), 1, 0.1),
        "error": {
            "message": error,
            "category": "unknown",
            "severity": "high"
        },
        "metadata": None
    }
    return response


def _build_response(pdf_path: str, pure_concepts: ConceptList, all_extracted_concepts: ConceptList,
                   chunks: ChunkList, chunks_to_process: ChunkList, 
                   semantic_count: int, boosted_count: int,
                   title_text: str, abstract_text: str, doc_metadata: PdfMetadata,
                   prune_stats: Optional[Dict], original_pure_count: int,
                   admin_mode: bool, start_time: datetime) -> IngestResponse:
    """Build the complete response dictionary.
    
    Args:
        pdf_path: Path to the PDF file
        pure_concepts: Filtered concepts
        all_extracted_concepts: All extracted concepts
        chunks: All chunks
        chunks_to_process: Processed chunks
        semantic_count: Number of semantic concepts
        boosted_count: Number of boosted concepts
        title_text: Document title
        abstract_text: Document abstract
        doc_metadata: Document metadata
        prune_stats: Pruning statistics
        original_pure_count: Original concept count before pruning
        admin_mode: Whether admin mode is enabled
        start_time: Processing start time
        
    Returns:
        Complete IngestResponse
    """
    concept_count = len(pure_concepts)
    total_time = safe_divide((datetime.now() - start_time).total_seconds(), 1, 0.1)
    
    # Calculate scores
    if pure_concepts:
        valid_scores = [safe_get(c, "quality_score", safe_get(c, "score", 0)) for c in pure_concepts]
        valid_scores = [s for s in valid_scores if s is not None]
        avg_score = safe_divide(sum(valid_scores), len(valid_scores), 0) if valid_scores else 0.0
    else:
        avg_score = 0.0
    
    high_conf_count = sum(1 for c in pure_concepts if safe_get(c, "score", 0) > 0.8)
    high_quality_count = sum(1 for c in pure_concepts if safe_get(c, "quality_score", 0) > 0.8)
    
    # Calculate section distribution
    section_distribution = {}
    for c in pure_concepts:
        section = safe_get(safe_get(c, 'metadata', {}), 'section', 'body')
        section_distribution[section] = section_distribution.get(section, 0) + 1
    
    # Build response
    response = {
        "filename": Path(pdf_path).name,
        "concept_count": concept_count,
        "concept_names": [safe_get(c, 'name', '') for c in pure_concepts],
        "concepts": pure_concepts,
        "status": "success" if concept_count > 0 else "no_concepts",
        "purity_based": True,
        "entropy_pruned": ENABLE_ENTROPY_PRUNING and prune_stats is not None,
        "admin_mode": admin_mode,
        "equal_access": True,
        "performance_limited": True,
        "chunks_processed": len(chunks_to_process),
        "chunks_available": len(chunks),
        "semantic_extracted": semantic_count,
        "file_storage_boosted": boosted_count,
        "average_concept_score": safe_round(avg_score),
        "high_confidence_concepts": high_conf_count,
        "high_quality_concepts": high_quality_count,
        "total_extraction_time": safe_round(total_time),
        "domain_distribution": {"general": concept_count},
        "section_distribution": section_distribution,
        "title_found": bool(title_text),
        "abstract_found": bool(abstract_text),
        "ocr_used": safe_get(doc_metadata, 'ocr_used', False),
        "parallel_processing": ENABLE_PARALLEL_PROCESSING,
        "enhanced_memory_storage": ENABLE_ENHANCED_MEMORY_STORAGE,
        "processing_time_seconds": safe_round(total_time),
        "sha256": safe_get(doc_metadata, 'sha256', 'unknown'),
        "purity_analysis": {
            "raw_concepts": len(all_extracted_concepts),
            "pure_concepts": original_pure_count,
            "final_concepts": concept_count,
            "purity_efficiency_percent": safe_round(safe_percentage(original_pure_count, len(all_extracted_concepts)), 1),
            "diversity_efficiency_percent": safe_round(safe_percentage(concept_count, original_pure_count), 1),
            "top_concepts": [
                {
                    "name": safe_get(c, 'name', ''),
                    "score": safe_round(safe_get(c, 'score', 0)),
                    "quality_score": safe_round(safe_get(c, 'quality_score', 0)),
                    "methods": [safe_get(c, 'method', 'unknown')],
                    "frequency": safe_get(safe_get(c, 'metadata', {}), 'frequency', 1),
                    "section": safe_get(safe_get(c, 'metadata', {}), 'section', 'body'),
                    "purity_decision": "accepted"
                }
                for c in pure_concepts[:10]
            ]
        }
    }
    
    # Add entropy analysis if available
    if prune_stats:
        # Sanitize stats completely
        clean_stats = sanitize_dict(prune_stats)
        
        total = safe_get(clean_stats, "total", 0)
        selected = safe_get(clean_stats, "selected", 0)
        pruned = safe_get(clean_stats, "pruned", 0)
        final_entropy = safe_get(clean_stats, "final_entropy", 0.0)
        avg_similarity = safe_get(clean_stats, "avg_similarity", 0.0)
        
        response["entropy_analysis"] = {
            "enabled": True,
            "admin_mode": admin_mode,
            "total_before_entropy": total,
            "selected_diverse": selected,
            "pruned_similar": pruned,
            "diversity_efficiency_percent": safe_round(safe_percentage(selected, total), 1),
            "final_entropy": safe_round(final_entropy),
            "avg_similarity": safe_round(avg_similarity),
            "by_category": safe_get(clean_stats, "by_category", {}),
            "config": {
                "max_diverse_concepts": "unlimited" if admin_mode else safe_get(ENTROPY_CONFIG, "max_diverse_concepts"),
                "entropy_threshold": safe_get(ENTROPY_CONFIG, "entropy_threshold", 0.0005),
                "similarity_threshold": safe_get(ENTROPY_CONFIG, "similarity_threshold", 0.83),
                "category_aware": safe_get(ENTROPY_CONFIG, "enable_categories", True)
            },
            "performance": {
                "original_pure_concepts": original_pure_count,
                "final_diverse_concepts": concept_count,
                "reduction_ratio": safe_round(safe_divide(original_pure_count - concept_count, original_pure_count, 0))
            }
        }
    else:
        response["entropy_analysis"] = {
            "enabled": False,
            "reason": "entropy_pruning_disabled" if not ENABLE_ENTROPY_PRUNING else "no_concepts_to_prune"
        }
    
    return response


# Re-export for backward compatibility
# ⚠️ Update test_exports() if you change this list
__all__ = [
    'ingest_pdf_clean', 
    'ingest_pdf_async', 
    'get_db', 
    'preload_concept_database',
    'preload_concept_database_async',
    'ProgressTracker',
    'shutdown_pipeline',
    'get_concurrency_manager'
]

# Cleanup function for graceful shutdown
def shutdown_pipeline():
    """Shutdown pipeline resources gracefully."""
    logger.info("Shutting down pipeline...")
    
    # Shutdown concurrency manager
    try:
        manager = get_concurrency_manager()
        manager.shutdown(wait=True)
    except Exception as e:
        logger.error(f"Error shutting down ConcurrencyManager: {e}")
    
    # Clear any cached data
    try:
        _current_db.set(None)
    except:
        pass
    
    logger.info("Pipeline shutdown complete")

# Register shutdown handler
import atexit
atexit.register(shutdown_pipeline)

if ENABLE_EMOJI_LOGS:
    logger.info("🛡️ PIPELINE LOADED - Production-ready with enhanced concurrency")
    logger.info("✨ Features: Dedicated executors, unified async/sync, thread-safe DB, quality scoring")
    logger.info("🚀 ConcurrencyManager initialized with CPU, I/O, and chunk executors")
else:
    logger.info("PIPELINE LOADED - Production-ready with enhanced concurrency")
    logger.info("Features: Dedicated executors, unified async/sync, thread-safe DB, quality scoring")
    logger.info("ConcurrencyManager initialized with CPU, I/O, and chunk executors")
