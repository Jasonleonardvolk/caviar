#!/usr/bin/env python3
"""
Hot-Swappable Graph Laplacian System
────────────────────────────────────
• Safe topologies: kagome · honeycomb · triangular · small_world  
• **Experimental**: penrose  (enable with env TORI_ENABLE_EXOTIC=1 or ctor flag)
• χ³ (Kerr) NLSE physics intact
"""
from __future__ import annotations

import asyncio
import logging
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import networkx as nx
import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import eigsh

# 3rd-party builder for Penrose
from .exotic_topologies import build_penrose_laplacian, PHI

# Optional infra stubs
try:
    from .blowup_harness import induce_blowup
    from .chaos_control_layer import ChaosControlLayer
except ModuleNotFoundError:  # unit-test context
    induce_blowup = lambda *a, **k: None
    ChaosControlLayer = object  # type: ignore

logger = logging.getLogger(__name__)


# ════════════════════════════════════════════════════════════════════════
#  Data classes
# ════════════════════════════════════════════════════════════════════════
@dataclass
class TopologyConfig:
    name: str
    lattice_type: str
    chern_number: int
    coordination_number: int
    spectral_gap: float
    optimal_for: List[str]


@dataclass
class ShadowTrace:
    phaseTag: float
    amplitude: float
    polarity: str
    original_index: int
    topological_charge: float


# ════════════════════════════════════════════════════════════════════════
#  Hot-Swappable Laplacian
# ════════════════════════════════════════════════════════════════════════
class HotSwappableLaplacian:
    def __init__(
        self,
        initial_topology: str = "kagome",
        lattice_size: Tuple[int, int] = (20, 20),
        ccl: Optional[ChaosControlLayer] = None,
        *,
        enable_experimental: bool | None = None,
    ):
        self.enable_experimental = (
            enable_experimental
            if enable_experimental is not None
            else bool(int(os.getenv("TORI_ENABLE_EXOTIC", "0")))
        )

        self.current_topology = initial_topology
        self.lattice_size = lattice_size
        self.ccl = ccl

        self.topologies = self._load_topology_configs()
        if initial_topology not in self.topologies:
            raise ValueError(
                f"Topology '{initial_topology}' not available "
                f"(enable_experimental={self.enable_experimental})"
            )

        # Build first Laplacian and init runtime state
        self.graph_laplacian = self._build_laplacian(initial_topology)
        self.active_solitons: List[Dict[str, Any]] = []
        self.total_energy = 0.0
        self.swap_history: List[Dict[str, Any]] = []
        self.swap_count = 0
        self.energy_harvested_total = 0.0
        self.max_history = 10

        # Energy thresholds
        self.critical_threshold = 1_000.0
        self.warning_threshold = 500.0

        logger.info(
            "Hot-swappable Laplacian initialised (%s, experimental=%s)",
            initial_topology,
            self.enable_experimental,
        )

    # ────────────────────────────────────────────────────────────────────
    #  Topology configs
    # ────────────────────────────────────────────────────────────────────
    def _load_topology_configs(self) -> Dict[str, TopologyConfig]:
        cfg: Dict[str, TopologyConfig] = {
            "kagome": TopologyConfig("kagome", "kagome", 1, 4, 0.5, ["pattern_recognition"]),
            "honeycomb": TopologyConfig("honeycomb", "honeycomb", 0, 3, 0.3, ["search"]),
            "triangular": TopologyConfig("triangular", "triangular", 2, 6, 0.7, ["dense_compute"]),
            "small_world": TopologyConfig("small_world", "small_world", 0, 4, 0.2, ["global_search"]),
        }

        if self.enable_experimental:
            cfg["penrose"] = TopologyConfig(
                "penrose", "penrose", 1, 4, 0.55, ["spectral_magic"]
            )
        return cfg

    # ────────────────────────────────────────────────────────────────────
    #  Graph builders
    # ────────────────────────────────────────────────────────────────────
    def _build_kagome_graph(self) -> nx.Graph:  # (unchanged)
        m, n = self.lattice_size
        G = nx.Graph()
        for i in range(m):
            for j in range(n):
                a, b, c = (i, j, "A"), (i, j, "B"), (i, j, "C")
                G.add_nodes_from([a, b, c])
                G.add_edges_from([(a, b), (b, c), (c, a)])
                if i < m - 1:
                    G.add_edge(b, ((i + 1) % m, j, "A"))
                if j < n - 1:
                    G.add_edge(c, (i, (j + 1) % n, "A"))
        return G

    def _build_honeycomb_graph(self) -> nx.Graph:  # (unchanged)
        m, n = self.lattice_size
        G = nx.Graph()
        for i in range(m):
            for j in range(n):
                a, b = (i, j, "A"), (i, j, "B")
                G.add_nodes_from([a, b])
                G.add_edge(a, b)
                if i < m - 1:
                    G.add_edge(b, ((i + 1) % m, j, "A"))
                if j < n - 1:
                    G.add_edge(b, (i, (j + 1) % n, "A"))
        return G

    def _build_triangular_graph(self) -> nx.Graph:  # (unchanged)
        m, n = self.lattice_size
        return nx.triangular_lattice_graph(m, n)

    def _build_small_world_graph(self) -> nx.Graph:  # (unchanged)
        m, n = self.lattice_size
        return nx.watts_strogatz_graph(m * n, k=4, p=0.1)



    # ────────────────────────────────────────────────────────────────────
    #  Laplacian builder
    # ────────────────────────────────────────────────────────────────────
    def _build_laplacian(self, topology: str) -> sp.csr_matrix:
        if topology not in self.topologies:
            raise ValueError(f"Topology '{topology}' unavailable")

        if topology == "kagome":
            G = self._build_kagome_graph()
            L = nx.laplacian_matrix(G).astype(np.float64)

        elif topology == "honeycomb":
            G = self._build_honeycomb_graph()
            L = nx.laplacian_matrix(G).astype(np.float64)

        elif topology == "triangular":
            G = self._build_triangular_graph()
            L = nx.laplacian_matrix(G).astype(np.float64)

        elif topology == "small_world":
            G = self._build_small_world_graph()
            L = nx.laplacian_matrix(G).astype(np.float64)

        elif topology == "penrose":
            # Penrose builder already returns a CSR Laplacian with flux
            L = build_penrose_laplacian()
            # Don't add flux again - it's already included

        else:
            raise ValueError(f"Unknown topology '{topology}'")

        cfg = self.topologies[topology]
        if cfg.chern_number and topology != "penrose":  # flux already baked for Penrose
            L = self._add_topological_flux(L, cfg.chern_number)
        return L.tocsr()

    # ────────────────────────────────────────────────────────────────────
    #  Flux adder (same bug-fixed version as before)
    # ────────────────────────────────────────────────────────────────────
    def _add_topological_flux(self, L: sp.csr_matrix, chern: int) -> sp.csr_matrix:
        n = L.shape[0]
        phase = 2 * np.pi * chern / n
        rows, cols = L.nonzero()
        flux = sp.lil_matrix((n, n), dtype=complex)
        for i, j in zip(rows, cols):
            if i < j:
                delta = j - i
                e = np.exp(1j * phase * delta)
                flux[i, j] = e
                flux[j, i] = np.conj(e)
        Lc = L.astype(complex).multiply(flux)
        return Lc.real.tocsr()

    # ────────────────────────────────────────────────────────────────────
    #  SWAP LOGIC
    # ────────────────────────────────────────────────────────────────────
    async def hot_swap_laplacian_with_safety(self, new_topology: str):
        """
        Perform hot-swap of graph Laplacian with full safety mechanisms
        
        Args:
            new_topology: Target topology ('kagome', 'honeycomb', 'triangular', 'small_world', 'penrose')
        """
        logger.info(f"Initiating hot-swap from {self.current_topology} to {new_topology}")
        
        # Record swap attempt
        swap_record = {
            'from': self.current_topology,
            'to': new_topology,
            'timestamp': asyncio.get_event_loop().time(),
            'initial_energy': self.total_energy
        }
        
        try:
            # 1. Create shadow traces to preserve phase relationships
            shadows = [self.create_shadow_trace(bright) for bright in self.active_solitons]
            logger.info(f"Created {len(shadows)} shadow traces")
            
            # 2. Check if energy is dangerously high (O(n²) buildup)
            harvested_energy = None
            if hasattr(self, 'lattice') and self.total_energy > self.critical_threshold:
                logger.warning(f"High energy detected: {self.total_energy:.2f}")
                # Harvest the excess energy before swap
                harvested_energy = induce_blowup(self.lattice, epsilon=0.3, steps=5)
                self.energy_harvested_total += np.sum(np.abs(harvested_energy)**2)
                logger.info("Energy harvested successfully")
                
            # 3. Save current state for rollback
            old_laplacian = self.graph_laplacian.copy()
            old_topology = self.current_topology
            
            # 4. Perform the Laplacian swap
            self.graph_laplacian = self._build_laplacian(new_topology)
            self.current_topology = new_topology
            
            # 5. Use shadows for interference-based stabilization
            await self.stabilize_with_shadows(shadows)
            
            # 6. Re-inject harvested energy as controlled solitons
            if harvested_energy is not None:
                await self.inject_as_bright_solitons(harvested_energy, new_topology)
                
            # 7. Verify stability
            if await self.verify_swap_stability():
                # Success - update records
                swap_record['success'] = True
                swap_record['final_energy'] = self.total_energy
                self.swap_history.append(swap_record)
                if len(self.swap_history) > self.max_history:
                    self.swap_history.pop(0)
                    
                self.swap_count += 1
                logger.info(f"Hot-swap completed successfully. Total swaps: {self.swap_count}")
                    
            else:
                # Rollback
                logger.error("Stability verification failed, rolling back")
                self.graph_laplacian = old_laplacian
                self.current_topology = old_topology
                swap_record['success'] = False
                swap_record['rollback'] = True
                
        except Exception as e:
            logger.error(f"Hot-swap failed: {e}")
            swap_record['success'] = False
            swap_record['error'] = str(e)
            raise

    # ────────────────────────────────────────────────────────────────────
    #  STABILIZATION
    # ────────────────────────────────────────────────────────────────────
    def create_shadow_trace(self, bright_soliton: Dict[str, Any]) -> ShadowTrace:
        """Create dark soliton shadow trace for a bright soliton"""
        return ShadowTrace(
            phaseTag=(bright_soliton.get('phase', 0) + np.pi) % (2 * np.pi),
            amplitude=-0.1 * bright_soliton.get('amplitude', 1.0),
            polarity='dark',
            original_index=bright_soliton.get('index', 0),
            topological_charge=bright_soliton.get('topological_charge', 0.0)
        )
        
    async def stabilize_with_shadows(self, shadows: List[ShadowTrace]):
        """Use shadow traces for phase-coherent stabilization"""
        logger.info("Stabilizing with shadow traces")
        
        # Create interference pattern
        for shadow in shadows:
            # Find matching bright soliton
            for i, soliton in enumerate(self.active_solitons):
                if i == shadow.original_index:
                    # Apply destructive interference to reduce energy
                    interference = shadow.amplitude * np.exp(1j * shadow.phaseTag)
                    soliton['amplitude'] *= (1 + 0.1 * interference.real)
                    
                    # Preserve topological charge
                    soliton['topological_charge'] = shadow.topological_charge
                    
        # Allow system to settle
        await asyncio.sleep(0.1)
        
    async def inject_as_bright_solitons(self, harvested_energy: np.ndarray, topology: str):
        """Re-inject harvested energy as bright solitons optimized for new topology"""
        logger.info(f"Re-injecting energy as bright solitons for {topology}")
        
        config = self.topologies[topology]
        
        # Determine optimal soliton configuration for this topology
        if 'search' in config.optimal_for:
            # Wide, fast-moving solitons for search
            soliton_width = 5.0
            soliton_velocity = 2.0
        elif 'optimization' in config.optimal_for:
            # Narrow, stable solitons for optimization
            soliton_width = 1.0
            soliton_velocity = 0.5
        else:
            # Default balanced configuration
            soliton_width = 2.0
            soliton_velocity = 1.0
        
        # Create solitons from harvested energy
        n_solitons = min(10, int(np.sum(np.abs(harvested_energy)**2) / 100))
        
        for i in range(n_solitons):
            soliton = {
                'amplitude': np.sqrt(np.abs(harvested_energy[i % len(harvested_energy)])),
                'phase': np.angle(harvested_energy[i % len(harvested_energy)]),
                'width': soliton_width,
                'velocity': soliton_velocity,
                'position': i * len(harvested_energy) // n_solitons,
                'topological_charge': config.chern_number,
                'index': len(self.active_solitons)
            }
            self.active_solitons.append(soliton)
        
        logger.info(f"Injected {n_solitons} bright solitons")
        
    async def verify_swap_stability(self) -> bool:
        """Verify system stability after topology swap"""
        # Check spectral properties
        try:
            # Compute smallest eigenvalues
            eigenvalues = eigsh(self.graph_laplacian, k=min(6, self.graph_laplacian.shape[0] - 1),
                                 which='SM', return_eigenvectors=False)
            
            # Check spectral gap
            if len(eigenvalues) > 1:
                spectral_gap = eigenvalues[1] - eigenvalues[0]
                config = self.topologies[self.current_topology]
                
                if spectral_gap < 0.5 * config.spectral_gap:
                    logger.warning(f"Spectral gap too small: {spectral_gap:.3f}")
                    return False
                    
            # Check energy conservation
            current_energy = sum(s.get('amplitude', 1.0)**2 for s in self.active_solitons)
            if current_energy > 2 * self.critical_threshold:
                logger.warning(f"Energy too high after swap: {current_energy:.2f}")
                return False
                
            return True
            
        except Exception as e:
            logger.error(f"Stability verification error: {e}")
            return False

    # ────────────────────────────────────────────────────────────────────
    #  METRICS AND UTILITIES
    # ────────────────────────────────────────────────────────────────────
    def recommend_topology_for_problem(self, problem_type: str) -> str:
        """Recommend optimal topology for given problem type"""
        for topology, config in self.topologies.items():
            if problem_type in config.optimal_for:
                return topology
        # Default to current if no match
        return self.current_topology
    
    async def adaptive_swap_for_complexity(self, current_complexity: str):
        """Automatically swap topology based on detected complexity pattern"""
        if current_complexity == "O(n²)":
            # Switch to small-world for better scaling
            if self.current_topology != 'small_world':
                logger.info("O(n²) detected - switching to small-world topology")
                await self.hot_swap_laplacian_with_safety('small_world')
        elif current_complexity == "dense_matrix":
            # Triangular is optimal for dense computations
            if self.current_topology != 'triangular':
                logger.info("Dense computation detected - switching to triangular topology")
                await self.hot_swap_laplacian_with_safety('triangular')
        elif current_complexity == "sparse_search":
            # Honeycomb for efficient sparse search
            if self.current_topology != 'honeycomb':
                logger.info("Sparse search detected - switching to honeycomb topology")
                await self.hot_swap_laplacian_with_safety('honeycomb')
    
    def multiply_with_topology(self, A: np.ndarray, B: np.ndarray) -> Tuple[np.ndarray, Dict[str, Any]]:
        """
        Multiply matrices using current topology's optimal method.
        
        Parameters
        ----------
        A, B : np.ndarray
            Matrices to multiply
            
        Returns
        -------
        C : np.ndarray
            Result matrix
        info : dict
            Performance info
        """
        n = A.shape[0]
        info = {'topology': self.current_topology}
        
        # Use topology-specific optimizations
        if self.current_topology == "penrose" and self.enable_experimental:
            # Use Penrose microkernel for potential speedup
            try:
                from .penrose_microkernel_v2 import multiply as penrose_multiply
                C, penrose_info = penrose_multiply(A, B, self.graph_laplacian)
                info.update(penrose_info)
                return C, info
            except ImportError:
                logger.warning("Penrose microkernel not available")
        
        # For other topologies or fallback, use standard multiplication
        # In a full implementation, we'd use Strassen for n >= 128
        info['method'] = 'numpy'
        return A @ B, info
    
    def get_swap_metrics(self) -> Dict[str, Any]:
        """Get metrics about topology swaps"""
        return {
            'current_topology': self.current_topology,
            'total_swaps': self.swap_count,
            'energy_harvested': self.energy_harvested_total,
            'swap_history': self.swap_history[-5:],  # Last 5 swaps
            'available_topologies': list(self.topologies.keys()),
            'current_properties': {
                'chern_number': self.topologies[self.current_topology].chern_number,
                'coordination': self.topologies[self.current_topology].coordination_number,
                'spectral_gap': self.topologies[self.current_topology].spectral_gap
            }
        }


# ════════════════════════════════════════════════════════════════════════
#  DEMO AND INTEGRATION
# ════════════════════════════════════════════════════════════════════════
async def demo_hot_swap():
    """Demonstrate hot-swap functionality"""
    print("Hot-Swappable Laplacian Demo")
    print("=" * 50)
    
    # Create minimal system
    hot_swap = HotSwappableLaplacian(enable_experimental=True)
    
    # Simulate high-energy scenario
    hot_swap.active_solitons = [
        {'amplitude': 10.0, 'phase': 0, 'topological_charge': 1},
        {'amplitude': 8.0, 'phase': np.pi/2, 'topological_charge': 1},
        {'amplitude': 12.0, 'phase': np.pi, 'topological_charge': -1}
    ]
    
    print(f"Initial topology: {hot_swap.current_topology}")
    print(f"Available topologies: {list(hot_swap.topologies.keys())}")
    
    # Perform a swap
    await hot_swap.hot_swap_laplacian_with_safety('honeycomb')
    
    # Check metrics
    metrics = hot_swap.get_swap_metrics()
    print(f"\nMetrics after swap:")
    print(f"  Current topology: {metrics['current_topology']}")
    print(f"  Total swaps: {metrics['total_swaps']}")
    print(f"  Energy harvested: {metrics['energy_harvested']:.2f}")
    
    # Recommend topology for specific problem
    recommendation = hot_swap.recommend_topology_for_problem('search')
    print(f"\nRecommended topology for 'search': {recommendation}")


if __name__ == "__main__":
    asyncio.run(demo_hot_swap())
