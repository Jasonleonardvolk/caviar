"""
FractalSolitonMemory - Enhanced Wave-Based Memory Lattice
Quantum soliton memory system with O(n^2.32) similarity operations and curvature integration
"""

import numpy as np
import asyncio
import json
import time
import logging
from typing import Dict, Any, List, Optional, Tuple, Union
from dataclasses import dataclass, field, asdict
from pathlib import Path
import pickle
import gzip
from concurrent.futures import ThreadPoolExecutor
import weakref

# Enhanced JIT compilation support
try:
    import numba
    from numba import jit, prange, types
    from numba.typed import Dict as NumbaDict
    NUMBA_AVAILABLE = True
except ImportError:
    NUMBA_AVAILABLE = False
    def jit(*args, **kwargs):
        def decorator(func):
            return func
        return decorator
    prange = range

logger = logging.getLogger(__name__)

# Phase integration support
try:
    from python.core.psi_phase_bridge import psi_phase_bridge
    PHASE_INTEGRATION_AVAILABLE = True
except ImportError:
    logger.warning("⚠️ Phase integration not available")
    PHASE_INTEGRATION_AVAILABLE = False

@dataclass
class SolitonWave:
    """Enhanced soliton wave with quantum properties"""
    id: str
    position: np.ndarray
    amplitude: float
    wavelength: float
    momentum: np.ndarray
    memory_content: Any
    embedding: Optional[np.ndarray] = None
    creation_time: float = field(default_factory=time.time)
    coherence: float = 1.0
    phase: float = 0.0
    phase_velocity: float = 0.0
    curvature_coupling: float = 1.0
    energy: float = 0.0
    stability_index: float = 1.0
    
    def __post_init__(self):
        """Calculate derived properties"""
        self.energy = self.amplitude ** 2 * self.wavelength
        if self.embedding is not None:
            self.stability_index = np.linalg.norm(self.embedding) / (np.linalg.norm(self.momentum) + 1e-8)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert wave to serializable dictionary"""
        wave_dict = asdict(self)
        
        # Handle numpy arrays
        if self.position is not None:
            wave_dict['position'] = self.position.tolist()
        if self.momentum is not None:
            wave_dict['momentum'] = self.momentum.tolist()
        if self.embedding is not None:
            wave_dict['embedding'] = self.embedding.tolist()
            
        return wave_dict
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SolitonWave':
        """Create wave from dictionary"""
        # Convert lists back to numpy arrays
        if 'position' in data and isinstance(data['position'], list):
            data['position'] = np.array(data['position'])
        if 'momentum' in data and isinstance(data['momentum'], list):
            data['momentum'] = np.array(data['momentum'])
        if 'embedding' in data and isinstance(data['embedding'], list):
            data['embedding'] = np.array(data['embedding'])
            
        return cls(**data)

# Optimized JIT functions
@jit(nopython=True, parallel=True, cache=True)
def update_quantum_lattice_jit(
    lattice_field: np.ndarray,
    phase_field: np.ndarray,
    curvature_field: np.ndarray,
    positions: np.ndarray,
    amplitudes: np.ndarray,
    wavelengths: np.ndarray,
    phases: np.ndarray,
    curvature_couplings: np.ndarray,
    lattice_size: int
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Optimized quantum lattice field update with parallel processing"""
    lattice_field.fill(0)
    phase_field.fill(0)
    curvature_field.fill(0)
    
    num_waves = len(positions)
    
    for i in prange(lattice_size):
        for j in prange(lattice_size):
            field_real = 0.0
            field_imag = 0.0
            phase_contrib = 0.0
            curvature_contrib = 0.0
            
            for w in range(num_waves):
                dx = i - positions[w, 0]
                dy = j - positions[w, 1]
                r_sq = dx * dx + dy * dy
                r = np.sqrt(r_sq)
                
                if r < 1e-10:
                    r = 1e-10
                
                wl = wavelengths[w]
                amp = amplitudes[w]
                phi = phases[w]
                curv_coup = curvature_couplings[w]
                
                # Gaussian envelope with exponential falloff
                envelope = amp * np.exp(-r_sq / (2 * wl * wl))
                
                # Geometric phase
                geo_phase = 2 * np.pi * r / wl
                total_phase = geo_phase + phi
                
                # Complex field contribution
                cos_phase = np.cos(total_phase)
                sin_phase = np.sin(total_phase)
                
                field_real += envelope * cos_phase
                field_imag += envelope * sin_phase
                phase_contrib += phi * envelope
                
                # Curvature field contribution
                if curv_coup > 0:
                    curvature_contrib += curv_coup * envelope * np.cos(2 * total_phase)
            
            lattice_field[i, j] = field_real + 1j * field_imag
            phase_field[i, j] = phase_contrib
            curvature_field[i, j] = curvature_contrib
    
    return lattice_field, phase_field, curvature_field

@jit(nopython=True, parallel=True, cache=True)
def compute_field_gradients_jit(
    phase_field: np.ndarray,
    curvature_field: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute phase and curvature gradients with boundary handling"""
    rows, cols = phase_field.shape
    phase_grad = np.zeros((rows, cols, 2))
    curvature_grad = np.zeros((rows, cols, 2))
    
    for i in prange(1, rows - 1):
        for j in prange(1, cols - 1):
            # Phase gradients (central difference)
            phase_grad[i, j, 0] = (phase_field[i+1, j] - phase_field[i-1, j]) * 0.5
            phase_grad[i, j, 1] = (phase_field[i, j+1] - phase_field[i, j-1]) * 0.5
            
            # Curvature gradients
            curvature_grad[i, j, 0] = (curvature_field[i+1, j] - curvature_field[i-1, j]) * 0.5
            curvature_grad[i, j, 1] = (curvature_field[i, j+1] - curvature_field[i, j-1]) * 0.5
    
    return phase_grad, curvature_grad

@jit(nopython=True, parallel=True, cache=True)
def evolve_soliton_dynamics_jit(
    positions: np.ndarray,
    momenta: np.ndarray,
    phases: np.ndarray,
    phase_velocities: np.ndarray,
    amplitudes: np.ndarray,
    coherences: np.ndarray,
    energies: np.ndarray,
    stability_indices: np.ndarray,
    curvature_couplings: np.ndarray,
    lattice_field: np.ndarray,
    phase_gradient: np.ndarray,
    curvature_gradient: np.ndarray,
    lattice_size: int,
    coupling_strength: float,
    dt: float,
    damping: float = 0.99
) -> None:
    """Advanced soliton dynamics with energy conservation and stability"""
    num_waves = len(positions)
    
    for idx in prange(num_waves):
        # Position evolution
        positions[idx] += momenta[idx] * dt
        
        # Periodic boundary conditions
        positions[idx, 0] = positions[idx, 0] % lattice_size
        positions[idx, 1] = positions[idx, 1] % lattice_size
        
        # Coherence decay with stability factor
        coherences[idx] *= (1.0 - (1.0 - damping) / stability_indices[idx])
        
        # Get lattice coordinates
        x = int(positions[idx, 0])
        y = int(positions[idx, 1])
        
        if 0 < x < lattice_size-1 and 0 < y < lattice_size-1:
            # Lattice field forces
            fx = np.real(lattice_field[x+1, y] - lattice_field[x-1, y]) * 0.5
            fy = np.real(lattice_field[x, y+1] - lattice_field[x, y-1]) * 0.5
            
            # Phase-driven forces
            phase_fx = -curvature_couplings[idx] * phase_gradient[x, y, 0]
            phase_fy = -curvature_couplings[idx] * phase_gradient[x, y, 1]
            
            # Curvature forces
            curv_fx = -curvature_gradient[x, y, 0] * amplitudes[idx]
            curv_fy = -curvature_gradient[x, y, 1] * amplitudes[idx]
            
            # Total force
            total_fx = coupling_strength * fx + phase_fx + curv_fx
            total_fy = coupling_strength * fy + phase_fy + curv_fy
            
            # Momentum update
            momenta[idx, 0] += total_fx * dt
            momenta[idx, 1] += total_fy * dt
            
            # Phase velocity from momentum-phase coupling
            phase_velocities[idx] = -(
                momenta[idx, 0] * phase_gradient[x, y, 0] +
                momenta[idx, 1] * phase_gradient[x, y, 1]
            ) * curvature_couplings[idx]
            
            # Phase evolution
            phases[idx] += phase_velocities[idx] * dt
            phases[idx] = np.arctan2(np.sin(phases[idx]), np.cos(phases[idx]))
            
            # Energy update
            kinetic = 0.5 * (momenta[idx, 0]**2 + momenta[idx, 1]**2)
            potential = amplitudes[idx]**2 * np.abs(lattice_field[x, y])**2
            energies[idx] = kinetic + potential
            
            # Stability index update
            momentum_norm = np.sqrt(momenta[idx, 0]**2 + momenta[idx, 1]**2)
            if momentum_norm > 1e-10:
                stability_indices[idx] = amplitudes[idx] / momentum_norm
            
            # Apply damping
            momenta[idx] *= damping

class FractalSolitonMemory:
    """Advanced quantum soliton memory system with enhanced performance"""
    
    _instances: Dict[str, 'FractalSolitonMemory'] = {}
    _lock = asyncio.Lock()
    
    @classmethod
    async def get_instance(cls, config: Dict[str, Any] = None, instance_id: str = "default"):
        """Thread-safe singleton with multiple named instances"""
        async with cls._lock:
            if instance_id not in cls._instances:
                cls._instances[instance_id] = cls(config or {}, instance_id)
            return cls._instances[instance_id]
    
    def __init__(self, config: Dict[str, Any], instance_id: str = "default"):
        self.instance_id = instance_id
        self.config = config
        
        # Core parameters
        self.lattice_size = config.get('lattice_size', 128)
        self.coupling_strength = config.get('coupling_strength', 0.1)
        self.damping_factor = config.get('damping_factor', 0.99)
        self.enable_penrose = config.get('enable_penrose', True)
        self.max_waves = config.get('max_waves', 1000)
        
        # Memory structures
        self.waves: Dict[str, SolitonWave] = {}
        self.wave_index: Dict[str, int] = {}
        
        # Quantum fields
        self._init_quantum_fields()
        
        # Performance optimizations
        self.executor = ThreadPoolExecutor(max_workers=config.get('num_threads', 4))
        self._evolution_task: Optional[asyncio.Task] = None
        self._is_evolving = False
        
        # External integrations
        self.penrose = None
        self.vault_bridge = None
        
        if self.enable_penrose:
            self._init_penrose()
        
        # Persistence
        self.data_file = Path(f"fractal_soliton_memory_{instance_id}.pkl.gz")
        self._auto_save_interval = config.get('auto_save_interval', 300)  # 5 minutes
        self._last_save = time.time()
        
        # Load existing state
        asyncio.create_task(self._load_state())
        
        logger.info(f"✅ FractalSolitonMemory '{instance_id}' initialized "
                   f"(lattice={self.lattice_size}x{self.lattice_size}, "
                   f"max_waves={self.max_waves})")
    
    def _init_quantum_fields(self):
        """Initialize quantum field arrays"""
        shape = (self.lattice_size, self.lattice_size)
        self.lattice_field = np.zeros(shape, dtype=np.complex128)
        self.phase_field = np.zeros(shape, dtype=np.float64)
        self.curvature_field = np.zeros(shape, dtype=np.float64)
        self.phase_gradient = np.zeros((*shape, 2), dtype=np.float64)
        self.curvature_gradient = np.zeros((*shape, 2), dtype=np.float64)
        
        # Field statistics for monitoring
        self.field_stats = {
            'energy': 0.0,
            'phase_coherence': 0.0,
            'curvature_strength': 0.0,
            'last_update': time.time()
        }
    
    def _init_penrose(self):
        """Initialize Penrose tensor acceleration"""
        try:
            from python.core.penrose_adapter import PenroseAdapter
            self.penrose = PenroseAdapter.get_instance()
            logger.info("✅ Penrose tensor acceleration enabled")
        except ImportError:
            logger.warning("⚠️ Penrose not available, using standard operations")
    
    def set_vault_bridge(self, vault):
        """Connect to unified memory vault"""
        self.vault_bridge = vault
        logger.info("✅ Connected to UnifiedMemoryVault")
    
    async def create_soliton(
        self,
        memory_id: str,
        content: Any,
        embedding: Optional[np.ndarray] = None,
        phase: Optional[float] = None,
        curvature: Optional[float] = None,
        wavelength: Optional[float] = None,
        amplitude: Optional[float] = None
    ) -> SolitonWave:
        """Create enhanced soliton wave with quantum properties"""
        
        # Check capacity
        if len(self.waves) >= self.max_waves:
            await self._evict_weakest_solitons(int(self.max_waves * 0.1))
        
        # Generate position and properties
        position = np.random.rand(2) * self.lattice_size
        
        if wavelength is None:
            content_hash = abs(hash(str(content)))
            wavelength = 8.0 + (content_hash % 16)
        
        if amplitude is None:
            amplitude = 0.3 + 0.7 * np.random.rand()
        
        momentum = np.random.randn(2) * 0.05
        
        # Phase calculation with curvature coupling (using colleague's approach)
        if phase is None:
            if curvature is not None:
                phase = np.angle(np.exp(1j * np.log(abs(curvature) + 1e-10)))
            else:
                phase = np.random.uniform(-np.pi, np.pi)
        
        # Create wave
        wave = SolitonWave(
            id=memory_id,
            position=position,
            amplitude=amplitude,
            wavelength=wavelength,
            momentum=momentum,
            memory_content=content,
            embedding=embedding,
            phase=phase,
            curvature_coupling=1.0 if curvature else 0.5
        )
        
        self.waves[memory_id] = wave
        self.wave_index[memory_id] = len(self.wave_index)
        
        # Update quantum fields
        await self._update_quantum_fields()
        
        # Phase integration (using colleague's pattern)
        if PHASE_INTEGRATION_AVAILABLE and phase is not None:
            asyncio.create_task(
                self._inject_phase_to_mesh(memory_id, phase, amplitude, curvature)
            )
        
        # Vault integration
        if self.vault_bridge:
            await self.vault_bridge.store_memory(
                memory_type="soliton",
                content=content,
                metadata={
                    "soliton_id": memory_id,
                    "wavelength": wavelength,
                    "phase": phase,
                    "amplitude": amplitude
                }
            )
        
        # Auto-save check
        await self._check_auto_save()
        
        return wave
    
    async def _update_quantum_fields(self):
        """Update quantum fields using optimized computation"""
        if not self.waves:
            return
        
        # Prepare wave data for JIT computation
        wave_data = list(self.waves.values())
        positions = np.array([w.position for w in wave_data])
        amplitudes = np.array([w.amplitude for w in wave_data])
        wavelengths = np.array([w.wavelength for w in wave_data])
        phases = np.array([w.phase for w in wave_data])
        curvature_couplings = np.array([w.curvature_coupling for w in wave_data])
        
        if NUMBA_AVAILABLE:
            # JIT-compiled field update
            self.lattice_field, self.phase_field, self.curvature_field = \
                await asyncio.get_event_loop().run_in_executor(
                    self.executor,
                    update_quantum_lattice_jit,
                    self.lattice_field, self.phase_field, self.curvature_field,
                    positions, amplitudes, wavelengths, phases,
                    curvature_couplings, self.lattice_size
                )
            
            # Compute gradients
            self.phase_gradient, self.curvature_gradient = \
                await asyncio.get_event_loop().run_in_executor(
                    self.executor,
                    compute_field_gradients_jit,
                    self.phase_field, self.curvature_field
                )
        else:
            # Fallback computation (using colleague's cleaner approach)
            await self._update_fields_fallback(
                positions, amplitudes, wavelengths, phases, curvature_couplings
            )
        
        # Update field statistics
        self._update_field_statistics()
    
    async def _update_fields_fallback(self, positions, amplitudes, wavelengths, phases, curvature_couplings):
        """Fallback field computation without JIT"""
        self.lattice_field.fill(0)
        self.phase_field.fill(0)
        self.curvature_field.fill(0)
        
        for i, (pos, amp, wl, phi, curv) in enumerate(
            zip(positions, amplitudes, wavelengths, phases, curvature_couplings)
        ):
            x, y = pos
            for gi in range(self.lattice_size):
                for gj in range(self.lattice_size):
                    dx, dy = gi - x, gj - y
                    r = np.sqrt(dx**2 + dy**2)
                    
                    envelope = amp * np.exp(-r**2 / (2 * wl**2))
                    geo_phase = 2 * np.pi * r / wl
                    total_phase = geo_phase + phi
                    
                    self.lattice_field[gi, gj] += envelope * np.exp(1j * total_phase)
                    self.phase_field[gi, gj] += phi * envelope
                    
                    if curv > 0:
                        self.curvature_field[gi, gj] += curv * envelope * np.cos(2 * total_phase)
    
    def _update_field_statistics(self):
        """Update field statistics for monitoring"""
        self.field_stats.update({
            'energy': float(np.sum(np.abs(self.lattice_field)**2)),
            'phase_coherence': float(np.std(self.phase_field)),
            'curvature_strength': float(np.max(np.abs(self.curvature_field))),
            'last_update': time.time()
        })
    
    async def inject_curvature_field(self, curvature_data: Dict[str, Union[np.ndarray, float]]):
        """
        Enhanced curvature field injection supporting encode_curvature_to_phase output
        
        Args:
            curvature_data: Dictionary containing curvature field data. Can include:
                - 'curvature_values': Kretschmann scalar curvature values
                - 'psi_phase': Phase field values
                - 'coordinates': Coordinate system information
                - 'region_sample': Spatial sampling information
                - 'tensor_components': Raw tensor components
                - 'metric_signature': Metric signature for proper field interpretation
        """
        try:
            from scipy.ndimage import zoom
            
            # Handle different input formats from encode_curvature_to_phase
            if 'curvature_values' in curvature_data:
                curvature = curvature_data['curvature_values']
                if isinstance(curvature, np.ndarray):
                    if curvature.shape != (self.lattice_size, self.lattice_size):
                        zoom_factors = (
                            self.lattice_size / curvature.shape[0],
                            self.lattice_size / curvature.shape[1]
                        )
                        curvature_resized = zoom(curvature, zoom_factors, order=1)
                        self.curvature_field += curvature_resized
                    else:
                        self.curvature_field += curvature
                    
                    logger.info(f"🌀 Injected curvature field: "
                              f"min={np.min(curvature):.6f}, max={np.max(curvature):.6f}")
                else:
                    # Scalar curvature value
                    self.curvature_field += float(curvature)
                    logger.info(f"🌀 Applied uniform curvature: {float(curvature):.6f}")
            
            if 'psi_phase' in curvature_data:
                phase = curvature_data['psi_phase']
                if isinstance(phase, np.ndarray):
                    if phase.shape != (self.lattice_size, self.lattice_size):
                        zoom_factors = (
                            self.lattice_size / phase.shape[0],
                            self.lattice_size / phase.shape[1]
                        )
                        phase_resized = zoom(phase, zoom_factors, order=1)
                        self.phase_field += phase_resized
                    else:
                        self.phase_field += phase
                    
                    logger.info(f"🌊 Injected phase field: "
                              f"range=[{np.min(phase):.3f}, {np.max(phase):.3f}]")
            
            # Handle advanced geometric data
            if 'tensor_components' in curvature_data:
                tensor_components = curvature_data['tensor_components']
                # Extract Ricci scalar or other curvature invariants
                if 'ricci_scalar' in tensor_components:
                    ricci = tensor_components['ricci_scalar']
                    if isinstance(ricci, np.ndarray):
                        ricci_normalized = np.tanh(ricci)  # Normalize for stability
                        if ricci.shape != (self.lattice_size, self.lattice_size):
                            zoom_factors = (
                                self.lattice_size / ricci.shape[0],
                                self.lattice_size / ricci.shape[1]
                            )
                            ricci_resized = zoom(ricci_normalized, zoom_factors, order=1)
                            self.curvature_field += 0.5 * ricci_resized  # Weight factor
                        else:
                            self.curvature_field += 0.5 * ricci_normalized
            
            # Handle coordinate and sampling information
            if 'coordinates' in curvature_data and 'region_sample' in curvature_data:
                coords = curvature_data['coordinates']
                region = curvature_data['region_sample']
                
                # Apply spatial weighting based on coordinate system
                if isinstance(coords, dict) and 'metric_det' in coords:
                    metric_det = coords['metric_det']
                    if isinstance(metric_det, np.ndarray):
                        # Use metric determinant to weight field contributions
                        weight_field = np.sqrt(np.abs(metric_det))
                        if weight_field.shape != (self.lattice_size, self.lattice_size):
                            zoom_factors = (
                                self.lattice_size / weight_field.shape[0],
                                self.lattice_size / weight_field.shape[1]
                            )
                            weight_resized = zoom(weight_field, zoom_factors, order=1)
                        else:
                            weight_resized = weight_field
                        
                        # Apply geometric weighting to existing fields
                        self.curvature_field *= (1.0 + 0.1 * weight_resized)
                        self.phase_field *= (1.0 + 0.05 * weight_resized)
            
            # Recompute gradients after field injection
            if NUMBA_AVAILABLE:
                self.phase_gradient, self.curvature_gradient = \
                    await asyncio.get_event_loop().run_in_executor(
                        self.executor,
                        compute_field_gradients_jit,
                        self.phase_field, self.curvature_field
                    )
            else:
                # Fallback gradient computation
                for i in range(1, self.lattice_size - 1):
                    for j in range(1, self.lattice_size - 1):
                        self.phase_gradient[i, j, 0] = (self.phase_field[i+1, j] - self.phase_field[i-1, j]) * 0.5
                        self.phase_gradient[i, j, 1] = (self.phase_field[i, j+1] - self.phase_field[i, j-1]) * 0.5
                        self.curvature_gradient[i, j, 0] = (self.curvature_field[i+1, j] - self.curvature_field[i-1, j]) * 0.5
                        self.curvature_gradient[i, j, 1] = (self.curvature_field[i, j+1] - self.curvature_field[i, j-1]) * 0.5
            
            # Update field statistics
            self._update_field_statistics()
            
            # Propagate changes to existing solitons
            for wave in self.waves.values():
                x, y = int(wave.position[0]), int(wave.position[1])
                if 0 <= x < self.lattice_size and 0 <= y < self.lattice_size:
                    # Couple soliton to local curvature
                    local_curvature = self.curvature_field[x, y]
                    wave.curvature_coupling = min(2.0, wave.curvature_coupling + 0.1 * abs(local_curvature))
                    
                    # Modify phase based on local field
                    local_phase = self.phase_field[x, y]
                    wave.phase += 0.01 * local_phase  # Small coupling
                    wave.phase = np.angle(np.exp(1j * wave.phase))  # Normalize to [-π, π]
            
            logger.info("✅ Enhanced curvature field injection complete")
            
        except ImportError:
            logger.warning("⚠️ scipy not available, using basic interpolation")
            # Basic fallback without scipy
            if 'curvature_values' in curvature_data:
                curvature = curvature_data['curvature_values']
                if isinstance(curvature, np.ndarray):
                    self.curvature_field += curvature
                else:
                    self.curvature_field += float(curvature)
            
        except Exception as e:
            logger.error(f"❌ Failed to inject curvature field: {e}")
            raise
    
    def reset(self):
        """Reset the memory system to initial state"""
        logger.info(f"🔄 Resetting FractalSolitonMemory '{self.instance_id}'")
        
        # Clear all waves and indices
        self.waves.clear()
        self.wave_index.clear()
        
        # Reset quantum fields
        self.lattice_field.fill(0)
        self.phase_field.fill(0)
        self.curvature_field.fill(0)
        self.phase_gradient.fill(0)
        self.curvature_gradient.fill(0)
        
        # Reset field statistics
        self.field_stats = {
            'energy': 0.0,
            'phase_coherence': 0.0,
            'curvature_strength': 0.0,
            'last_update': time.time()
        }
        
        logger.info("✅ Memory system reset complete")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the entire memory system to a serializable dictionary"""
        return {
            "instance_id": self.instance_id,
            "config": self.config,
            "lattice_size": self.lattice_size,
            "waves": {wave_id: wave.to_dict() for wave_id, wave in self.waves.items()},
            "wave_index": self.wave_index,
            "field_stats": self.field_stats,
            "quantum_fields": {
                "lattice_field": {
                    "real": np.real(self.lattice_field).tolist(),
                    "imag": np.imag(self.lattice_field).tolist()
                },
                "phase_field": self.phase_field.tolist(),
                "curvature_field": self.curvature_field.tolist(),
                "phase_gradient": self.phase_gradient.tolist(),
                "curvature_gradient": self.curvature_gradient.tolist()
            },
            "performance_flags": {
                "numba_available": NUMBA_AVAILABLE,
                "phase_integration": PHASE_INTEGRATION_AVAILABLE,
                "penrose_enabled": self.penrose is not None
            },
            "timestamp": time.time(),
            "version": "2.1"
        }
    
    @classmethod
    async def from_dict(cls, data: Dict[str, Any]) -> 'FractalSolitonMemory':
        """Create a FractalSolitonMemory instance from a dictionary"""
        instance_id = data.get("instance_id", "default")
        config = data.get("config", {})
        
        # Create new instance
        memory = cls(config, instance_id)
        
        # Restore waves
        if "waves" in data:
            memory.waves = {
                wave_id: SolitonWave.from_dict(wave_data)
                for wave_id, wave_data in data["waves"].items()
            }
        
        # Restore wave index
        if "wave_index" in data:
            memory.wave_index = data["wave_index"]
        
        # Restore field statistics
        if "field_stats" in data:
            memory.field_stats = data["field_stats"]
        
        # Restore quantum fields
        if "quantum_fields" in data:
            qf = data["quantum_fields"]
            
            if "lattice_field" in qf:
                lf = qf["lattice_field"]
                memory.lattice_field = np.array(lf["real"]) + 1j * np.array(lf["imag"])
            
            if "phase_field" in qf:
                memory.phase_field = np.array(qf["phase_field"])
            
            if "curvature_field" in qf:
                memory.curvature_field = np.array(qf["curvature_field"])
            
            if "phase_gradient" in qf:
                memory.phase_gradient = np.array(qf["phase_gradient"])
            
            if "curvature_gradient" in qf:
                memory.curvature_gradient = np.array(qf["curvature_gradient"])
        
        logger.info(f"✅ Restored FractalSolitonMemory from dict with {len(memory.waves)} waves")
        return memory
    
    async def evolve_system(self, dt: float = 0.1, steps: int = 1):
        """Evolve the quantum soliton system"""
        if not self.waves or self._is_evolving:
            return
        
        self._is_evolving = True
        
        try:
            for _ in range(steps):
                await self._single_evolution_step(dt)
        finally:
            self._is_evolving = False
    
    async def _single_evolution_step(self, dt: float):
        """Single evolution step with enhanced dynamics"""
        if not self.waves:
            return
        
        # Prepare wave data
        wave_ids = list(self.waves.keys())
        wave_data = list(self.waves.values())
        
        positions = np.array([w.position for w in wave_data])
        momenta = np.array([w.momentum for w in wave_data])
        phases = np.array([w.phase for w in wave_data])
        phase_velocities = np.array([w.phase_velocity for w in wave_data])
        amplitudes = np.array([w.amplitude for w in wave_data])
        coherences = np.array([w.coherence for w in wave_data])
        energies = np.array([w.energy for w in wave_data])
        stability_indices = np.array([w.stability_index for w in wave_data])
        curvature_couplings = np.array([w.curvature_coupling for w in wave_data])
        
        if NUMBA_AVAILABLE:
            # JIT-compiled evolution
            await asyncio.get_event_loop().run_in_executor(
                self.executor,
                evolve_soliton_dynamics_jit,
                positions, momenta, phases, phase_velocities,
                amplitudes, coherences, energies, stability_indices,
                curvature_couplings, self.lattice_field,
                self.phase_gradient, self.curvature_gradient,
                self.lattice_size, self.coupling_strength, dt, self.damping_factor
            )
        else:
            # Fallback evolution
            await self._evolve_fallback(wave_data, dt)
        
        # Update wave objects
        for i, wave_id in enumerate(wave_ids):
            w = self.waves[wave_id]
            w.position = positions[i]
            w.momentum = momenta[i]
            w.phase = phases[i]
            w.phase_velocity = phase_velocities[i]
            w.coherence = coherences[i]
            w.energy = energies[i]
            w.stability_index = stability_indices[i]
        
        # Update quantum fields
        await self._update_quantum_fields()
        
        # Phase propagation
        if PHASE_INTEGRATION_AVAILABLE:
            await self._propagate_phase_changes()
    
    async def _evolve_fallback(self, wave_data, dt):
        """Fallback evolution without JIT"""
        for w in wave_data:
            # Basic position and momentum evolution
            w.position += w.momentum * dt
            w.position %= self.lattice_size
            w.coherence *= self.damping_factor
            
            # Simple force calculation
            x, y = int(w.position[0]), int(w.position[1])
            if 0 < x < self.lattice_size-1 and 0 < y < self.lattice_size-1:
                fx = np.real(self.lattice_field[x+1, y] - self.lattice_field[x-1, y])
                fy = np.real(self.lattice_field[x, y+1] - self.lattice_field[x, y-1])
                
                w.momentum[0] += self.coupling_strength * fx * dt
                w.momentum[1] += self.coupling_strength * fy * dt
                w.momentum *= self.damping_factor
    
    async def find_resonant_memories(
        self,
        query_embedding: np.ndarray,
        k: int = 5,
        coherence_threshold: float = 0.1,
        energy_weight: float = 0.2
    ) -> List[Tuple[str, float, Dict[str, Any]]]:
        """Enhanced resonant memory search with quantum properties"""
        if not self.waves:
            return []
        
        # Filter by coherence threshold
        valid_waves = {
            wave_id: wave for wave_id, wave in self.waves.items()
            if wave.embedding is not None and wave.coherence > coherence_threshold
        }
        
        if not valid_waves:
            return []
        
        wave_ids = list(valid_waves.keys())
        embeddings = np.array([valid_waves[wid].embedding for wid in wave_ids])
        
        # Compute similarities
        if self.penrose and len(embeddings) > 10:
            # Use Penrose tensor for large matrices
            full_matrix = np.vstack([query_embedding.reshape(1, -1), embeddings])
            similarity_matrix = await asyncio.get_event_loop().run_in_executor(
                self.executor,
                self.penrose.similarity_matrix,
                full_matrix
            )
            similarities = similarity_matrix[0, 1:]
        else:
            # Standard cosine similarity (using colleague's pattern)
            q_norm = query_embedding / (np.linalg.norm(query_embedding) + 1e-8)
            e_norm = embeddings / (np.linalg.norm(embeddings, axis=1, keepdims=True) + 1e-8)
            similarities = e_norm @ q_norm
        
        # Enhanced scoring with quantum properties
        scored_results = []
        current_time = time.time()
        
        for i, (wave_id, similarity) in enumerate(zip(wave_ids, similarities)):
            wave = valid_waves[wave_id]
            
            # Time decay (using colleague's approach)
            age_factor = np.exp(-0.1 * (current_time - wave.creation_time) / 3600)
            
            # Quantum factors
            coherence_factor = wave.coherence
            energy_factor = np.tanh(wave.energy) if energy_weight > 0 else 1.0
            stability_factor = np.tanh(wave.stability_index)
            
            # Combined score
            quantum_score = (
                similarity * coherence_factor * age_factor * stability_factor +
                energy_weight * energy_factor
            )
            
            # Metadata
            metadata = {
                'coherence': float(wave.coherence),
                'energy': float(wave.energy),
                'stability': float(wave.stability_index),
                'phase': float(wave.phase),
                'amplitude': float(wave.amplitude),
                'age_hours': (current_time - wave.creation_time) / 3600
            }
            
            scored_results.append((wave_id, float(quantum_score), metadata))
        
        # Sort and return top k
        scored_results.sort(key=lambda x: x[1], reverse=True)
        return scored_results[:k]
    
    async def _evict_weakest_solitons(self, num_to_evict: int):
        """Evict weakest solitons to maintain capacity"""
        if len(self.waves) <= num_to_evict:
            return
        
        # Score waves by weakness (low coherence, low energy, old age)
        current_time = time.time()
        weakness_scores = []
        
        for wave_id, wave in self.waves.items():
            age_penalty = (current_time - wave.creation_time) / 3600  # Hours
            weakness = (
                (1.0 - wave.coherence) * 2.0 +
                (1.0 / (wave.energy + 1e-6)) +
                age_penalty * 0.1
            )
            weakness_scores.append((wave_id, weakness))
        
        # Sort by weakness (highest first) and evict
        weakness_scores.sort(key=lambda x: x[1], reverse=True)
        
        for wave_id, _ in weakness_scores[:num_to_evict]:
            del self.waves[wave_id]
            if wave_id in self.wave_index:
                del self.wave_index[wave_id]
        
        logger.info(f"🗑️ Evicted {num_to_evict} weak solitons")
    
    async def _inject_phase_to_mesh(
        self,
        memory_id: str,
        phase: float,
        amplitude: float,
        curvature: Optional[float]
    ):
        """Inject phase modulation to external mesh (using colleague's approach)"""
        try:
            await psi_phase_bridge.inject_phase_modulation(memory_id, {
                'phase_value': phase,
                'amplitude_value': amplitude,
                'curvature_value': curvature,
                'source': f'fractal_soliton_memory_{self.instance_id}',
                'timestamp': time.time()
            })
            logger.debug(f"🌀 Injected phase φ={phase:.3f} into ψ-mesh for {memory_id}")
        except Exception as e:
            logger.error(f"❌ Failed to inject phase: {e}")
    
    async def _propagate_phase_changes(self):
        """Propagate significant phase changes to external systems"""
        significant_changes = [
            (wave_id, wave) for wave_id, wave in self.waves.items()
            if abs(wave.phase_velocity) > 0.05
        ]
        
        if significant_changes:
            tasks = [
                self._inject_phase_to_mesh(
                    wave_id, wave.phase, wave.amplitude, None
                )
                for wave_id, wave in significant_changes
            ]
            await asyncio.gather(*tasks, return_exceptions=True)
    
    async def _check_auto_save(self):
        """Check if auto-save is needed"""
        if time.time() - self._last_save > self._auto_save_interval:
            await self._save_state()
    
    async def _save_state(self):
        """Save current state to disk (using colleague's compression approach)"""
        try:
            state_data = {
                "waves": self.waves,
                "config": self.config,
                "field_stats": self.field_stats,
                "instance_id": self.instance_id,
                "timestamp": time.time(),
                "version": "2.1"
            }
            
            await asyncio.get_event_loop().run_in_executor(
                self.executor,
                self._save_compressed,
                state_data
            )
            
            self._last_save = time.time()
            logger.debug(f"💾 Saved {len(self.waves)} soliton waves")
            
        except Exception as e:
            logger.error(f"❌ Failed to save soliton memory: {e}")
    
    def _save_compressed(self, state_data):
        """Compressed save operation"""
        with gzip.open(self.data_file, 'wb') as f:
            pickle.dump(state_data, f, protocol=pickle.HIGHEST_PROTOCOL)
    
    async def _load_state(self):
        """Load state from disk"""
        try:
            if self.data_file.exists():
                state_data = await asyncio.get_event_loop().run_in_executor(
                    self.executor,
                    self._load_compressed
                )
                
                if state_data:
                    self.waves = state_data.get("waves", {})
                    self.field_stats = state_data.get("field_stats", {})
                    
                    # Rebuild wave index
                    self.wave_index = {
                        wave_id: i for i, wave_id in enumerate(self.waves.keys())
                    }
                    
                    await self._update_quantum_fields()
                    logger.info(f"✅ Loaded {len(self.waves)} soliton waves")
                    
        except Exception as e:
            logger.error(f"❌ Failed to load soliton memory: {e}")
    
    def _load_compressed(self):
        """Compressed load operation"""
        try:
            with gzip.open(self.data_file, 'rb') as f:
                return pickle.load(f)
        except:
            return None
    
    def get_system_diagnostics(self) -> Dict[str, Any]:
        """Get comprehensive system diagnostics"""
        if not self.waves:
            return {"status": "empty", "num_waves": 0}
        
        wave_stats = {
            "coherence": [w.coherence for w in self.waves.values()],
            "energy": [w.energy for w in self.waves.values()],
            "stability": [w.stability_index for w in self.waves.values()],
            "age": [(time.time() - w.creation_time)/3600 for w in self.waves.values()]
        }
        
        return {
            "status": "active",
            "instance_id": self.instance_id,
            "num_waves": len(self.waves),
            "lattice_size": self.lattice_size,
            "field_energy": self.field_stats.get('energy', 0),
            "phase_coherence": self.field_stats.get('phase_coherence', 0),
            "curvature_strength": self.field_stats.get('curvature_strength', 0),
            "wave_statistics": {
                "avg_coherence": np.mean(wave_stats["coherence"]),
                "avg_energy": np.mean(wave_stats["energy"]),
                "avg_stability": np.mean(wave_stats["stability"]),
                "avg_age_hours": np.mean(wave_stats["age"]),
                "coherence_std": np.std(wave_stats["coherence"]),
                "energy_range": [np.min(wave_stats["energy"]), np.max(wave_stats["energy"])],
            },
            "performance": {
                "numba_available": NUMBA_AVAILABLE,
                "phase_integration": PHASE_INTEGRATION_AVAILABLE,
                "penrose_enabled": self.penrose is not None,
                "evolution_active": self._is_evolving
            },
            "last_save": self._last_save,
            "memory_usage_mb": len(pickle.dumps(self.waves)) / (1024 * 1024)
        }
    
    def get_visualization_data(self) -> Dict[str, Any]:
        """Get data for quantum field visualization"""
        return {
            "lattice_size": self.lattice_size,
            "amplitude_field": np.abs(self.lattice_field).tolist(),
            "phase_field": self.phase_field.tolist(),
            "curvature_field": self.curvature_field.tolist(),
            "phase_gradient_magnitude": np.linalg.norm(self.phase_gradient, axis=2).tolist(),
            "curvature_gradient_magnitude": np.linalg.norm(self.curvature_gradient, axis=2).tolist(),
            "soliton_positions": {
                wave_id: {
                    "x": float(wave.position[0]),
                    "y": float(wave.position[1]),
                    "phase": float(wave.phase),
                    "amplitude": float(wave.amplitude),
                    "coherence": float(wave.coherence),
                    "energy": float(wave.energy),
                    "stability": float(wave.stability_index)
                }
                for wave_id, wave in self.waves.items()
            },
            "field_stats": self.field_stats
        }
    
    async def start_continuous_evolution(self, dt: float = 0.1, update_interval: float = 1.0):
        """Start continuous system evolution"""
        if self._evolution_task and not self._evolution_task.done():
            logger.warning("⚠️ Evolution already running")
            return
        
        async def evolution_loop():
            while True:
                try:
                    await self.evolve_system(dt, steps=int(update_interval/dt))
                    await asyncio.sleep(update_interval)
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"❌ Evolution error: {e}")
                    await asyncio.sleep(1.0)
        
        self._evolution_task = asyncio.create_task(evolution_loop())
        logger.info("🚀 Started continuous evolution")
    
    async def stop_continuous_evolution(self):
        """Stop continuous system evolution"""
        if self._evolution_task and not self._evolution_task.done():
            self._evolution_task.cancel()
            try:
                await self._evolution_task
            except asyncio.CancelledError:
                pass
            logger.info("🛑 Stopped continuous evolution")
    
    async def shutdown(self):
        """Graceful shutdown with state preservation"""
        logger.info(f"🧵 Shutting down FractalSolitonMemory '{self.instance_id}'")
        
        # Stop evolution
        await self.stop_continuous_evolution()
        
        # Save state
        await self._save_state()
        
        # Cleanup resources
        self.executor.shutdown(wait=True)
        
        # Remove from instances
        if self.instance_id in self._instances:
            del self._instances[self.instance_id]
        
        logger.info("✅ FractalSolitonMemory shutdown complete")

# Factory function for easy instantiation
async def create_fractal_soliton_memory(
    config: Optional[Dict[str, Any]] = None,
    instance_id: str = "default"
) -> FractalSolitonMemory:
    """Factory function to create FractalSolitonMemory instance"""
    default_config = {
        'lattice_size': 128,
        'coupling_strength': 0.1,
        'damping_factor': 0.995,
        'enable_penrose': True,
        'max_waves': 1000,
        'num_threads': 4,
        'auto_save_interval': 300
    }
    
    if config:
        default_config.update(config)
    
    return await FractalSolitonMemory.get_instance(default_config, instance_id)