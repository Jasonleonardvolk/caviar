#!/usr/bin/env python3
"""
Async background task that ticks the global OscillatorLattice every Δt.
"""
import asyncio
import time
import logging
from python.core.oscillator_lattice import get_global_lattice

logger = logging.getLogger(__name__)

# Phase 7: Import lattice subscription for concept events
try:
    from python.core.lattice_evolution_subscriber import setup_lattice_subscription, oscillator_count
    PHASE7_AVAILABLE = True
except ImportError as e:
    logger.warning(f"Phase 7 lattice subscription not available: {e}")
    PHASE7_AVAILABLE = False
    oscillator_count = 0

DT = 0.05        # 50 ms step
LOG_PERIOD = 5   # seconds


# Global shutdown event
shutdown_event = asyncio.Event()

def request_shutdown():
    """Request a graceful shutdown of the lattice runner"""
    logger.info("Lattice evolution shutdown requested")
    shutdown_event.set()

async def run_forever() -> None:
    """Run the oscillator lattice evolution loop until shutdown is requested."""
    lattice = get_global_lattice()
    last_log = time.time()
    
    logger.info("Starting oscillator lattice evolution runner")
    
    # Phase 7: Setup concept event subscription
    if PHASE7_AVAILABLE:
        setup_lattice_subscription()
        logger.info("Phase 7: Lattice subscribed to concept events")
    
    try:
        while not shutdown_event.is_set():
            # Step the lattice dynamics
            lattice.step(DT)
            
            # Periodic logging
            now = time.time()
            if now - last_log >= LOG_PERIOD:
                R = lattice.order_parameter()
                H = lattice.phase_entropy()
                N = len(lattice.oscillators)
                
                # Phase 7: Include concept-driven oscillator count
                if PHASE7_AVAILABLE:
                    from python.core.lattice_evolution_subscriber import oscillator_count as concept_count
                    # Only log if there are oscillators or significant activity
                    if N > 0 or concept_count > 0 or R > 0.001:
                        logger.info(f"[lattice] oscillators={N} concept_oscillators={concept_count} R={R:.3f} H={R:.3f}")
                        print(f"[lattice] oscillators={N} concept_oscillators={concept_count} R={R:.3f} H={H:.3f}")
                else:
                    # Only log if there are oscillators or significant activity
                    if N > 0 or R > 0.001:
                        logger.info(f"[lattice] oscillators={N} R={R:.3f} H={H:.3f}")
                        print(f"[lattice] oscillators={N} R={R:.3f} H={H:.3f}")
                
                last_log = now
            
            # Use wait_for to allow checking shutdown_event periodically
            try:
                await asyncio.wait_for(shutdown_event.wait(), timeout=DT)
                break  # Shutdown requested
            except asyncio.TimeoutError:
                pass  # Continue running
                
    except asyncio.CancelledError:
        logger.info("Lattice evolution runner cancelled")
    finally:
        logger.info("Lattice evolution runner stopped")


if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Run the evolution loop
    asyncio.run(run_forever())
