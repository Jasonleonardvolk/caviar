"""
Unified Penrose adapter for TORI components
"""
import numpy as np
from typing import List, Union, Optional, Dict, Any
import logging
import time
from pathlib import Path
import sys

logger = logging.getLogger(__name__)

class PenroseAdapter:
    """Single entry point for Penrose operations across TORI"""
    
    _instance = None
    
    @classmethod
    def get_instance(cls, rank: int = 32, embedding_dim: int = 768):
        if cls._instance is None:
            cls._instance = cls(rank, embedding_dim)
        return cls._instance
    
    def __init__(self, rank: int = 32, embedding_dim: int = 768):
        self.rank = rank
        self.embedding_dim = embedding_dim
        self.projector = None
        self.backend = None
        self._init_projector()
    
    def _init_projector(self):
        """Initialize Penrose projector"""
        # Try to import Penrose from multiple possible locations
        
        # Method 1: Try the Rust backend first (PRIORITY)
        try:
            import penrose_engine_rs
            self.projector = penrose_engine_rs
            self.backend = "rust"
            logger.info(f"✅ Penrose Rust backend loaded successfully (rank={self.rank})")
            return
        except ImportError:
            pass
        
        # Method 2: Try through concept_mesh.similarity (which handles Rust/Python fallback)
        try:
            from concept_mesh import similarity
            self.projector = similarity.penrose
            self.backend = similarity.BACKEND
            logger.info(f"✅ Penrose initialized via concept_mesh ({self.backend} backend, rank={self.rank})")
            return
        except ImportError:
            pass
        
        # Method 3: Try the accelerated PenroseProjector
        try:
            from penrose_projector import PenroseProjector
            self.projector = PenroseProjector(rank=self.rank, threshold=0.7)
            self.backend = "python-accelerated"
            logger.info(f"✅ Initialized accelerated Penrose projector (O(n^2.32), rank={self.rank})")
            return
        except ImportError:
            pass
        
        # Method 4: Add root to path and try again
        try:
            root_path = Path(__file__).parent.parent.parent
            if str(root_path) not in sys.path:
                sys.path.insert(0, str(root_path))
            from penrose_projector import PenroseProjector
            self.projector = PenroseProjector(rank=self.rank, threshold=0.7)
            self.backend = "python-accelerated"
            logger.info(f"✅ Initialized accelerated Penrose projector from root (O(n^2.32), rank={self.rank})")
            return
        except ImportError:
            pass
        
        # Method 5: Try basic PenroseEngine as fallback
        try:
            from penrose_projector import PenroseEngine
            self.projector = PenroseEngine()
            self.backend = "python-basic"
            logger.warning("⚠️ Using basic Penrose engine (fallback mode, not accelerated)")
            return
        except ImportError:
            pass
        
        # Method 6: Try the microkernel version
        try:
            from python.core.penrose_microkernel_v2 import PenroseProjector
            self.projector = PenroseProjector(
                n=self.embedding_dim,
                rank=self.rank,
                topology='kagome'  # Best performing
            )
            self.backend = "python-microkernel"
            logger.info(f"✅ Penrose microkernel initialized (rank={self.rank}, ω≈2.32)")
            return
        except ImportError:
            pass
        
        # If all imports fail, use fallback
        logger.warning("⚠️ Penrose not available, operations will fall back to cosine similarity")
        self.projector = None
        self.backend = "cosine-fallback"
    
    def similarity_matrix(self, embeddings: np.ndarray) -> np.ndarray:
        """Compute similarity matrix with O(n^2.32) complexity"""
        if self.projector is None:
            # Fallback to standard cosine similarity
            return self._cosine_similarity_matrix(embeddings)
        
        # Handle Rust backend
        if self.backend == "rust" and hasattr(self.projector, 'compute_similarity_matrix'):
            # Use Rust backend's matrix computation
            return self.projector.compute_similarity_matrix(embeddings)
        
        # Check if we have the accelerated projector
        if hasattr(self.projector, 'project_sparse'):
            # Use the accelerated O(n^2.32) implementation!
            sparse_sim, stats = self.projector.project_sparse(embeddings, return_stats=True)
            
            # Log performance stats
            if stats:
                logger.info(f"⚡ Penrose stats: {stats['n_edges']} edges, "
                          f"{stats['density_pct']:.2f}% density, "
                          f"{stats['speedup_vs_full']:.1f}x speedup")
            
            # Convert sparse matrix to dense for compatibility
            return sparse_sim.toarray()
        
        # Check which type of projector we have
        elif hasattr(self.projector, 'batch_similarity'):
            # Use basic Penrose engine
            if hasattr(embeddings, 'shape') and len(embeddings.shape) == 2:
                # Convert to list of vectors for batch_similarity
                vectors = [embeddings[i] for i in range(embeddings.shape[0])]
                n = len(vectors)
                sim_matrix = np.zeros((n, n))
                for i in range(n):
                    results = self.projector.batch_similarity(vectors[i], vectors)
                    for idx, sim in results:
                        sim_matrix[i, idx] = sim
                return sim_matrix
            else:
                return self.projector.batch_similarity(embeddings)
        else:
            # For compute_similarity interface
            n = embeddings.shape[0]
            sim_matrix = np.zeros((n, n))
            for i in range(n):
                for j in range(n):
                    sim_matrix[i, j] = self.projector.compute_similarity(embeddings[i], embeddings[j])
            return sim_matrix
    
    def _cosine_similarity_matrix(self, embeddings: np.ndarray) -> np.ndarray:
        """Standard O(n²) cosine similarity fallback"""
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        embeddings_normalized = embeddings / (norms + 1e-8)
        return embeddings_normalized @ embeddings_normalized.T
    
    def get_sparse_similarity(self, embeddings: np.ndarray, threshold: float = 0.7) -> Any:
        """Get sparse similarity matrix directly (for advanced usage)"""
        if hasattr(self.projector, 'project_sparse'):
            return self.projector.project_sparse(embeddings, return_stats=True)
        else:
            # Fallback: compute dense then sparsify
            dense_sim = self.similarity_matrix(embeddings)
            dense_sim[dense_sim < threshold] = 0
            from scipy.sparse import csr_matrix
            return csr_matrix(dense_sim), {"fallback": True}
