# Replace the old file with this fixed version
python run_legendary_test.py