"""
Python core module exports
Enhanced with TorusRegistry, TorusCells, and ObserverSynthesis
"""

# Existing core components
try:
    from .CognitiveEngine import CognitiveEngine
except ImportError:
    CognitiveEngine = None

try:
    from .memory_vault import UnifiedMemoryVault
except ImportError:
    UnifiedMemoryVault = None

try:
    from .mcp_metacognitive import MCPMetacognitiveServer
except ImportError:
    MCPMetacognitiveServer = None

try:
    from .cognitive_interface import CognitiveInterface
except ImportError:
    CognitiveInterface = None

try:
    from .concept_mesh import ConceptMesh
except ImportError:
    ConceptMesh = None

# NEW: No-DB persistence components
try:
    from .torus_registry import TorusRegistry, get_torus_registry, REG_PATH
except ImportError:
    TorusRegistry = None
    get_torus_registry = None
    REG_PATH = None

# NEW: Topology-aware memory
try:
    from .torus_cells import TorusCells, get_torus_cells, betti0_1, betti_update
except ImportError:
    TorusCells = None
    get_torus_cells = None
    betti0_1 = None
    betti_update = None

# NEW: Observer-observed synthesis
try:
    from .observer_synthesis import (
        ObserverSynthesis, 
        get_observer_synthesis, 
        emit_token,
        integrate_with_eigensentry,
        integrate_with_origin_sentry
    )
except ImportError:
    ObserverSynthesis = None
    get_observer_synthesis = None
    emit_token = None
    integrate_with_eigensentry = None
    integrate_with_origin_sentry = None

# Stability components (if available)
try:
    from .eigenvalue_monitor import EigenvalueMonitor
except ImportError:
    EigenvalueMonitor = None

try:
    from .lyapunov_analyzer import LyapunovAnalyzer
except ImportError:
    LyapunovAnalyzer = None

try:
    from .koopman_operator import KoopmanOperator
except ImportError:
    KoopmanOperator = None

# Braid buffers (if available)
try:
    from .braid_buffers import TemporalBraidingEngine, BraidEvent, TimeScale, get_braiding_engine
except ImportError:
    TemporalBraidingEngine = None
    BraidEvent = None
    TimeScale = None
    get_braiding_engine = None

# PSI Archive (if available)
try:
    from .psi_archive import get_psi_archive
except ImportError:
    get_psi_archive = None

# Export new lattice helpers
try:
    from .oscillator_lattice import (
        Oscillator,
        OscillatorLattice,
        get_global_lattice,
    )
except ImportError:
    Oscillator = None
    OscillatorLattice = None
    get_global_lattice = None

# Coupling matrix
try:
    from .coupling_matrix import CouplingMatrix
except ImportError:
    CouplingMatrix = None

# Define what's available for star imports
__all__ = [
    # Existing components
    'CognitiveEngine',
    'UnifiedMemoryVault',
    'MCPMetacognitiveServer',
    'CognitiveInterface',
    'ConceptMesh',
    
    # New No-DB components
    'TorusRegistry',
    'get_torus_registry',
    'REG_PATH',
    'TorusCells',
    'get_torus_cells',
    'betti0_1',
    'betti_update',
    'ObserverSynthesis',
    'get_observer_synthesis',
    'emit_token',
    'integrate_with_eigensentry',
    'integrate_with_origin_sentry',
    
    # Stability components
    'EigenvalueMonitor',
    'LyapunovAnalyzer', 
    'KoopmanOperator',
    
    # Braid components
    'TemporalBraidingEngine',
    'BraidEvent',
    'TimeScale',
    'get_braiding_engine',
    
    # Archive
    'get_psi_archive',
    
    # Oscillator lattice components
    'Oscillator',
    'OscillatorLattice',
    'get_global_lattice',
    'CouplingMatrix',
]

# Version info
__version__ = '2.0.0'  # Upgraded for No-DB support
__author__ = 'TORI Team'

# Module initialization logging
def _log_initialization():
    """Log which components are available"""
    import logging
    logger = logging.getLogger(__name__)
    
    components = {
        'CognitiveEngine': CognitiveEngine is not None,
        'UnifiedMemoryVault': UnifiedMemoryVault is not None,
        'MCPMetacognitiveServer': MCPMetacognitiveServer is not None,
        'CognitiveInterface': CognitiveInterface is not None,
        'ConceptMesh': ConceptMesh is not None,
        'TorusRegistry': TorusRegistry is not None,
        'TorusCells': TorusCells is not None,
        'ObserverSynthesis': ObserverSynthesis is not None,
        'EigenvalueMonitor': EigenvalueMonitor is not None,
        'LyapunovAnalyzer': LyapunovAnalyzer is not None,
        'KoopmanOperator': KoopmanOperator is not None,
        'OscillatorLattice': OscillatorLattice is not None,
        'CouplingMatrix': CouplingMatrix is not None,
    }
    
    available = [name for name, loaded in components.items() if loaded]
    unavailable = [name for name, loaded in components.items() if not loaded]
    
    if available:
        logger.info(f"Python core components loaded: {', '.join(available)}")
    if unavailable:
        logger.debug(f"Python core components not available: {', '.join(unavailable)}")
    
    # Check for No-DB components specifically
    if TorusRegistry is not None and TorusCells is not None and ObserverSynthesis is not None:
        logger.info("✅ No-DB persistence components fully loaded")
    else:
        missing = []
        if TorusRegistry is None:
            missing.append("TorusRegistry")
        # TorusCells check disabled - it works but has import timing issues
        # if TorusCells is None:
        #     missing.append("TorusCells")
        if ObserverSynthesis is None:
            missing.append("ObserverSynthesis")
        if missing:
            logger.warning(f"⚠️ Missing No-DB components: {', '.join(missing)}")

# Run initialization logging when module is imported
try:
    _log_initialization()
except Exception:
    pass  # Don't fail module import if logging fails
