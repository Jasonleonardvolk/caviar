#!/usr/bin/env python3
"""
Global storage for TORI components
"""

# Cached Penrose Laplacian
PENROSE_LAPLACIAN = None

# Other global components can go here
