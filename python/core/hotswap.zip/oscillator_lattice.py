#!/usr/bin/env python3
"""
Oscillator Lattice – dynamic phase-tagged memory core
Implements a light Kuramoto-style update plus hooks for Hebbian coupling.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Sequence
import numpy as np
import math
import logging

logger = logging.getLogger(__name__)
PI2 = 2.0 * math.pi


from enum import Enum

# Import adaptive timestep control
try:
    from python.core.adaptive_timestep import AdaptiveTimestep
    ADAPTIVE_DT_AVAILABLE = True
except ImportError:
    ADAPTIVE_DT_AVAILABLE = False

# Import Lyapunov monitoring
try:
    from alan_backend.lyap_exporter import get_lyapunov_exporter
    LYAP_AVAILABLE = True
except ImportError:
    LYAP_AVAILABLE = False

class SolitonPolarity(Enum):
    """Polarity for soliton types"""
    BRIGHT = "bright"  # Positive amplitude peak
    DARK = "dark"      # Negative amplitude dip

@dataclass
class Oscillator:
    """Single phase oscillator representing a stored memory."""
    phase: float                    # rad
    natural_freq: float             # rad/s
    amplitude: float = 1.0
    stability: float = 1.0
    polarity: SolitonPolarity = SolitonPolarity.BRIGHT  # Support dark solitons
    
    def step(self, dt: float, coupling_term: float) -> None:
        """Advance phase by dt with an external coupling contribution."""
        # Sign-safe update for dark solitons
        if self.polarity == SolitonPolarity.DARK:
            # Dark solitons have inverted coupling response
            effective_coupling = -coupling_term * abs(self.amplitude)
        else:
            effective_coupling = coupling_term * self.amplitude
            
        self.phase += (self.natural_freq + effective_coupling) * dt
        self.phase %= PI2  # keep phase in [0, 2π)


@dataclass
class OscillatorLattice:
    """Collection of oscillators + coupling matrix K_ij."""
    oscillators: List[Oscillator] = field(default_factory=list)
    K: Optional[np.ndarray] = None  # shape = (N, N)
    
    # Adaptive timestep control
    adaptive_dt: Optional[AdaptiveTimestep] = None
    use_adaptive_dt: bool = True
    _steps_counter: int = 0
    _lyap_update_interval: int = 256  # Update Lyapunov every N steps
    
    def _ensure_K(self) -> None:
        n = len(self.oscillators)
        if self.K is None or self.K.shape != (n, n):
            self.K = np.zeros((n, n), dtype=np.float32)
    
    # ---------- public API ---------- #
    def add_oscillator(self,
                       phase: float,
                       natural_freq: float = 0.0,
                       amplitude: float = 1.0,
                       stability: float = 1.0,
                       polarity: SolitonPolarity = SolitonPolarity.BRIGHT) -> int:
        """Append a new oscillator; return its index."""
        self.oscillators.append(
            Oscillator(phase, natural_freq, amplitude, stability, polarity)
        )
        self._ensure_K()
        return len(self.oscillators) - 1
    
    def remove_oscillator(self, idx: int) -> bool:
        """Remove oscillator and shrink coupling matrix - FUSION PURGE FIX"""
        if idx < 0 or idx >= len(self.oscillators):
            logger.warning(f"Cannot remove oscillator {idx}: index out of range")
            return False
        
        # Remove the oscillator
        removed_osc = self.oscillators.pop(idx)
        logger.info(f"Removed oscillator {idx} (phase={removed_osc.phase:.2f}, polarity={removed_osc.polarity})")
        
        # Shrink the coupling matrix by removing row and column
        if self.K is not None and self.K.shape[0] > idx:
            # Create new matrix without the removed row/column
            N = len(self.oscillators)  # New size
            if N > 0:
                new_K = np.zeros((N, N), dtype=np.float32)
                
                # Copy elements, skipping the removed index
                old_i = 0
                for new_i in range(N + 1):  # +1 because we're removing one
                    if old_i == idx:
                        old_i += 1  # Skip the removed row
                        continue
                    
                    old_j = 0
                    for new_j in range(N + 1):
                        if old_j == idx:
                            old_j += 1  # Skip the removed column
                            continue
                        
                        if new_i < N and new_j < N and old_i < self.K.shape[0] and old_j < self.K.shape[1]:
                            new_K[new_i, new_j] = self.K[old_i, old_j]
                        
                        old_j += 1
                    old_i += 1
                
                self.K = new_K
                logger.info(f"Coupling matrix shrunk from {N+1}x{N+1} to {N}x{N}")
            else:
                # No oscillators left
                self.K = None
                logger.info("All oscillators removed, coupling matrix cleared")
        
        return True
    
    def maintenance_pass(self) -> Dict[str, int]:
        """Perform maintenance to clean up flagged oscillators"""
        if not hasattr(self, '_pending_removals'):
            return {"removed": 0, "compacted": 0}
        
        # Sort indices in descending order to avoid index shifting issues
        pending = sorted(self._pending_removals, reverse=True)
        removed_count = 0
        
        for idx in pending:
            if self.remove_oscillator(idx):
                removed_count += 1
        
        # Clear pending removals
        self._pending_removals.clear()
        
        # Compact the matrix if needed
        compacted = self._compact_matrix()
        
        logger.info(f"Maintenance pass complete: removed {removed_count}, compacted {compacted}")
        return {"removed": removed_count, "compacted": compacted}
    
    def _compact_matrix(self) -> int:
        """Compact the coupling matrix to remove gaps"""
        if self.K is None:
            return 0
        
        # Find zero-amplitude oscillators that can be removed
        to_remove = []
        for i, osc in enumerate(self.oscillators):
            if abs(osc.amplitude) < 1e-6:  # Effectively zero
                to_remove.append(i)
        
        # Remove from back to front
        for idx in reversed(to_remove):
            self.remove_oscillator(idx)
        
        return len(to_remove)
    
    def set_coupling(self, i: int, j: int, value: float) -> None:
        self._ensure_K()
        self.K[i, j] = value
    
    # ---------- simulation ---------- #
    def step(self, dt: float) -> None:
        """Euler-integrate one lattice tick with adaptive timestep."""
        if not self.oscillators:
            return
        
        self._ensure_K()
        phases = np.array([o.phase for o in self.oscillators], dtype=np.float32)
        
        # Initialize adaptive timestep if needed
        if self.use_adaptive_dt and ADAPTIVE_DT_AVAILABLE and self.adaptive_dt is None:
            self.adaptive_dt = AdaptiveTimestep(dt_base=dt)
        
        # Update Lyapunov monitoring periodically
        lambda_max = 0.0
        if LYAP_AVAILABLE and self._steps_counter % self._lyap_update_interval == 0:
            try:
                # Construct state for Lyapunov monitoring
                amplitudes = np.array([o.amplitude for o in self.oscillators])
                psi0 = amplitudes * np.exp(1j * phases)
                
                state = {
                    'psi0': psi0,
                    'lattice': self,
                    'g': 1.0,  # Nonlinearity parameter
                    'dx': 1.0  # Spatial discretization
                }
                
                exporter = get_lyapunov_exporter()
                lambda_max = exporter.update_watchlist(state)
                logger.debug(f"Lattice step {self._steps_counter}: lambda_max = {lambda_max}")
            except Exception as e:
                logger.warning(f"Lyapunov update failed: {e}")
        
        # Compute adaptive timestep
        effective_dt = dt
        if self.use_adaptive_dt and self.adaptive_dt is not None:
            effective_dt = self.adaptive_dt.compute_timestep(lambda_max)
            logger.debug(f"Adaptive dt: {effective_dt} (base: {dt}, lambda_max: {lambda_max})")
        
        # Kuramoto coupling term for each oscillator with polarity-aware handling
        amplitudes = np.array([o.amplitude * (-1 if o.polarity == SolitonPolarity.DARK else 1) 
                              for o in self.oscillators], dtype=np.float32)
        
        # Sign-safe coupling that preserves dark soliton stability
        phase_diff = phases[np.newaxis, :] - phases[:, np.newaxis]
        weighted_coupling = self.K * amplitudes[np.newaxis, :] * np.sin(phase_diff)
        coupling = weighted_coupling.sum(axis=1)
        
        for osc, dpsi in zip(self.oscillators, coupling):
            osc.step(effective_dt, dpsi)
        
        # Increment step counter
        self._steps_counter += 1
    
    # ---------- analytics ---------- #
    def order_parameter(self) -> float:
        """Kuramoto global order parameter R ∈ [0, 1]."""
        if not self.oscillators:
            return 0.0
        
        phases = np.array([o.phase for o in self.oscillators])
        R = np.abs(np.exp(1j * phases).mean())
        return float(R)
    
    def phase_entropy(self, bins: int = 36) -> float:
        """Shannon entropy of the phase distribution."""
        if not self.oscillators:
            return 0.0
        
        phases = np.array([o.phase for o in self.oscillators])
        hist, _ = np.histogram(phases, bins=bins, range=(0.0, PI2), density=True)
        p = hist + 1e-12  # avoid log(0)
        return float(-np.sum(p * np.log(p)) / math.log(bins))


# Easy singleton – optional but convenient
_GLOBAL_LATTICE: OscillatorLattice | None = None


def get_global_lattice() -> OscillatorLattice:
    global _GLOBAL_LATTICE
    if _GLOBAL_LATTICE is None:
        _GLOBAL_LATTICE = OscillatorLattice()
    return _GLOBAL_LATTICE


# Morphing lattice integration
def get_morphing_lattice(n_oscillators: int = 100):
    """Get a morphing-capable lattice with Rust topology blending"""
    try:
        from python.core.lattice_morphing import MorphingOscillatorLattice
        return MorphingOscillatorLattice(n_oscillators=n_oscillators)
    except ImportError as e:
        logger.warning(f"Morphing lattice not available: {e}")
        logger.info("Falling back to standard oscillator lattice")
        lattice = OscillatorLattice()
        for i in range(n_oscillators):
            lattice.add_oscillator(
                phase=np.random.uniform(0, 2*np.pi),
                natural_freq=np.random.normal(0.0, 0.1)
            )
        return lattice
