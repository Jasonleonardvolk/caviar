#!/usr/bin/env python3
"""
Rust Lattice Topology Bridge
Connects Python oscillator_lattice.py with Rust lattice_topology.rs for real-time morphing
"""

import ctypes
import json
import numpy as np
from typing import Dict, Tuple, List, Optional
import logging
import os

logger = logging.getLogger(__name__)

class RustLatticeTopology:
    """
    Python wrapper for Rust lattice topology functions
    Provides seamless integration with oscillator_lattice.py
    USES PRE-ALLOCATED ARRAYS TO AVOID ALLOCATION STORMS
    """
    
    def __init__(self, lib_path: Optional[str] = None, max_nodes: int = 10000):
        """Initialize the Rust library connection with pre-allocated buffers"""
        if lib_path is None:
            # Try to find the shared library in common locations
            possible_paths = [
                "concept_mesh/target/release/libconcept_mesh.so",
                "concept_mesh/target/release/libconcept_mesh.dylib", 
                "concept_mesh/target/release/concept_mesh.dll",
                "../concept_mesh/target/release/libconcept_mesh.so",
                "../concept_mesh/target/release/libconcept_mesh.dylib",
                "../concept_mesh/target/release/concept_mesh.dll"
            ]
            
            for path in possible_paths:
                if os.path.exists(path):
                    lib_path = path
                    break
            
            if lib_path is None:
                raise RuntimeError("Could not find Rust library. Please build concept_mesh first.")
        
        # Load the Rust library
        self.lib = ctypes.CDLL(lib_path)
        
        # PRE-ALLOCATE NUMPY ARRAYS TO AVOID ALLOCATION HELL
        self.max_nodes = max_nodes
        self.matrix_buffer_1 = np.zeros((max_nodes, max_nodes), dtype=np.float32)
        self.matrix_buffer_2 = np.zeros((max_nodes, max_nodes), dtype=np.float32)
        self.blend_buffer = np.zeros((max_nodes, max_nodes), dtype=np.float32)
        self.batch_cache = {}  # Cache for batch results
        
        # Configure function signatures
        self._setup_function_signatures()
        logger.info(f"Rust lattice topology library loaded: {lib_path}")
        logger.info(f"Pre-allocated buffers for up to {max_nodes} nodes - NO MORE ALLOCATION STORMS!")
    
    def _setup_function_signatures(self):
        """Configure ctypes function signatures for type safety"""
        # lattice_generate_coupling
        self.lib.lattice_generate_coupling.argtypes = [
            ctypes.c_char_p,  # topology_type
            ctypes.c_int,     # n_nodes
            ctypes.c_double,  # param1
            ctypes.c_double   # param2
        ]
        self.lib.lattice_generate_coupling.restype = ctypes.c_char_p
        
        # lattice_blend_coupling
        self.lib.lattice_blend_coupling.argtypes = [
            ctypes.c_char_p,  # current_json
            ctypes.c_char_p,  # target_json
            ctypes.c_double   # alpha
        ]
        self.lib.lattice_blend_coupling.restype = ctypes.c_char_p
        
        # lattice_morph_step
        self.lib.lattice_morph_step.argtypes = [
            ctypes.c_char_p,  # user_id
            ctypes.c_char_p,  # from_topology
            ctypes.c_char_p,  # to_topology
            ctypes.c_double,  # progress
            ctypes.c_int      # n_nodes
        ]
        self.lib.lattice_morph_step.restype = ctypes.c_char_p
        
        # lattice_batch_morph
        self.lib.lattice_batch_morph.argtypes = [
            ctypes.c_char_p,  # user_id
            ctypes.c_char_p,  # from_topology
            ctypes.c_char_p,  # to_topology
            ctypes.c_double,  # alpha_start
            ctypes.c_double,  # alpha_end
            ctypes.c_int,     # steps
            ctypes.c_int      # n_nodes
        ]
        self.lib.lattice_batch_morph.restype = ctypes.c_char_p
        
        # Memory management
        self.lib.soliton_free_string.argtypes = [ctypes.c_char_p]
        self.lib.soliton_free_string.restype = None
    
    def _call_rust_function(self, func, *args) -> Dict:
        """Call Rust function and handle memory management"""
        # Convert string arguments to bytes
        byte_args = []
        for arg in args:
            if isinstance(arg, str):
                byte_args.append(arg.encode('utf-8'))
            else:
                byte_args.append(arg)
        
        # Call the function
        result_ptr = func(*byte_args)
        
        if not result_ptr:
            raise RuntimeError("Rust function returned null pointer")
        
        # Convert result to string and parse JSON
        result_str = ctypes.c_char_p(result_ptr).value.decode('utf-8')
        
        # Free the string memory
        self.lib.soliton_free_string(result_ptr)
        
        # Parse JSON result
        return json.loads(result_str)
    
    def generate_coupling_matrix(self, topology: str, n_nodes: int, 
                                param1: float = 1.0, param2: float = 0.5) -> np.ndarray:
        """
        Generate coupling matrix for a given topology - REUSABLE VERSION
        
        Args:
            topology: 'kagome', 'hexagonal', 'square', 'all_to_all'
            n_nodes: Number of nodes
            param1: First topology parameter (strength, t1, etc.)
            param2: Second topology parameter (t2 for kagome)
            
        Returns:
            Dense coupling matrix as numpy array (REUSES PRE-ALLOCATED BUFFER)
        """
        if n_nodes > self.max_nodes:
            raise RuntimeError(f"Node count {n_nodes} exceeds pre-allocated buffer size {self.max_nodes}")
            
        result = self._call_rust_function(
            self.lib.lattice_generate_coupling,
            topology, n_nodes, param1, param2
        )
        
        if not result.get('success', False):
            raise RuntimeError(f"Failed to generate coupling matrix: {result.get('error', 'Unknown error')}")
        
        # REUSE PRE-ALLOCATED BUFFER - zero out only the needed region
        K = self.matrix_buffer_1[:n_nodes, :n_nodes]
        K.fill(0.0)  # Clear without allocation
        
        for edge in result['edges']:
            i, j, weight = edge['from'], edge['to'], edge['weight']
            K[i, j] = weight
        
        # Return a copy of just the used portion
        return K.copy()
    
    def blend_coupling_matrices(self, current: np.ndarray, target: np.ndarray, 
                               alpha: float) -> np.ndarray:
        """
        Blend two coupling matrices with smooth interpolation - REUSABLE VERSION
        
        Args:
            current: Current coupling matrix
            target: Target coupling matrix  
            alpha: Blend factor (0 = current, 1 = target)
            
        Returns:
            Blended coupling matrix (REUSES PRE-ALLOCATED BUFFER)
        """
        n = max(current.shape[0], target.shape[0])
        if n > self.max_nodes:
            raise RuntimeError(f"Matrix size {n} exceeds pre-allocated buffer size {self.max_nodes}")
        
        # FAST IN-PLACE BLENDING - NO JSON CONVERSION, NO FFI CALLS
        # This is faster than calling Rust for simple blending
        blended = self.blend_buffer[:n, :n]
        blended.fill(0.0)
        
        # Direct numpy blending - leverages BLAS
        current_view = current if current.shape[0] == n else np.pad(current, ((0, n-current.shape[0]), (0, n-current.shape[1])))
        target_view = target if target.shape[0] == n else np.pad(target, ((0, n-target.shape[0]), (0, n-target.shape[1])))
        
        # In-place blending: blended = (1-alpha)*current + alpha*target
        np.multiply(current_view, (1.0 - alpha), out=blended)
        np.multiply(target_view, alpha, out=self.matrix_buffer_2[:n, :n])
        np.add(blended, self.matrix_buffer_2[:n, :n], out=blended)
        
        return blended.copy()
    
    def morph_topology(self, user_id: str, from_topology: str, to_topology: str,
                      progress: float, n_nodes: int) -> np.ndarray:
        """
        Morph between two topologies with smooth transition
        
        Args:
            user_id: User identifier for tracking
            from_topology: Starting topology
            to_topology: Target topology
            progress: Morph progress (0.0 to 1.0)
            n_nodes: Number of nodes
            
        Returns:
            Morphed coupling matrix
        """
        result = self._call_rust_function(
            self.lib.lattice_morph_step,
            user_id, from_topology, to_topology, progress, n_nodes
        )
        
        if not result.get('success', False):
            raise RuntimeError(f"Failed to morph topology: {result.get('error', 'Unknown error')}")
        
        # Convert to dense matrix
        K = np.zeros((n_nodes, n_nodes), dtype=np.float32)
        
        for edge in result['edges']:
            i, j, weight = edge['from'], edge['to'], edge['weight']
            K[i, j] = weight
        
        logger.info(f"Morphed {from_topology} -> {to_topology} (progress: {progress:.2f})")
        return K
    
    def batch_morph_topology(self, user_id: str, from_topology: str, to_topology: str,
                            alpha_start: float, alpha_end: float, steps: int, n_nodes: int) -> List[np.ndarray]:
        """
        Batch morph multiple steps at once - REDUCES FFI OVERHEAD
        
        Args:
            user_id: User identifier for tracking
            from_topology: Starting topology
            to_topology: Target topology
            alpha_start: Starting blend factor
            alpha_end: Ending blend factor
            steps: Number of steps to compute
            n_nodes: Number of nodes
            
        Returns:
            List of morphed coupling matrices
        """
        cache_key = (from_topology, to_topology, alpha_start, alpha_end, steps, n_nodes)
        
        # Check cache first
        if cache_key in self.batch_cache:
            logger.debug(f"Batch morph cache hit: {from_topology} -> {to_topology}")
            return self.batch_cache[cache_key]
        
        result = self._call_rust_function(
            self.lib.lattice_batch_morph,
            user_id, from_topology, to_topology, alpha_start, alpha_end, steps, n_nodes
        )
        
        if not result.get('success', False):
            raise RuntimeError(f"Failed to batch morph: {result.get('error', 'Unknown error')}")
        
        # Convert all matrices
        matrices = []
        for matrix_data in result['morphed_matrices']:
            K = np.zeros((n_nodes, n_nodes), dtype=np.float32)
            for edge in matrix_data['edges']:
                i, j, weight = edge['from'], edge['to'], edge['weight']
                K[i, j] = weight
            matrices.append(K)
        
        # Cache the result
        self.batch_cache[cache_key] = matrices
        
        logger.info(f"Batch morphed {from_topology} -> {to_topology}: {steps} steps computed at once")
        return matrices


class MorphingOscillatorLattice:
    """
    Enhanced oscillator lattice with real-time topology morphing
    Integrates Python oscillator dynamics with Rust topology blending
    """
    
    def __init__(self, n_oscillators: int = 100):
        """Initialize morphing lattice with pre-allocated structures"""
        # Import the base oscillator lattice
        from python.core.oscillator_lattice import OscillatorLattice, Oscillator, SolitonPolarity
        
        self.base_lattice = OscillatorLattice()
        self.rust_topology = RustLatticeTopology(max_nodes=max(n_oscillators * 2, 1000))
        self.n_oscillators = n_oscillators
        
        # Morphing state
        self.current_topology = "square"
        self.target_topology = "kagome"
        self.morph_progress = 0.0
        self.morph_speed = 0.01  # Progress per step
        self.morph_active = False
        
        # BATCH PROCESSING - compute multiple steps at once
        self.batch_size = 50  # Compute 50 morph steps at once
        self.batch_buffer = []  # Buffer of pre-computed matrices
        self.batch_index = 0
        
        # Initialize oscillators
        for i in range(n_oscillators):
            self.base_lattice.add_oscillator(
                phase=np.random.uniform(0, 2*np.pi),
                natural_freq=np.random.normal(0.0, 0.1),
                amplitude=1.0,
                polarity=SolitonPolarity.BRIGHT
            )
        
        # Initialize coupling matrix
        self._update_coupling_matrix()
        logger.info(f"Morphing oscillator lattice initialized with {n_oscillators} oscillators")
    
    def _update_coupling_matrix(self):
        """Update the coupling matrix based on current morph state - BATCH OPTIMIZED"""
        if self.morph_active and self.morph_progress < 1.0:
            # Check if we need to compute a new batch
            if not self.batch_buffer or self.batch_index >= len(self.batch_buffer):
                self._compute_morph_batch()
            
            # Use pre-computed matrix from batch
            if self.batch_buffer and self.batch_index < len(self.batch_buffer):
                K = self.batch_buffer[self.batch_index]
                self.batch_index += 1
            else:
                # Fallback to single computation
                K = self.rust_topology.morph_topology(
                    user_id="morphing_lattice",
                    from_topology=self.current_topology,
                    to_topology=self.target_topology,
                    progress=self.morph_progress,
                    n_nodes=self.n_oscillators
                )
        else:
            # Static topology
            K = self.rust_topology.generate_coupling_matrix(
                topology=self.current_topology,
                n_nodes=self.n_oscillators
            )
        
        # Update the oscillator lattice coupling matrix
        self.base_lattice.K = K
    
    def _compute_morph_batch(self):
        """Compute a batch of morph steps at once - REDUCES FFI OVERHEAD"""
        if not self.morph_active:
            return
            
        # Compute progress range for this batch
        remaining_progress = 1.0 - self.morph_progress
        batch_progress = min(remaining_progress, self.batch_size * self.morph_speed)
        
        alpha_start = self.morph_progress
        alpha_end = min(self.morph_progress + batch_progress, 1.0)
        actual_steps = min(self.batch_size, int(remaining_progress / self.morph_speed) + 1)
        
        if actual_steps > 0:
            logger.info(f"Computing batch: {actual_steps} steps from α={alpha_start:.3f} to α={alpha_end:.3f}")
            
            self.batch_buffer = self.rust_topology.batch_morph_topology(
                user_id="morphing_lattice",
                from_topology=self.current_topology,
                to_topology=self.target_topology,
                alpha_start=alpha_start,
                alpha_end=alpha_end,
                steps=actual_steps,
                n_nodes=self.n_oscillators
            )
            self.batch_index = 0
    
    def start_morph(self, target_topology: str, speed: float = 0.01):
        """Start morphing to a new topology with batch optimization"""
        self.target_topology = target_topology
        self.morph_speed = speed
        self.morph_progress = 0.0
        self.morph_active = True
        
        # Clear batch buffer for new morph
        self.batch_buffer = []
        self.batch_index = 0
        
        logger.info(f"Started morphing: {self.current_topology} -> {target_topology} (batch size: {self.batch_size})")
    
    def step(self, dt: float):
        """Step the morphing lattice dynamics - BATCH OPTIMIZED"""
        # Update morph progress
        if self.morph_active:
            self.morph_progress += self.morph_speed
            
            if self.morph_progress >= 1.0:
                # Morph complete
                self.morph_progress = 1.0
                self.current_topology = self.target_topology
                self.morph_active = False
                self.batch_buffer = []  # Clear batch
                logger.info(f"Morph completed: now using {self.current_topology}")
            
            # Update coupling matrix with current morph state (uses batch if available)
            self._update_coupling_matrix()
        
        # Step the base oscillator dynamics
        self.base_lattice.step(dt)
    
    def add_dark_soliton(self, phase: float, frequency: float = 0.0) -> int:
        """Add a dark soliton oscillator"""
        from python.core.oscillator_lattice import SolitonPolarity
        
        idx = self.base_lattice.add_oscillator(
            phase=phase,
            natural_freq=frequency,
            amplitude=1.0,
            polarity=SolitonPolarity.DARK
        )
        
        # Update coupling matrix to account for new oscillator
        self.n_oscillators = len(self.base_lattice.oscillators)
        self._update_coupling_matrix()
        
        return idx
    
    def get_topology_info(self) -> Dict:
        """Get current topology and morph status"""
        return {
            'current_topology': self.current_topology,
            'target_topology': self.target_topology if self.morph_active else None,
            'morph_progress': self.morph_progress if self.morph_active else 1.0,
            'morph_active': self.morph_active,
            'n_oscillators': self.n_oscillators,
            'order_parameter': self.base_lattice.order_parameter(),
            'phase_entropy': self.base_lattice.phase_entropy()
        }
    
    # Delegate other methods to base lattice
    def __getattr__(self, name):
        return getattr(self.base_lattice, name)


# Convenience functions
def demo_lattice_morphing():
    """Demonstrate real-time lattice morphing"""
    print("🚀 Morphing Oscillator Lattice Demo")
    print("=" * 40)
    
    # Create morphing lattice
    lattice = MorphingOscillatorLattice(n_oscillators=50)
    
    # Add some dark solitons
    lattice.add_dark_soliton(phase=np.pi, frequency=0.1)
    lattice.add_dark_soliton(phase=0.5*np.pi, frequency=-0.1)
    
    print(f"Initial topology: {lattice.current_topology}")
    print(f"Order parameter: {lattice.order_parameter():.3f}")
    
    # Start morphing to kagome
    lattice.start_morph("kagome", speed=0.05)
    
    # Simulate morphing process
    for step in range(50):
        lattice.step(dt=0.1)
        
        if step % 10 == 0:
            info = lattice.get_topology_info()
            print(f"Step {step}: {info['current_topology']} -> {info['target_topology']} "
                  f"({info['morph_progress']:.2f}) R={lattice.order_parameter():.3f}")
    
    print(f"Final topology: {lattice.current_topology}")
    print("✅ Morphing demo complete!")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='%(levelname)s - %(message)s')
    
    try:
        demo_lattice_morphing()
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        print("Make sure the Rust library is built with: cargo build --release")
        print("\n📝 NOTE: This demo shows the performance improvements from:")
        print("  - Pre-allocated HashMap/HashSet workspaces in Rust")
        print("  - Reusable numpy arrays in Python")
        print("  - Batch FFI calls instead of per-step calls")
        print("  - Smart caching of morph trajectories")
        print("\n🚀 NO MORE ALLOCATION STORMS!")
