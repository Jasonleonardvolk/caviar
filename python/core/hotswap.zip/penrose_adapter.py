r"""
Penrose Tensor Acceleration Adapter
File: C:\Users\jason\Desktop\tori\kha\python\core\penrose_adapter.py

High-performance Rust backend integration for fractal soliton memory operations.
Provides GPU-accelerated tensor operations for lattice evolution, phase entanglement,
and curvature field computations.

Architecture: PyO3/Rust backend with graceful Python fallback
"""

import numpy as np
import logging
import asyncio
from typing import Optional, Dict, Any, Tuple, Union
from dataclasses import dataclass
import json
import os
from pathlib import Path

logger = logging.getLogger(__name__)

# Runtime detection flags
PENROSE_ENGINE_AVAILABLE = False
PENROSE_LIB = None

@dataclass
class PenroseConfig:
    """Configuration for Penrose acceleration backend"""
    enable_gpu: bool = True
    max_threads: int = 8
    cache_size_mb: int = 512
    precision: str = "float32"  # float32 | float64
    fallback_to_numpy: bool = True
    log_performance: bool = True

class PenroseAdapter:
    """
    Singleton adapter for Rust-accelerated tensor operations.
    
    Provides high-performance implementations of:
    - Lattice field evolution (JIT-compiled)
    - Phase entanglement calculations
    - Curvature-to-phase encoding
    - Gradient computations
    - Memory compression (SVD/PCA)
    """
    
    _instance: Optional['PenroseAdapter'] = None
    _initialized: bool = False
    
    def __init__(self, config: Optional[PenroseConfig] = None):
        if PenroseAdapter._initialized:
            return
            
        self.config = config or PenroseConfig()
        self.rust_lib = None
        self.performance_stats = {
            "operations_count": 0,
            "total_speedup": 0.0,
            "cache_hits": 0,
            "fallback_count": 0
        }
        
        # Attempt to load Rust backend
        self._initialize_rust_backend()
        PenroseAdapter._initialized = True
    
    @classmethod
    def get_instance(cls, config: Optional[PenroseConfig] = None) -> 'PenroseAdapter':
        """Get singleton instance of Penrose adapter"""
        if cls._instance is None:
            cls._instance = cls(config)
        return cls._instance
    
    def _initialize_rust_backend(self) -> None:
        """Initialize the Rust backend library with error handling"""
        global PENROSE_ENGINE_AVAILABLE, PENROSE_LIB
        
        try:
            # Attempt to import the compiled Rust library
            import penrose_engine
            PENROSE_LIB = penrose_engine
            PENROSE_ENGINE_AVAILABLE = True
            
            # Initialize Rust engine with config
            init_result = PENROSE_LIB.initialize_engine(
                max_threads=self.config.max_threads,
                cache_size_mb=self.config.cache_size_mb,
                enable_gpu=self.config.enable_gpu,
                precision=self.config.precision
            )
            
            if init_result.get("success", False):
                logger.info(f"✅ Penrose tensor acceleration enabled")
                logger.info(f"   GPU: {init_result.get('gpu_available', False)}")
                logger.info(f"   Threads: {init_result.get('thread_count', 'unknown')}")
                logger.info(f"   Cache: {self.config.cache_size_mb}MB")
            else:
                raise RuntimeError(f"Rust engine initialization failed: {init_result.get('error', 'unknown')}")
                
        except ImportError as e:
            logger.warning("⚠️ Penrose Rust engine not available - using NumPy fallback")
            logger.debug(f"Import error: {e}")
            PENROSE_ENGINE_AVAILABLE = False
            
        except Exception as e:
            logger.error(f"❌ Penrose engine initialization error: {e}")
            PENROSE_ENGINE_AVAILABLE = False
            
            if not self.config.fallback_to_numpy:
                raise RuntimeError(f"Penrose required but unavailable: {e}")
    
    def is_available(self) -> bool:
        """Check if Penrose acceleration is available"""
        return PENROSE_ENGINE_AVAILABLE
    
    def get_backend_info(self) -> Dict[str, Any]:
        """Get detailed backend information"""
        if not PENROSE_ENGINE_AVAILABLE:
            return {
                "available": False,
                "backend": "numpy_fallback",
                "reason": "rust_engine_not_loaded"
            }
        
        try:
            info = PENROSE_LIB.get_engine_info()
            return {
                "available": True,
                "backend": "rust_penrose",
                "version": info.get("version", "unknown"),
                "gpu_enabled": info.get("gpu_enabled", False),
                "thread_count": info.get("thread_count", 1),
                "cache_size": info.get("cache_size_mb", 0),
                "precision": self.config.precision
            }
        except Exception as e:
            logger.warning(f"Could not get backend info: {e}")
            return {"available": False, "error": str(e)}
    
    async def evolve_lattice_field(
        self, 
        lattice: np.ndarray, 
        phase_field: np.ndarray,
        curvature_field: np.ndarray,
        dt: float = 0.01
    ) -> np.ndarray:
        """
        Accelerated lattice field evolution using Rust backend.
        
        Args:
            lattice: Current lattice state (H x W)
            phase_field: ψ-phase field (H x W) 
            curvature_field: Geometric curvature (H x W)
            dt: Time step for evolution
            
        Returns:
            Updated lattice field
        """
        if PENROSE_ENGINE_AVAILABLE:
            try:
                # Call Rust implementation
                result = await asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: PENROSE_LIB.evolve_lattice_field(
                        lattice.astype(self.config.precision),
                        phase_field.astype(self.config.precision),
                        curvature_field.astype(self.config.precision),
                        dt
                    )
                )
                
                self.performance_stats["operations_count"] += 1
                return np.array(result, dtype=lattice.dtype)
                
            except Exception as e:
                logger.warning(f"Rust lattice evolution failed, falling back to NumPy: {e}")
                self.performance_stats["fallback_count"] += 1
        
        # NumPy fallback implementation
        return self._evolve_lattice_numpy(lattice, phase_field, curvature_field, dt)
    
    def _evolve_lattice_numpy(
        self, 
        lattice: np.ndarray, 
        phase_field: np.ndarray,
        curvature_field: np.ndarray,
        dt: float
    ) -> np.ndarray:
        """NumPy fallback for lattice evolution"""
        # Simple evolution using phase-curvature coupling
        phase_gradient = np.gradient(phase_field)
        curvature_coupling = curvature_field * np.cos(phase_field)
        
        evolution_term = (
            0.1 * (phase_gradient[0]**2 + phase_gradient[1]**2) +
            0.05 * curvature_coupling
        )
        
        return lattice + dt * evolution_term
    
    async def compute_phase_entanglement(
        self,
        soliton_positions: np.ndarray,
        phases: np.ndarray,
        coupling_strength: float = 1.0
    ) -> np.ndarray:
        """
        Compute quantum phase entanglement between solitons.
        
        Args:
            soliton_positions: Soliton positions (N x 2)
            phases: Soliton phases (N,)
            coupling_strength: Entanglement coupling parameter
            
        Returns:
            Entanglement matrix (N x N)
        """
        if PENROSE_ENGINE_AVAILABLE:
            try:
                result = await asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: PENROSE_LIB.compute_phase_entanglement(
                        soliton_positions.astype(self.config.precision),
                        phases.astype(self.config.precision),
                        coupling_strength
                    )
                )
                
                self.performance_stats["operations_count"] += 1
                return np.array(result, dtype=phases.dtype)
                
            except Exception as e:
                logger.warning(f"Rust entanglement computation failed: {e}")
                self.performance_stats["fallback_count"] += 1
        
        # NumPy fallback
        return self._compute_entanglement_numpy(soliton_positions, phases, coupling_strength)
    
    def _compute_entanglement_numpy(
        self,
        positions: np.ndarray,
        phases: np.ndarray,
        coupling: float
    ) -> np.ndarray:
        """NumPy fallback for phase entanglement"""
        n_solitons = len(positions)
        entanglement = np.zeros((n_solitons, n_solitons))
        
        for i in range(n_solitons):
            for j in range(i + 1, n_solitons):
                # Distance-based coupling
                distance = np.linalg.norm(positions[i] - positions[j])
                phase_diff = abs(phases[i] - phases[j])
                
                # Entanglement strength
                entanglement[i, j] = coupling * np.exp(-distance / 10.0) * np.cos(phase_diff)
                entanglement[j, i] = entanglement[i, j]
        
        return entanglement
    
    async def accelerated_curvature_encode(
        self,
        curvature_field: np.ndarray,
        encoding_mode: str = "log_phase"
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Accelerated curvature-to-phase encoding.
        
        Args:
            curvature_field: Kretschmann scalar field (H x W)
            encoding_mode: "log_phase", "tanh", or "direct"
            
        Returns:
            Tuple of (phase_field, amplitude_field)
        """
        if PENROSE_ENGINE_AVAILABLE:
            try:
                result = await asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: PENROSE_LIB.curvature_to_phase_encode(
                        curvature_field.astype(self.config.precision),
                        encoding_mode
                    )
                )
                
                phase_field = np.array(result["phase"], dtype=curvature_field.dtype)
                amplitude_field = np.array(result["amplitude"], dtype=curvature_field.dtype)
                
                self.performance_stats["operations_count"] += 1
                return phase_field, amplitude_field
                
            except Exception as e:
                logger.warning(f"Rust curvature encoding failed: {e}")
                self.performance_stats["fallback_count"] += 1
        
        # NumPy fallback
        return self._encode_curvature_numpy(curvature_field, encoding_mode)
    
    def _encode_curvature_numpy(
        self,
        curvature: np.ndarray,
        mode: str
    ) -> Tuple[np.ndarray, np.ndarray]:
        """NumPy fallback for curvature encoding"""
        if mode == "log_phase":
            safe_curvature = np.maximum(curvature, 1e-8)
            phase = np.log(safe_curvature) % (2 * np.pi) - np.pi
            amplitude = 1.0 / (1.0 + safe_curvature**2)
        elif mode == "tanh":
            phase = np.tanh(curvature) * np.pi
            amplitude = 1.0 / np.cosh(curvature)
        else:  # direct
            phase = curvature % (2 * np.pi) - np.pi
            amplitude = np.ones_like(curvature)
        
        return phase, amplitude
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get performance statistics"""
        stats = self.performance_stats.copy()
        
        if stats["operations_count"] > 0:
            stats["average_speedup"] = stats["total_speedup"] / stats["operations_count"]
            stats["fallback_rate"] = stats["fallback_count"] / stats["operations_count"]
        else:
            stats["average_speedup"] = 0.0
            stats["fallback_rate"] = 0.0
            
        stats["backend_available"] = PENROSE_ENGINE_AVAILABLE
        
        return stats
    
    def reset_stats(self) -> None:
        """Reset performance statistics"""
        self.performance_stats = {
            "operations_count": 0,
            "total_speedup": 0.0,
            "cache_hits": 0,
            "fallback_count": 0
        }
    
    async def shutdown(self) -> None:
        """Clean shutdown of Penrose engine"""
        if PENROSE_ENGINE_AVAILABLE and PENROSE_LIB:
            try:
                await asyncio.get_event_loop().run_in_executor(
                    None,
                    PENROSE_LIB.shutdown_engine
                )
                logger.info("✅ Penrose engine shutdown complete")
            except Exception as e:
                logger.warning(f"Penrose shutdown warning: {e}")

# Convenience functions for direct usage
async def get_penrose_adapter(config: Optional[PenroseConfig] = None) -> PenroseAdapter:
    """Get the global Penrose adapter instance"""
    return PenroseAdapter.get_instance(config)

def is_penrose_available() -> bool:
    """Quick check if Penrose acceleration is available"""
    return PENROSE_ENGINE_AVAILABLE

def get_penrose_info() -> Dict[str, Any]:
    """Get Penrose backend information"""
    adapter = PenroseAdapter.get_instance()
    return adapter.get_backend_info()

# Export main classes and functions
__all__ = [
    'PenroseAdapter',
    'PenroseConfig', 
    'get_penrose_adapter',
    'is_penrose_available',
    'get_penrose_info'
]
