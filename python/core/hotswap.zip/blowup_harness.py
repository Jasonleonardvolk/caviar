def induce_blowup(lattice, epsilon: float = 0.5, steps: int = 10):
    """
    Deliberately amplify lattice energy and then harvest it.
    Repeatedly boosts the lattice's wavefunction by (1+ε) for a few steps to induce a blow-up,
    then captures the resulting state and clears the lattice.
    Returns:
        harvested (np.ndarray): Copy of the high-energy wavefunction before clearing.
    """
    # Increase energy over a number of steps
    for _ in range(steps):
        lattice.psi *= (1 + epsilon)
        lattice.step()            # advance one integration step (using current dt)
    # Copy out the high-energy state
    harvested = lattice.psi.copy()
    # Reset the lattice state (remove all energy)
    lattice.psi *= 0.0
    return harvested
