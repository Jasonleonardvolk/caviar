"""
TORI/KHA Unified Memory Vault - Production Implementation
Consolidates all memory systems with FILE-BASED storage only (NO DATABASES)
"""

import json
import pickle
import hashlib
import time
import logging
import asyncio
import threading
import os
from typing import Dict, Any, List, Optional, Union, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path
from datetime import datetime
from collections import defaultdict, OrderedDict
from enum import Enum
import numpy as np
import gzip
import shutil

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MemoryType(Enum):
    """Types of memory storage"""
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    WORKING = "working"
    GHOST = "ghost"
    SOLITON = "soliton"

@dataclass
class MemoryEntry:
    """Single memory entry"""
    id: str
    type: MemoryType
    content: Any
    embedding: Optional[np.ndarray]
    metadata: Dict[str, Any]
    timestamp: float
    access_count: int = 0
    last_accessed: Optional[float] = None
    decay_rate: float = 0.0
    importance: float = 1.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        data = asdict(self)
        data['type'] = self.type.value
        if self.embedding is not None:
            data['embedding'] = self.embedding.tolist()
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MemoryEntry':
        """Create from dictionary"""
        data['type'] = MemoryType(data['type'])
        if data.get('embedding') is not None:
            data['embedding'] = np.array(data['embedding'])
        return cls(**data)

class UnifiedMemoryVault:
    """
    Unified memory system consolidating all memory implementations
    Uses ONLY file-based storage - NO DATABASES
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize unified memory vault"""
        self.config = config or {}
        
        # Storage configuration
        self.storage_path = Path(self.config.get('storage_path', 'data/memory_vault'))
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        # Create storage subdirectories
        self.memories_dir = self.storage_path / 'memories'
        self.index_dir = self.storage_path / 'index'
        self.blobs_dir = self.storage_path / 'blobs'
        self.working_dir = self.storage_path / 'working'
        self.ghost_dir = self.storage_path / 'ghost'
        self.logs_dir = self.storage_path / 'logs'
        
        for directory in [self.memories_dir, self.index_dir, self.blobs_dir, self.working_dir, self.ghost_dir, self.logs_dir]:
            directory.mkdir(exist_ok=True)
        
        # Dual-mode logging paths
        self.live_log_path = self.logs_dir / 'vault_live.jsonl'
        self.snapshot_path = self.logs_dir / 'vault_snapshot.json'
        
        # Session tracking
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.session_log_path = self.logs_dir / f'session_{self.session_id}.jsonl'
        
        # Deduplication tracking
        self.seen_hashes_file = self.logs_dir / 'seen_hashes.json'
        self.seen_hashes = self._load_seen_hashes()
        
        # Memory configuration
        self.max_working_memory = self.config.get('max_working_memory', 100)
        self.ghost_memory_ttl = self.config.get('ghost_memory_ttl', 3600)  # 1 hour
        self.decay_enabled = self.config.get('decay_enabled', True)
        self.compression_threshold = self.config.get('compression_threshold', 1024)
        self.use_compression = self.config.get('use_compression', True)
        
        # In-memory caches
        self.working_memory: OrderedDict[str, MemoryEntry] = OrderedDict()
        self.ghost_memory: Dict[str, MemoryEntry] = {}
        self.access_cache: Dict[str, float] = defaultdict(float)
        
        # Index files
        self.main_index_file = self.index_dir / 'main_index.json'
        self.type_index_file = self.index_dir / 'type_index.json'
        self.tag_index_file = self.index_dir / 'tag_index.json'
        
        # Thread safety
        self.lock = threading.RLock()
        
        # Load indices
        self._load_indices()
        
        # Start background tasks
        self._start_background_tasks()
        
        # Enhanced tracking for observability
        self._start_time = time.time()
        self._pending_snapshot_count = 0
        self._init_crash_log()
        
        logger.info(f"UnifiedMemoryVault initialized at {self.storage_path} (FILE-BASED ONLY)")
        logger.info(f"Session ID: {self.session_id}")
        logger.info(f"Dual-mode logging: {self.live_log_path} + {self.snapshot_path}")
    
    def _load_seen_hashes(self) -> Dict[str, float]:
        """Load seen hashes for deduplication"""
        if self.seen_hashes_file.exists():
            try:
                with open(self.seen_hashes_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Failed to load seen hashes: {e}")
        return {}
    
    def _save_seen_hashes(self):
        """Save seen hashes for deduplication"""
        try:
            with open(self.seen_hashes_file, 'w') as f:
                json.dump(self.seen_hashes, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save seen hashes: {e}")
    
    def _calculate_entry_hash(self, entry: MemoryEntry) -> str:
        """Calculate SHA-256 hash for deduplication"""
        # Create consistent hash from entry content
        entry_dict = {
            'type': entry.type.value,
            'content': str(entry.content),
            'metadata': entry.metadata
        }
        entry_str = json.dumps(entry_dict, sort_keys=True)
        return hashlib.sha256(entry_str.encode()).hexdigest()
    
    def _init_crash_log(self):
        """Initialize crash-safe logging"""
        # Ensure log exists
        self.live_log_path.touch(exist_ok=True)
        
        # Write session start marker
        start_marker = {
            'session_id': self.session_id,
            'timestamp': self._start_time,
            'action': 'session_start',
            'pid': os.getpid()
        }
        
        with open(self.live_log_path, 'a') as f:
            f.write(json.dumps(start_marker) + '\n')
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """Enhanced memory statistics for observability endpoint"""
        with self.lock:
            stats = self.get_statistics()  # Existing method
            
            # Add real-time metrics
            stats.update({
                'live_log_size': self.live_log_path.stat().st_size if self.live_log_path.exists() else 0,
                'session_duration': (time.time() - self._start_time),
                'write_rate': len(self.working_memory) / max(1, time.time() - self._start_time),
                'hash_collisions': sum(1 for v in self.seen_hashes.values() if isinstance(v, (int, float)) and v > 1),
                'pending_snapshots': self._pending_snapshot_count
            })
            
            return stats
    
    def _append_to_live_log(self, entry: MemoryEntry, action: str = "store"):
        """Append entry to live NDJSON log"""
        try:
            log_entry = {
                'session_id': self.session_id,
                'timestamp': time.time(),
                'action': action,
                'entry': entry.to_dict(),
                'checksum': self._calculate_entry_hash(entry)  # For integrity
            }
            
            # Append to main live log
            with open(self.live_log_path, 'a', encoding='utf-8') as f:
                f.write(json.dumps(log_entry) + '\n')
            
            # Also append to session log
            with open(self.session_log_path, 'a', encoding='utf-8') as f:
                f.write(json.dumps(log_entry) + '\n')
                
        except Exception as e:
            logger.error(f"Failed to append to live log: {e}")
    
    def _enhanced_append_to_live_log(self, entry: MemoryEntry, action: str = "store"):
        """Enhanced crash-safe NDJSON writer with buffering"""
        try:
            log_entry = {
                'session_id': self.session_id,
                'timestamp': time.time(),
                'action': action,
                'entry': entry.to_dict(),
                'checksum': self._calculate_entry_hash(entry)  # For integrity
            }
            
            # Buffer writes for performance
            if not hasattr(self, '_log_buffer'):
                self._log_buffer = []
                self._last_flush = time.time()
            
            self._log_buffer.append(json.dumps(log_entry) + '\n')
            
            # Flush if buffer is large or time elapsed
            if len(self._log_buffer) >= 10 or (time.time() - self._last_flush) > 5:
                self._flush_log_buffer()
                
        except Exception as e:
            logger.error(f"Failed to append to live log: {e}")
            # Force flush on error
            self._flush_log_buffer()
    
    def _flush_log_buffer(self):
        """Flush log buffer to disk"""
        if hasattr(self, '_log_buffer') and self._log_buffer:
            with open(self.live_log_path, 'a', encoding='utf-8') as f:
                f.writelines(self._log_buffer)
                f.flush()
                os.fsync(f.fileno())  # Force to disk
            
            self._log_buffer.clear()
            self._last_flush = time.time()
    
    def _write_snapshot(self):
        """Write complete memory snapshot"""
        try:
            snapshot_data = {
                'session_id': self.session_id,
                'timestamp': time.time(),
                'statistics': self.get_statistics(),
                'memories': {
                    'working': [m.to_dict() for m in self.working_memory.values()],
                    'ghost': [m.to_dict() for m in self.ghost_memory.values()],
                    'persistent_count': len(self.main_index)
                },
                'indices': {
                    'main_index': self.main_index,
                    'type_index': self.type_index,
                    'tag_index': self.tag_index
                },
                'seen_hashes': self.seen_hashes
            }
            
            # Write snapshot atomically
            temp_path = self.snapshot_path.with_suffix('.tmp')
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(snapshot_data, f, indent=2)
            
            # Atomic rename
            temp_path.replace(self.snapshot_path)
            
            logger.debug(f"Snapshot written: {self.snapshot_path}")
            
        except Exception as e:
            logger.error(f"Failed to write snapshot: {e}")
    
    def _load_indices(self):
        """Load file-based indices"""
        try:
            # Main index: memory_id -> file_path
            if self.main_index_file.exists():
                with open(self.main_index_file, 'r') as f:
                    self.main_index = json.load(f)
            else:
                self.main_index = {}
            
            # Type index: memory_type -> [memory_ids]
            if self.type_index_file.exists():
                with open(self.type_index_file, 'r') as f:
                    self.type_index = json.load(f)
            else:
                self.type_index = {}
            
            # Tag index: tag -> [memory_ids]
            if self.tag_index_file.exists():
                with open(self.tag_index_file, 'r') as f:
                    self.tag_index = json.load(f)
            else:
                self.tag_index = {}
                
            logger.info(f"Loaded indices: {len(self.main_index)} memories indexed")
            
        except Exception as e:
            logger.error(f"Failed to load indices: {e}")
            self.main_index = {}
            self.type_index = {}
            self.tag_index = {}
    
    def _save_indices(self):
        """Save file-based indices"""
        try:
            # Save main index
            with open(self.main_index_file, 'w') as f:
                json.dump(self.main_index, f, indent=2)
            
            # Save type index
            with open(self.type_index_file, 'w') as f:
                json.dump(self.type_index, f, indent=2)
            
            # Save tag index
            with open(self.tag_index_file, 'w') as f:
                json.dump(self.tag_index, f, indent=2)
                
        except Exception as e:
            logger.error(f"Failed to save indices: {e}")
    
    def _start_background_tasks(self):
        """Start background maintenance tasks"""
        # Decay task
        if self.decay_enabled:
            threading.Thread(target=self._decay_loop, daemon=True).start()
        
        # Ghost memory cleanup
        threading.Thread(target=self._ghost_cleanup_loop, daemon=True).start()
        
        # Index maintenance
        threading.Thread(target=self._index_maintenance_loop, daemon=True).start()
    
    def _decay_loop(self):
        """Background task to decay memories"""
        while True:
            time.sleep(300)  # Run every 5 minutes
            try:
                self._apply_decay()
            except Exception as e:
                logger.error(f"Decay loop error: {e}")
    
    def _ghost_cleanup_loop(self):
        """Background task to clean expired ghost memories"""
        while True:
            time.sleep(60)  # Run every minute
            try:
                self._cleanup_ghost_memory()
            except Exception as e:
                logger.error(f"Ghost cleanup error: {e}")
    
    def recover_from_crash(self) -> Dict[str, int]:
        """Recover state from live log after crash"""
        stats = {
            'recovered': 0,
            'duplicates': 0,
            'errors': 0
        }
        
        if not self.live_log_path.exists():
            logger.info("No live log found for recovery")
            return stats
        
        logger.info(f"Recovering from crash using: {self.live_log_path}")
        
        try:
            with open(self.live_log_path, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, 1):
                    try:
                        log_entry = json.loads(line.strip())
                        
                        # Skip entries from current session
                        if log_entry.get('session_id') == self.session_id:
                            continue
                        
                        action = log_entry.get('action')
                        entry_data = log_entry.get('entry')
                        
                        if action == 'store' and entry_data:
                            # Recreate memory entry
                            entry = MemoryEntry.from_dict(entry_data)
                            
                            # Check if already exists
                            if entry.id in self.main_index or \
                               entry.id in self.working_memory or \
                               entry.id in self.ghost_memory:
                                stats['duplicates'] += 1
                                continue
                            
                            # Re-store based on type
                            if entry.type == MemoryType.WORKING:
                                self.working_memory[entry.id] = entry
                            elif entry.type == MemoryType.GHOST:
                                self.ghost_memory[entry.id] = entry
                            else:
                                # Add to main index
                                self.main_index[entry.id] = f"memories/{entry.id}.json"
                            
                            stats['recovered'] += 1
                            
                    except Exception as e:
                        logger.debug(f"Error processing line {line_num}: {e}")
                        stats['errors'] += 1
            
            logger.info(f"✅ Crash recovery complete: {stats}")
            
            # Write recovery snapshot
            self._write_snapshot()
            
        except Exception as e:
            logger.error(f"Failed to recover from crash: {e}")
        
        return stats
    
    def _index_maintenance_loop(self):
        """Background task to maintain indices"""
        while True:
            time.sleep(600)  # Run every 10 minutes
            try:
                self._save_indices()
            except Exception as e:
                logger.error(f"Index maintenance error: {e}")
    
    async def store(
        self,
        content: Any,
        memory_type: Union[MemoryType, str],
        metadata: Optional[Dict[str, Any]] = None,
        embedding: Optional[np.ndarray] = None,
        importance: float = 1.0,
        tags: Optional[List[str]] = None
    ) -> str:
        """Store a memory entry with deduplication and dual-mode logging"""
        with self.lock:
            # Convert string to MemoryType
            if isinstance(memory_type, str):
                memory_type = MemoryType(memory_type)
            
            # Generate ID
            memory_id = self._generate_id(content, metadata)
            
            # Create memory entry
            entry = MemoryEntry(
                id=memory_id,
                type=memory_type,
                content=content,
                embedding=embedding,
                metadata=metadata or {},
                timestamp=time.time(),
                importance=importance
            )
            
            # Check for duplicates using SHA-256
            entry_hash = self._calculate_entry_hash(entry)
            if entry_hash in self.seen_hashes:
                logger.debug(f"Duplicate entry detected (hash: {entry_hash[:8]}...), updating timestamp")
                self.seen_hashes[entry_hash] = time.time()
                # Still log the attempt
                self._append_to_live_log(entry, "duplicate")
                return memory_id
            
            # Mark as seen
            self.seen_hashes[entry_hash] = time.time()
            
            # Log to NDJSON immediately (crash-safe)
            self._append_to_live_log(entry, "store")
            
            # Store based on type
            if memory_type == MemoryType.WORKING:
                # Add to working memory (in-memory only)
                self.working_memory[memory_id] = entry
                
                # Enforce size limit
                while len(self.working_memory) > self.max_working_memory:
                    oldest_id = next(iter(self.working_memory))
                    evicted = self.working_memory.pop(oldest_id)
                    self._append_to_live_log(evicted, "evicted")
                
                # Also save to working directory for persistence
                await self._save_memory_to_file(entry, self.working_dir)
                    
            elif memory_type == MemoryType.GHOST:
                # Add to ghost memory (ephemeral)
                self.ghost_memory[memory_id] = entry
                
                # Save to ghost directory
                await self._save_memory_to_file(entry, self.ghost_dir)
                
            else:
                # Store to persistent file storage
                await self._save_memory_to_file(entry, self.memories_dir)
                
                # Update indices
                self._update_indices(memory_id, memory_type, tags)
            
            # Periodic snapshot (every N entries or time interval)
            total_entries = len(self.working_memory) + len(self.ghost_memory) + len(self.main_index)
            if total_entries % 100 == 0:  # Every 100 entries
                self._write_snapshot()
            
            logger.debug(f"Stored memory {memory_id} of type {memory_type.value}")
            return memory_id
    
    async def _save_memory_to_file(self, entry: MemoryEntry, directory: Path):
        """Save memory entry to file"""
        file_path = directory / f"{entry.id}.json"
        
        # Prepare data for serialization
        data = entry.to_dict()
        
        # Handle large content
        if self._should_compress_content(entry.content):
            # Save content separately and compressed
            blob_path = self.blobs_dir / f"{entry.id}.pkl.gz"
            with gzip.open(blob_path, 'wb') as f:
                pickle.dump(entry.content, f)
            
            # Replace content with reference
            data['content'] = f"__BLOB_REF__:{blob_path.name}"
        
        # Save memory metadata
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)
        
        # Update main index
        self.main_index[entry.id] = str(file_path.relative_to(self.storage_path))
    
    def _should_compress_content(self, content: Any) -> bool:
        """Check if content should be compressed and stored separately"""
        try:
            serialized = pickle.dumps(content)
            return len(serialized) > self.compression_threshold
        except:
            return False
    
    async def retrieve(self, memory_id: str) -> Optional[MemoryEntry]:
        """Retrieve a memory entry"""
        with self.lock:
            # Check working memory
            if memory_id in self.working_memory:
                entry = self.working_memory[memory_id]
                self._update_access(entry)
                self._append_to_live_log(entry, "accessed")
                return entry
            
            # Check ghost memory
            if memory_id in self.ghost_memory:
                entry = self.ghost_memory[memory_id]
                self._update_access(entry)
                self._append_to_live_log(entry, "accessed")
                return entry
            
            # Load from file storage
            entry = await self._load_memory_from_file(memory_id)
            if entry:
                self._append_to_live_log(entry, "loaded")
            return entry
    
    async def _load_memory_from_file(self, memory_id: str) -> Optional[MemoryEntry]:
        """Load memory entry from file"""
        try:
            # Find file path in index
            if memory_id not in self.main_index:
                return None
            
            file_path = self.storage_path / self.main_index[memory_id]
            
            if not file_path.exists():
                # Clean up stale index entry
                del self.main_index[memory_id]
                return None
            
            # Load memory metadata
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            # Handle blob references
            if isinstance(data.get('content'), str) and data['content'].startswith('__BLOB_REF__:'):
                blob_name = data['content'].split(':', 1)[1]
                blob_path = self.blobs_dir / blob_name
                
                if blob_path.exists():
                    with gzip.open(blob_path, 'rb') as f:
                        data['content'] = pickle.load(f)
                else:
                    logger.warning(f"Blob file not found: {blob_path}")
                    data['content'] = None
            
            # Create memory entry
            entry = MemoryEntry.from_dict(data)
            
            # Update access
            self._update_access(entry)
            
            # Save updated access info back to file
            await self._save_memory_to_file(entry, file_path.parent)
            
            return entry
            
        except Exception as e:
            logger.error(f"Failed to load memory {memory_id}: {e}")
            return None
    
    async def search(
        self,
        query: Optional[str] = None,
        memory_type: Optional[MemoryType] = None,
        tags: Optional[List[str]] = None,
        min_importance: float = 0.0,
        max_results: int = 100,
        include_embeddings: bool = False
    ) -> List[MemoryEntry]:
        """Search memories with various criteria"""
        with self.lock:
            results = []
            
            # Search in-memory stores first
            for memory in list(self.working_memory.values()) + list(self.ghost_memory.values()):
                if self._matches_criteria(memory, memory_type, tags, min_importance):
                    results.append(memory)
            
            # Search file storage
            candidate_ids = set()
            
            # Filter by type if specified
            if memory_type:
                type_candidates = self.type_index.get(memory_type.value, [])
                candidate_ids.update(type_candidates)
            else:
                candidate_ids.update(self.main_index.keys())
            
            # Filter by tags if specified
            if tags:
                tag_candidates = set()
                for tag in tags:
                    tag_candidates.update(self.tag_index.get(tag, []))
                candidate_ids.intersection_update(tag_candidates)
            
            # Load and filter candidates
            for memory_id in candidate_ids:
                if len(results) >= max_results:
                    break
                
                memory = await self._load_memory_from_file(memory_id)
                if memory and self._matches_criteria(memory, memory_type, tags, min_importance):
                    results.append(memory)
            
            # Sort by importance and recency
            results.sort(key=lambda m: (m.importance, m.timestamp), reverse=True)
            
            return results[:max_results]
    
    async def find_similar(
        self,
        embedding: np.ndarray,
        memory_type: Optional[MemoryType] = None,
        threshold: float = 0.7,
        max_results: int = 10
    ) -> List[Tuple[MemoryEntry, float]]:
        """Find memories with similar embeddings"""
        similar_memories = []
        
        with self.lock:
            # Search in-memory stores
            for memory in list(self.working_memory.values()) + list(self.ghost_memory.values()):
                if memory.embedding is not None:
                    if memory_type is None or memory.type == memory_type:
                        similarity = self._cosine_similarity(embedding, memory.embedding)
                        if similarity >= threshold:
                            similar_memories.append((memory, similarity))
            
            # Search file storage - only load memories that might have embeddings
            for memory_id in self.main_index.keys():
                if len(similar_memories) >= max_results * 2:  # Load extra for filtering
                    break
                
                memory = await self._load_memory_from_file(memory_id)
                if memory and memory.embedding is not None:
                    if memory_type is None or memory.type == memory_type:
                        similarity = self._cosine_similarity(embedding, memory.embedding)
                        if similarity >= threshold:
                            similar_memories.append((memory, similarity))
            
            # Sort by similarity
            similar_memories.sort(key=lambda x: x[1], reverse=True)
            
            return similar_memories[:max_results]
    
    async def update(
        self,
        memory_id: str,
        content: Optional[Any] = None,
        metadata: Optional[Dict[str, Any]] = None,
        importance: Optional[float] = None,
        tags: Optional[List[str]] = None
    ) -> bool:
        """Update an existing memory"""
        with self.lock:
            # Find memory
            memory = await self.retrieve(memory_id)
            if not memory:
                return False
            
            # Update fields
            if content is not None:
                memory.content = content
            if metadata is not None:
                memory.metadata.update(metadata)
            if importance is not None:
                memory.importance = importance
            
            # Update in appropriate store
            if memory.type == MemoryType.WORKING:
                self.working_memory[memory_id] = memory
                await self._save_memory_to_file(memory, self.working_dir)
            elif memory.type == MemoryType.GHOST:
                self.ghost_memory[memory_id] = memory
                await self._save_memory_to_file(memory, self.ghost_dir)
            else:
                await self._save_memory_to_file(memory, self.memories_dir)
                self._update_indices(memory_id, memory.type, tags)
            
            return True
    
    async def delete(self, memory_id: str) -> bool:
        """Delete a memory"""
        with self.lock:
            # Remove from in-memory stores
            if memory_id in self.working_memory:
                del self.working_memory[memory_id]
                # Remove file
                file_path = self.working_dir / f"{memory_id}.json"
                if file_path.exists():
                    file_path.unlink()
                return True
            
            if memory_id in self.ghost_memory:
                del self.ghost_memory[memory_id]
                # Remove file
                file_path = self.ghost_dir / f"{memory_id}.json"
                if file_path.exists():
                    file_path.unlink()
                return True
            
            # Remove from file storage
            return await self._delete_from_files(memory_id)
    
    async def _delete_from_files(self, memory_id: str) -> bool:
        """Delete memory from file storage"""
        try:
            if memory_id not in self.main_index:
                return False
            
            # Get file path
            file_path = self.storage_path / self.main_index[memory_id]
            
            # Remove blob if exists
            blob_path = self.blobs_dir / f"{memory_id}.pkl.gz"
            if blob_path.exists():
                blob_path.unlink()
            
            # Remove memory file
            if file_path.exists():
                file_path.unlink()
            
            # Remove from indices
            del self.main_index[memory_id]
            
            # Remove from type index
            for memory_type, ids in self.type_index.items():
                if memory_id in ids:
                    ids.remove(memory_id)
                    break
            
            # Remove from tag index
            for tag, ids in self.tag_index.items():
                if memory_id in ids:
                    ids.remove(memory_id)
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to delete memory {memory_id}: {e}")
            return False
    
    def consolidate(self) -> Dict[str, Any]:
        """Consolidate and optimize memory storage"""
        with self.lock:
            stats = {
                'working_memory_size': len(self.working_memory),
                'ghost_memory_size': len(self.ghost_memory),
                'file_storage_size': len(self.main_index),
                'consolidated': 0,
                'deleted': 0
            }
            
            # Move important working memories to persistent storage
            for memory_id, memory in list(self.working_memory.items()):
                if memory.importance > 0.7 and memory.access_count > 5:
                    asyncio.create_task(self._save_memory_to_file(memory, self.memories_dir))
                    del self.working_memory[memory_id]
                    stats['consolidated'] += 1
            
            # Clean up old, low-importance memories
            current_time = time.time()
            to_delete = []
            
            for memory_id in self.main_index.keys():
                memory_task = asyncio.create_task(self._load_memory_from_file(memory_id))
                try:
                    memory = asyncio.run(memory_task)
                    if memory:
                        # Delete if old and unimportant
                        age_days = (current_time - memory.timestamp) / 86400
                        if memory.importance < 0.1 and age_days > 30:
                            to_delete.append(memory_id)
                except:
                    pass
            
            # Delete old memories
            for memory_id in to_delete:
                asyncio.create_task(self._delete_from_files(memory_id))
                stats['deleted'] += 1
            
            # Save updated indices
            self._save_indices()
            
            logger.info(f"Memory consolidation complete: {stats}")
            return stats
    
    def _generate_id(self, content: Any, metadata: Optional[Dict[str, Any]]) -> str:
        """Generate unique ID for memory using unified ID system"""
        try:
            from .unified_id_generator import generate_memory_id
            return generate_memory_id(content, metadata)
        except ImportError:
            # Fallback to legacy format if unified generator not available
            content_str = str(content)
            metadata_str = json.dumps(metadata or {}, sort_keys=True)
            combined = f"{content_str}:{metadata_str}:{time.time()}"
            
            return hashlib.sha256(combined.encode()).hexdigest()[:16]
    
    def _update_access(self, memory: MemoryEntry):
        """Update access statistics"""
        memory.access_count += 1
        memory.last_accessed = time.time()
        self.access_cache[memory.id] = time.time()
    
    def _update_indices(self, memory_id: str, memory_type: MemoryType, tags: Optional[List[str]]):
        """Update file-based indices"""
        # Update type index
        type_name = memory_type.value
        if type_name not in self.type_index:
            self.type_index[type_name] = []
        if memory_id not in self.type_index[type_name]:
            self.type_index[type_name].append(memory_id)
        
        # Update tag index
        if tags:
            for tag in tags:
                if tag not in self.tag_index:
                    self.tag_index[tag] = []
                if memory_id not in self.tag_index[tag]:
                    self.tag_index[tag].append(memory_id)
    
    def _matches_criteria(
        self,
        memory: MemoryEntry,
        memory_type: Optional[MemoryType],
        tags: Optional[List[str]],
        min_importance: float
    ) -> bool:
        """Check if memory matches search criteria"""
        if memory_type and memory.type != memory_type:
            return False
        
        if memory.importance < min_importance:
            return False
        
        # Simple tag matching (could be enhanced)
        if tags:
            memory_tags = memory.metadata.get('tags', [])
            if not any(tag in memory_tags for tag in tags):
                return False
        
        return True
    
    def _cosine_similarity(self, vec1: np.ndarray, vec2: np.ndarray) -> float:
        """Calculate cosine similarity between vectors"""
        dot_product = np.dot(vec1, vec2)
        norm1 = np.linalg.norm(vec1)
        norm2 = np.linalg.norm(vec2)
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return dot_product / (norm1 * norm2)
    
    def _apply_decay(self):
        """Apply decay to memories based on access patterns"""
        current_time = time.time()
        
        # Only apply to file-stored memories
        for memory_id in list(self.main_index.keys()):
            try:
                memory = asyncio.run(self._load_memory_from_file(memory_id))
                if memory:
                    # Calculate decay
                    time_since_access = current_time - (memory.last_accessed or memory.timestamp)
                    days_since_access = time_since_access / 86400
                    
                    if days_since_access > 1:  # Only decay after 24 hours
                        decay_factor = 0.99 ** days_since_access
                        
                        # Adjust importance
                        new_importance = memory.importance * decay_factor
                        
                        # Boost based on access count
                        access_boost = min(0.1, memory.access_count / 100.0)
                        new_importance = min(1.0, new_importance + access_boost)
                        
                        # Update if changed significantly
                        if abs(memory.importance - new_importance) > 0.01:
                            memory.importance = new_importance
                            asyncio.run(self._save_memory_to_file(memory, self.memories_dir))
                            
            except Exception as e:
                logger.debug(f"Decay error for {memory_id}: {e}")
        
        logger.debug("Memory decay applied")
    
    def _cleanup_ghost_memory(self):
        """Remove expired ghost memories"""
        current_time = time.time()
        expired = []
        
        with self.lock:
            for memory_id, memory in self.ghost_memory.items():
                age = current_time - memory.timestamp
                if age > self.ghost_memory_ttl:
                    expired.append(memory_id)
            
            for memory_id in expired:
                del self.ghost_memory[memory_id]
                # Remove file
                file_path = self.ghost_dir / f"{memory_id}.json"
                if file_path.exists():
                    file_path.unlink()
            
            if expired:
                logger.debug(f"Cleaned up {len(expired)} expired ghost memories")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get memory vault statistics"""
        with self.lock:
            # Calculate storage sizes
            total_size = 0
            for directory in [self.memories_dir, self.blobs_dir, self.working_dir, self.ghost_dir]:
                for file_path in directory.rglob('*'):
                    if file_path.is_file():
                        total_size += file_path.stat().st_size
            
            stats = {
                'total_memories': (
                    len(self.working_memory) + 
                    len(self.ghost_memory) + 
                    len(self.main_index)
                ),
                'working_memory_count': len(self.working_memory),
                'ghost_memory_count': len(self.ghost_memory),
                'file_storage_count': len(self.main_index),
                'storage_path': str(self.storage_path),
                'total_size_mb': total_size / (1024 * 1024),
                'storage_type': 'FILE-BASED (NO DATABASE)',
                'type_distribution': dict(self.type_index),
                'tag_count': len(self.tag_index)
            }
            
            return stats
    
    def export_memories(self, export_path: Path, memory_type: Optional[MemoryType] = None) -> int:
        """Export memories to JSON file"""
        memories_to_export = []
        
        with self.lock:
            # Collect from all sources
            all_memories = []
            
            # In-memory
            all_memories.extend(self.working_memory.values())
            all_memories.extend(self.ghost_memory.values())
            
            # File storage
            for memory_id in self.main_index.keys():
                memory = asyncio.run(self._load_memory_from_file(memory_id))
                if memory:
                    all_memories.append(memory)
            
            # Convert to exportable format
            for memory in all_memories:
                if memory_type is None or memory.type == memory_type:
                    memories_to_export.append(memory.to_dict())
        
        # Write to file
        with open(export_path, 'w') as f:
            json.dump(memories_to_export, f, indent=2)
        
        logger.info(f"Exported {len(memories_to_export)} memories to {export_path}")
        return len(memories_to_export)
    
    def import_memories(self, import_path: Path) -> int:
        """Import memories from JSON file"""
        with open(import_path, 'r') as f:
            memories_data = json.load(f)
        
        imported = 0
        for memory_data in memories_data:
            try:
                memory = MemoryEntry.from_dict(memory_data)
                asyncio.run(self.store(
                    content=memory.content,
                    memory_type=memory.type,
                    metadata=memory.metadata,
                    embedding=memory.embedding,
                    importance=memory.importance
                ))
                imported += 1
            except Exception as e:
                logger.error(f"Failed to import memory: {e}")
        
        logger.info(f"Imported {imported} memories from {import_path}")
        return imported
    
    def backup(self, backup_path: Path):
        """Create a backup of the entire memory vault"""
        backup_path.mkdir(parents=True, exist_ok=True)
        
        # Copy entire storage directory
        shutil.copytree(self.storage_path, backup_path / 'memory_vault', dirs_exist_ok=True)
        
        # Save metadata
        metadata = {
            'backup_time': time.time(),
            'backup_date': datetime.now().isoformat(),
            'statistics': self.get_statistics()
        }
        
        with open(backup_path / 'backup_metadata.json', 'w') as f:
            json.dump(metadata, f, indent=2)
        
        logger.info(f"Memory vault backed up to {backup_path}")
    
    def restore(self, backup_path: Path):
        """Restore memory vault from backup"""
        backup_vault_path = backup_path / 'memory_vault'
        
        if not backup_vault_path.exists():
            raise ValueError(f"Backup not found at {backup_path}")
        
        # Remove current storage
        if self.storage_path.exists():
            shutil.rmtree(self.storage_path)
        
        # Copy backup
        shutil.copytree(backup_vault_path, self.storage_path)
        
        # Reload indices
        self._load_indices()
        
        logger.info(f"Memory vault restored from {backup_path}")
    
    def save_all(self):
        """
        Save all memories to disk - called during shutdown.
        This is the method that enhanced_launcher.py expects.
        """
        try:
            with self.lock:
                # Save all in-memory working memories
                for memory_id, memory in self.working_memory.items():
                    asyncio.run(self._save_memory_to_file(memory, self.working_dir))
                
                # Save all ghost memories
                for memory_id, memory in self.ghost_memory.items():
                    asyncio.run(self._save_memory_to_file(memory, self.ghost_dir))
                
                # Save indices
                self._save_indices()
                
                # Save seen hashes for deduplication
                self._save_seen_hashes()
                
                # Write final snapshot
                self._write_snapshot()
                
                # Write session summary
                session_summary = {
                    'session_id': self.session_id,
                    'start_time': self.session_id,  # Encoded in ID
                    'end_time': datetime.now().strftime("%Y%m%d_%H%M%S"),
                    'total_entries': len(self.working_memory) + len(self.ghost_memory) + len(self.main_index),
                    'entries_by_type': {
                        'working': len(self.working_memory),
                        'ghost': len(self.ghost_memory),
                        'persistent': len(self.main_index)
                    },
                    'log_files': {
                        'live_log': str(self.live_log_path),
                        'session_log': str(self.session_log_path),
                        'snapshot': str(self.snapshot_path)
                    }
                }
                
                summary_path = self.logs_dir / f'session_{self.session_id}_summary.json'
                with open(summary_path, 'w', encoding='utf-8') as f:
                    json.dump(session_summary, f, indent=2)
                
                logger.info("✅ UnifiedMemoryVault saved all memories to disk")
                logger.info(f"  - Working memories: {len(self.working_memory)}")
                logger.info(f"  - Ghost memories: {len(self.ghost_memory)}")
                logger.info(f"  - Indexed memories: {len(self.main_index)}")
                logger.info(f"  - Session logs: {self.session_log_path}")
                logger.info(f"  - Final snapshot: {self.snapshot_path}")
        except Exception as e:
            logger.error(f"❌ Failed to save UnifiedMemoryVault: {e}")
    
    def get_status(self):
        """
        Get memory vault status for observability.
        """
        return {
            "entries": len(self.main_index) + len(self.working_memory) + len(self.ghost_memory),
            "working_memory": len(self.working_memory),
            "ghost_memory": len(self.ghost_memory),
            "file_storage": len(self.main_index),
            "path": str(self.storage_path),
            "last_modified": datetime.fromtimestamp(
                max([p.stat().st_mtime for p in self.storage_path.rglob('*') if p.is_file()], default=0)
            ).isoformat() if any(self.storage_path.rglob('*')) else "Never"
        }
    
    def shutdown(self):
        """Cleanup and shutdown"""
        with self.lock:
            # Save all memories first
            self.save_all()
            
            # Final consolidation
            self.consolidate()
            
            logger.info("UnifiedMemoryVault shutdown complete")

# Example usage
if __name__ == "__main__":
    async def test_memory_vault():
        """Test the unified memory vault"""
        config = {
            'storage_path': 'data/memory_test',
            'max_working_memory': 50,
            'ghost_memory_ttl': 60  # 1 minute for testing
        }
        
        vault = UnifiedMemoryVault(config)
        
        # Test different memory types
        print("Testing memory storage (FILE-BASED)...")
        
        # Working memory
        work_id = await vault.store(
            "Current task context",
            MemoryType.WORKING,
            metadata={'task': 'testing', 'tags': ['work']}
        )
        print(f"Working memory stored: {work_id}")
        
        # Semantic memory
        semantic_id = await vault.store(
            "The sky is blue",
            MemoryType.SEMANTIC,
            metadata={'category': 'facts', 'tags': ['science', 'nature']},
            importance=0.9
        )
        print(f"Semantic memory stored: {semantic_id}")
        
        # Ghost memory
        ghost_id = await vault.store(
            "Temporary thought",
            MemoryType.GHOST,
            metadata={'ephemeral': True, 'tags': ['temp']}
        )
        print(f"Ghost memory stored: {ghost_id}")
        
        # Test retrieval
        print("\nTesting retrieval...")
        memory = await vault.retrieve(semantic_id)
        if memory:
            print(f"Retrieved: {memory.content} (importance: {memory.importance})")
        
        # Test search
        print("\nTesting search...")
        results = await vault.search(
            memory_type=MemoryType.SEMANTIC,
            tags=['science']
        )
        print(f"Found {len(results)} semantic memories with 'science' tag")
        
        # Test similarity search with random embedding
        print("\nTesting similarity search...")
        test_embedding = np.random.randn(128)
        
        # Store with embedding
        embed_id = await vault.store(
            "Content with embedding",
            MemoryType.SEMANTIC,
            embedding=test_embedding,
            metadata={'tags': ['embedding']}
        )
        
        # Find similar
        similar = await vault.find_similar(test_embedding, threshold=0.8)
        print(f"Found {len(similar)} similar memories")
        
        # Get statistics
        stats = vault.get_statistics()
        print(f"\nMemory vault statistics:")
        print(f"  Storage type: {stats['storage_type']}")
        print(f"  Total memories: {stats['total_memories']}")
        print(f"  Storage size: {stats['total_size_mb']:.2f} MB")
        print(f"  Type distribution: {stats['type_distribution']}")
        
        vault.shutdown()
    
    # Run test
    asyncio.run(test_memory_vault())
