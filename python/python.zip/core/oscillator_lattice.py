#!/usr/bin/env python3
"""
Oscillator Lattice – dynamic phase-tagged memory core
Implements a light Kuramoto-style update plus hooks for Hebbian coupling.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Sequence
import numpy as np
import math
import logging

logger = logging.getLogger(__name__)
PI2 = 2.0 * math.pi


from enum import Enum

# Import adaptive timestep control
try:
    from python.core.adaptive_timestep import AdaptiveTimestep
    ADAPTIVE_DT_AVAILABLE = True
except ImportError:
    ADAPTIVE_DT_AVAILABLE = False

# Import Lyapunov monitoring
try:
    from alan_backend.lyap_exporter import get_lyapunov_exporter
    LYAP_AVAILABLE = True
except ImportError:
    LYAP_AVAILABLE = False

class SolitonPolarity(Enum):
    """Polarity for soliton types"""
    BRIGHT = "bright"  # Positive amplitude peak
    DARK = "dark"      # Negative amplitude dip

@dataclass
class Oscillator:
    """Single phase oscillator representing a stored memory."""
    phase: float                    # rad
    natural_freq: float             # rad/s
    amplitude: float = 1.0
    stability: float = 1.0
    polarity: SolitonPolarity = SolitonPolarity.BRIGHT  # Support dark solitons
    
    def step(self, dt: float, coupling_term: float) -> None:
        """Advance phase by dt with an external coupling contribution."""
        # Sign-safe update for dark solitons
        if self.polarity == SolitonPolarity.DARK:
            # Dark solitons have inverted coupling response
            effective_coupling = -coupling_term * abs(self.amplitude)
        else:
            effective_coupling = coupling_term * self.amplitude
            
        self.phase += (self.natural_freq + effective_coupling) * dt
        self.phase %= PI2  # keep phase in [0, 2π)


@dataclass
class OscillatorLattice:
    """Collection of oscillators + coupling matrix K_ij."""
    oscillators: List[Oscillator] = field(default_factory=list)
    K: Optional[np.ndarray] = None  # shape = (N, N)
    
    # Adaptive timestep control
    adaptive_dt: Optional[AdaptiveTimestep] = None
    use_adaptive_dt: bool = True
    _steps_counter: int = 0
    _lyap_update_interval: int = 256  # Update Lyapunov every N steps
    
    def _ensure_K(self) -> None:
        n = len(self.oscillators)
        if self.K is None or self.K.shape != (n, n):
            self.K = np.zeros((n, n), dtype=np.float32)
    
    # ---------- public API ---------- #
    def add_oscillator(self,
                       phase: float,
                       natural_freq: float = 0.0,
                       amplitude: float = 1.0,
                       stability: float = 1.0,
                       polarity: SolitonPolarity = SolitonPolarity.BRIGHT) -> int:
        """Append a new oscillator; return its index."""
        self.oscillators.append(
            Oscillator(phase, natural_freq, amplitude, stability, polarity)
        )
        self._ensure_K()
        return len(self.oscillators) - 1
    
    def set_coupling(self, i: int, j: int, value: float) -> None:
        self._ensure_K()
        self.K[i, j] = value
    
    # ---------- simulation ---------- #
    def step(self, dt: float) -> None:
        """Euler-integrate one lattice tick with adaptive timestep."""
        if not self.oscillators:
            return
        
        self._ensure_K()
        phases = np.array([o.phase for o in self.oscillators], dtype=np.float32)
        
        # Initialize adaptive timestep if needed
        if self.use_adaptive_dt and ADAPTIVE_DT_AVAILABLE and self.adaptive_dt is None:
            self.adaptive_dt = AdaptiveTimestep(dt_base=dt)
        
        # Update Lyapunov monitoring periodically
        lambda_max = 0.0
        if LYAP_AVAILABLE and self._steps_counter % self._lyap_update_interval == 0:
            try:
                # Construct state for Lyapunov monitoring
                amplitudes = np.array([o.amplitude for o in self.oscillators])
                psi0 = amplitudes * np.exp(1j * phases)
                
                state = {
                    'psi0': psi0,
                    'lattice': self,
                    'g': 1.0,  # Nonlinearity parameter
                    'dx': 1.0  # Spatial discretization
                }
                
                exporter = get_lyapunov_exporter()
                lambda_max = exporter.update_watchlist(state)
                logger.debug(f"Lattice step {self._steps_counter}: lambda_max = {lambda_max}")
            except Exception as e:
                logger.warning(f"Lyapunov update failed: {e}")
        
        # Compute adaptive timestep
        effective_dt = dt
        if self.use_adaptive_dt and self.adaptive_dt is not None:
            effective_dt = self.adaptive_dt.compute_timestep(lambda_max)
            logger.debug(f"Adaptive dt: {effective_dt} (base: {dt}, lambda_max: {lambda_max})")
        
        # Kuramoto coupling term for each oscillator with polarity-aware handling
        amplitudes = np.array([o.amplitude * (-1 if o.polarity == SolitonPolarity.DARK else 1) 
                              for o in self.oscillators], dtype=np.float32)
        
        # Sign-safe coupling that preserves dark soliton stability
        phase_diff = phases[np.newaxis, :] - phases[:, np.newaxis]
        weighted_coupling = self.K * amplitudes[np.newaxis, :] * np.sin(phase_diff)
        coupling = weighted_coupling.sum(axis=1)
        
        for osc, dpsi in zip(self.oscillators, coupling):
            osc.step(effective_dt, dpsi)
        
        # Increment step counter
        self._steps_counter += 1
    
    # ---------- analytics ---------- #
    def order_parameter(self) -> float:
        """Kuramoto global order parameter R ∈ [0, 1]."""
        if not self.oscillators:
            return 0.0
        
        phases = np.array([o.phase for o in self.oscillators])
        R = np.abs(np.exp(1j * phases).mean())
        return float(R)
    
    def phase_entropy(self, bins: int = 36) -> float:
        """Shannon entropy of the phase distribution."""
        if not self.oscillators:
            return 0.0
        
        phases = np.array([o.phase for o in self.oscillators])
        hist, _ = np.histogram(phases, bins=bins, range=(0.0, PI2), density=True)
        p = hist + 1e-12  # avoid log(0)
        return float(-np.sum(p * np.log(p)) / math.log(bins))


# Easy singleton – optional but convenient
_GLOBAL_LATTICE: OscillatorLattice | None = None


def get_global_lattice() -> OscillatorLattice:
    global _GLOBAL_LATTICE
    if _GLOBAL_LATTICE is None:
        _GLOBAL_LATTICE = OscillatorLattice()
    return _GLOBAL_LATTICE
