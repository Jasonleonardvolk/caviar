#!/usr/bin/env python3
"""
Intent-Driven Reasoning System
Adds intent parsing, conflict resolution, and self-reflective capabilities
"""

from typing import List, Dict, Any, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timezone
import logging
import json
import numpy as np

from python.core.reasoning_traversal import (
    ReasoningPath, ConceptNode, EdgeType
)
from python.core.temporal_reasoning_integration import (
    TemporalConceptMesh
)

logger = logging.getLogger(__name__)

# ========== Intent Types ==========

class ReasoningIntent(Enum):
    """Types of reasoning intent"""
    EXPLAIN = "explain"          # General explanation
    JUSTIFY = "justify"          # Provide justification
    CAUSAL = "causal"           # Focus on cause-effect
    SUPPORT = "support"         # Find supporting evidence
    HISTORICAL = "historical"   # Historical perspective
    COMPARE = "compare"         # Compare alternatives
    CRITIQUE = "critique"       # Critical analysis
    SPECULATE = "speculate"     # Hypothetical reasoning

class PathStrategy(Enum):
    """Path selection strategies"""
    SHORTEST = "shortest"        # Prefer direct paths
    COMPREHENSIVE = "comprehensive"  # Include all relevant paths
    RECENT = "recent"           # Prefer recent knowledge
    TRUSTED = "trusted"         # Prefer highly-rated sources
    DIVERSE = "diverse"         # Include different perspectives

# ========== Resolution Report ==========

@dataclass
class ResolutionReport:
    """Report on conflict resolution between paths"""
    winning_path: Optional[ReasoningPath]
    discarded_paths: List[ReasoningPath]
    conflicts: List[Dict[str, Any]]
    confidence_gap: float
    explanation: str
    resolution_strategy: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "winning_path": self.winning_path.to_dict() if self.winning_path else None,
            "discarded_paths": [p.to_dict() for p in self.discarded_paths],
            "conflicts": self.conflicts,
            "confidence_gap": self.confidence_gap,
            "explanation": self.explanation,
            "resolution_strategy": self.resolution_strategy,
            "metadata": self.metadata
        }

# ========== Intent Parser ==========

class ReasoningIntentParser:
    """Parse user intent from queries"""
    
    def __init__(self):
        # Intent keywords mapping
        self.intent_keywords = {
            ReasoningIntent.EXPLAIN: ["explain", "what", "describe", "tell me about"],
            ReasoningIntent.JUSTIFY: ["why", "justify", "reason", "rationale"],
            ReasoningIntent.CAUSAL: ["cause", "because", "lead to", "result in"],
            ReasoningIntent.SUPPORT: ["evidence", "support", "prove", "back up"],
            ReasoningIntent.HISTORICAL: ["history", "evolution", "how has", "changed over time"],
            ReasoningIntent.COMPARE: ["compare", "versus", "difference", "alternative"],
            ReasoningIntent.CRITIQUE: ["critique", "problem", "issue", "flaw"],
            ReasoningIntent.SPECULATE: ["what if", "hypothetically", "imagine", "suppose"]
        }
        
        # Strategy preferences by intent
        self.intent_strategies = {
            ReasoningIntent.EXPLAIN: PathStrategy.COMPREHENSIVE,
            ReasoningIntent.JUSTIFY: PathStrategy.TRUSTED,
            ReasoningIntent.CAUSAL: PathStrategy.SHORTEST,
            ReasoningIntent.SUPPORT: PathStrategy.DIVERSE,
            ReasoningIntent.HISTORICAL: PathStrategy.RECENT,
            ReasoningIntent.COMPARE: PathStrategy.DIVERSE,
            ReasoningIntent.CRITIQUE: PathStrategy.COMPREHENSIVE,
            ReasoningIntent.SPECULATE: PathStrategy.DIVERSE
        }
    
    def parse_intent(self, query: str, context: Optional[Dict[str, Any]] = None) -> Tuple[ReasoningIntent, PathStrategy]:
        """Parse reasoning intent from query"""
        query_lower = query.lower()
        
        # Check explicit intent in context
        if context and 'intent' in context:
            intent_str = context['intent']
            try:
                intent = ReasoningIntent(intent_str)
                strategy = self.intent_strategies.get(intent, PathStrategy.COMPREHENSIVE)
                return intent, strategy
            except ValueError:
                pass
        
        # Infer from query keywords
        intent_scores = {}
        for intent, keywords in self.intent_keywords.items():
            score = sum(1 for keyword in keywords if keyword in query_lower)
            if score > 0:
                intent_scores[intent] = score
        
        # Select highest scoring intent
        if intent_scores:
            best_intent = max(intent_scores.items(), key=lambda x: x[1])[0]
        else:
            best_intent = ReasoningIntent.EXPLAIN  # Default
        
        # Get corresponding strategy
        strategy = self.intent_strategies.get(best_intent, PathStrategy.COMPREHENSIVE)
        
        # Override strategy if specified
        if context and 'strategy' in context:
            try:
                strategy = PathStrategy(context['strategy'])
            except ValueError:
                pass
        
        return best_intent, strategy

# ========== Conflict Resolution Engine ==========

class CognitiveResolutionEngine:
    """Resolve conflicts between reasoning paths"""
    
    def __init__(self, mesh: TemporalConceptMesh):
        self.mesh = mesh
        self.trust_scores = {}  # Source trust ratings
        
    def resolve_conflicts(self, paths: List[ReasoningPath], 
                         intent: ReasoningIntent = ReasoningIntent.EXPLAIN,
                         strategy: PathStrategy = PathStrategy.COMPREHENSIVE) -> ResolutionReport:
        """Resolve conflicts between multiple reasoning paths"""
        
        if not paths:
            return ResolutionReport(
                winning_path=None,
                discarded_paths=[],
                conflicts=[],
                confidence_gap=0.0,
                explanation="No paths to resolve",
                resolution_strategy="none"
            )
        
        # Detect conflicts
        conflicts = self._detect_conflicts(paths)
        
        # Score paths based on multiple criteria
        scored_paths = []
        for path in paths:
            score = self._score_path(path, intent, strategy)
            scored_paths.append((score, path))
        
        # Sort by score
        scored_paths.sort(key=lambda x: x[0], reverse=True)
        
        # Select winner
        if scored_paths:
            winning_score, winning_path = scored_paths[0]
            discarded_paths = [p for _, p in scored_paths[1:]]
            
            # Calculate confidence gap
            if len(scored_paths) > 1:
                confidence_gap = winning_score - scored_paths[1][0]
            else:
                confidence_gap = winning_score
            
            # Generate explanation
            explanation = self._generate_resolution_explanation(
                winning_path, discarded_paths, conflicts, intent, strategy
            )
            
            resolution_strategy = f"{intent.value}_{strategy.value}"
        else:
            winning_path = None
            discarded_paths = paths
            confidence_gap = 0.0
            explanation = "No valid paths after scoring"
            resolution_strategy = "failed"
        
        return ResolutionReport(
            winning_path=winning_path,
            discarded_paths=discarded_paths,
            conflicts=conflicts,
            confidence_gap=confidence_gap,
            explanation=explanation,
            resolution_strategy=resolution_strategy,
            metadata={
                "intent": intent.value,
                "strategy": strategy.value,
                "total_paths": len(paths),
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
        )
    
    def _detect_conflicts(self, paths: List[ReasoningPath]) -> List[Dict[str, Any]]:
        """Detect logical conflicts between paths"""
        conflicts = []
        
        # Check for contradictory conclusions
        conclusions = {}
        for i, path in enumerate(paths):
            if path.chain:
                last_node = path.chain[-1]
                if last_node.id in conclusions:
                    # Found paths with same conclusion but different routes
                    other_idx = conclusions[last_node.id]
                    if self._paths_contradict(paths[other_idx], path):
                        conflicts.append({
                            "type": "contradictory_routes",
                            "path1_idx": other_idx,
                            "path2_idx": i,
                            "node": last_node.id,
                            "description": f"Different routes to {last_node.name}"
                        })
                else:
                    conclusions[last_node.id] = i
        
        # Check for opposing relationships
        for i, path1 in enumerate(paths):
            for j, path2 in enumerate(paths[i+1:], i+1):
                if self._has_opposing_edges(path1, path2):
                    conflicts.append({
                        "type": "opposing_relationships",
                        "path1_idx": i,
                        "path2_idx": j,
                        "description": "Paths contain opposing relationships"
                    })
        
        return conflicts
    
    def _paths_contradict(self, path1: ReasoningPath, path2: ReasoningPath) -> bool:
        """Check if two paths contradict each other"""
        # Check for CONTRADICTS edges
        for just in path1.edge_justifications:
            if "contradict" in just.lower():
                return True
        for just in path2.edge_justifications:
            if "contradict" in just.lower():
                return True
        
        # Could add more sophisticated contradiction detection
        return False
    
    def _has_opposing_edges(self, path1: ReasoningPath, path2: ReasoningPath) -> bool:
        """Check if paths have opposing edge types"""
        edges1 = set(path1.edge_justifications)
        edges2 = set(path2.edge_justifications)
        
        opposing_pairs = [
            ("supports", "contradicts"),
            ("enables", "prevents"),
            ("causes", "prevents")
        ]
        
        for e1 in edges1:
            for e2 in edges2:
                for pair in opposing_pairs:
                    if (e1 in pair[0] and e2 in pair[1]) or (e1 in pair[1] and e2 in pair[0]):
                        return True
        
        return False
    
    def _score_path(self, path: ReasoningPath, intent: ReasoningIntent, 
                   strategy: PathStrategy) -> float:
        """Score a path based on intent and strategy"""
        score = path.score  # Base score
        
        # Intent-based scoring
        if intent == ReasoningIntent.CAUSAL:
            # Prefer paths with causal edges
            causal_count = sum(1 for j in path.edge_justifications 
                             if any(word in j for word in ["causes", "because", "leads to"]))
            score *= (1 + 0.2 * causal_count)
        
        elif intent == ReasoningIntent.SUPPORT:
            # Prefer paths with supporting evidence
            support_count = sum(1 for j in path.edge_justifications 
                              if "support" in j)
            score *= (1 + 0.2 * support_count)
        
        elif intent == ReasoningIntent.HISTORICAL:
            # Prefer paths that show evolution
            if "evolved" in " ".join(path.edge_justifications):
                score *= 1.5
        
        # Strategy-based scoring
        if strategy == PathStrategy.SHORTEST:
            # Penalize long paths
            score *= (1.0 / (1.0 + len(path.chain) * 0.1))
        
        elif strategy == PathStrategy.RECENT:
            # Boost recent paths (already handled in temporal scoring)
            pass
        
        elif strategy == PathStrategy.TRUSTED:
            # Boost paths from trusted sources
            trust_boost = self._calculate_trust_score(path)
            score *= trust_boost
        
        elif strategy == PathStrategy.DIVERSE:
            # This would need context of other selected paths
            pass
        
        # Penalize deprecated or scarred nodes
        for node in path.chain:
            if self._is_deprecated(node):
                score *= 0.5
            if self._is_scarred(node):
                score *= 0.7
        
        return score
    
    def _calculate_trust_score(self, path: ReasoningPath) -> float:
        """Calculate trust score based on sources"""
        if not path.chain:
            return 1.0
        
        trust_sum = 0.0
        source_count = 0
        
        for node in path.chain:
            for source in node.sources:
                # Simple heuristic - could be replaced with actual trust DB
                if "arxiv" in source.lower():
                    trust_sum += 0.9
                elif "nature" in source.lower() or "science" in source.lower():
                    trust_sum += 0.95
                elif "wiki" in source.lower():
                    trust_sum += 0.7
                else:
                    trust_sum += 0.8
                source_count += 1
        
        return trust_sum / source_count if source_count > 0 else 0.8
    
    def _is_deprecated(self, node: ConceptNode) -> bool:
        """Check if node is deprecated"""
        if hasattr(node, 'metadata') and isinstance(node.metadata, dict):
            return 'deprecated' in node.metadata
        return False
    
    def _is_scarred(self, node: ConceptNode) -> bool:
        """Check if node is scarred (outdated/problematic)"""
        # Check age
        now = datetime.now(timezone.utc)
        for source in node.sources:
            if "T" in source:  # Has timestamp
                try:
                    source_time = datetime.fromisoformat(source)
                    if (now - source_time).days > 365:  # Older than 1 year
                        return True
                except:
                    pass
        
        # Check for scar indicators
        if hasattr(node, 'metadata') and isinstance(node.metadata, dict):
            return node.metadata.get('scarred', False)
        
        return False
    
    def _generate_resolution_explanation(self, winning_path: Optional[ReasoningPath],
                                       discarded_paths: List[ReasoningPath],
                                       conflicts: List[Dict[str, Any]],
                                       intent: ReasoningIntent,
                                       strategy: PathStrategy) -> str:
        """Generate explanation for resolution decision"""
        explanation_parts = []
        
        if winning_path:
            # Explain why winner was chosen
            chain_str = " → ".join([n.name for n in winning_path.chain])
            explanation_parts.append(f"Selected path: {chain_str}")
            
            # Intent-specific reasoning
            if intent == ReasoningIntent.CAUSAL:
                causal_edges = [j for j in winning_path.edge_justifications 
                               if any(word in j for word in ["causes", "because"])]
                if causal_edges:
                    explanation_parts.append(f"This path shows clear causal relationships: {', '.join(causal_edges)}")
            
            elif intent == ReasoningIntent.SUPPORT:
                sources = [src for node in winning_path.chain for src in node.sources]
                explanation_parts.append(f"Supported by {len(sources)} sources")
            
            # Strategy-specific reasoning
            if strategy == PathStrategy.SHORTEST:
                explanation_parts.append(f"Shortest valid path with {len(winning_path.chain)} nodes")
            elif strategy == PathStrategy.TRUSTED:
                trust_score = self._calculate_trust_score(winning_path)
                explanation_parts.append(f"Highest trust score: {trust_score:.2f}")
        
        # Explain conflicts
        if conflicts:
            explanation_parts.append(f"Resolved {len(conflicts)} conflicts:")
            for conflict in conflicts[:2]:  # Show first 2
                explanation_parts.append(f"  - {conflict['description']}")
        
        # Explain discarded paths
        if discarded_paths:
            explanation_parts.append(f"Discarded {len(discarded_paths)} alternative paths")
            if len(discarded_paths) > 0:
                reasons = []
                for path in discarded_paths[:2]:
                    if self._has_deprecated_nodes(path):
                        reasons.append("contains deprecated concepts")
                    elif self._has_scarred_nodes(path):
                        reasons.append("contains outdated information")
                    elif path.score < 0.5:
                        reasons.append("low confidence score")
                
                if reasons:
                    explanation_parts.append(f"Reasons: {', '.join(set(reasons))}")
        
        return " ".join(explanation_parts)
    
    def _has_deprecated_nodes(self, path: ReasoningPath) -> bool:
        """Check if path contains deprecated nodes"""
        return any(self._is_deprecated(node) for node in path.chain)
    
    def _has_scarred_nodes(self, path: ReasoningPath) -> bool:
        """Check if path contains scarred nodes"""
        return any(self._is_scarred(node) for node in path.chain)

# ========== Self-Reflective Reasoning ==========

class SelfReflectiveReasoner:
    """Enable Prajna to explain its own reasoning decisions"""
    
    def __init__(self, resolution_engine: CognitiveResolutionEngine,
                 intent_parser: ReasoningIntentParser):
        self.resolution_engine = resolution_engine
        self.intent_parser = intent_parser
        self.reasoning_history = []  # Track decisions
    
    def explain_reasoning_decision(self, original_query: str,
                                  response: Any,
                                  resolution_report: ResolutionReport) -> str:
        """Explain why a particular answer was given"""
        explanation_parts = []
        
        # Start with meta-explanation
        explanation_parts.append("I arrived at this answer through the following reasoning process:")
        
        # Explain intent understanding
        intent, strategy = self.intent_parser.parse_intent(original_query)
        explanation_parts.append(f"\n1. Intent Recognition: I interpreted your question as seeking to {intent.value} "
                               f"and used a {strategy.value} approach.")
        
        # Explain path selection
        if resolution_report.winning_path:
            chain = " → ".join([n.name for n in resolution_report.winning_path.chain])
            explanation_parts.append(f"\n2. Reasoning Path: {chain}")
            
            # Explain each step
            explanation_parts.append("\n3. Step-by-step reasoning:")
            for i, node in enumerate(resolution_report.winning_path.chain):
                explanation_parts.append(f"   - {node.name}: {node.description}")
                if node.sources:
                    explanation_parts.append(f"     Source: {node.sources[0]}")
                
                if i < len(resolution_report.winning_path.edge_justifications):
                    edge = resolution_report.winning_path.edge_justifications[i]
                    explanation_parts.append(f"     ↳ {edge}")
        
        # Explain conflict resolution
        if resolution_report.conflicts:
            explanation_parts.append(f"\n4. Conflict Resolution: I found {len(resolution_report.conflicts)} "
                                   f"conflicting interpretations and resolved them by:")
            explanation_parts.append(f"   {resolution_report.explanation}")
        
        # Explain confidence
        if resolution_report.confidence_gap:
            explanation_parts.append(f"\n5. Confidence: The chosen path was {resolution_report.confidence_gap:.2f} "
                                   f"more confident than alternatives.")
        
        # Explain discarded alternatives
        if resolution_report.discarded_paths:
            explanation_parts.append(f"\n6. Alternatives Considered: I evaluated {len(resolution_report.discarded_paths)} "
                                   f"other reasoning paths but discarded them because:")
            
            # Sample reasons
            for path in resolution_report.discarded_paths[:2]:
                if self.resolution_engine._has_deprecated_nodes(path):
                    explanation_parts.append("   - One path relied on outdated concepts")
                elif path.score < 0.5:
                    explanation_parts.append("   - One path had insufficient evidence")
        
        # Meta-reflection
        explanation_parts.append("\n7. Reflection: This explanation represents my best current understanding "
                               "based on the knowledge available to me.")
        
        # Track in history
        self.reasoning_history.append({
            "query": original_query,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "intent": intent.value,
            "strategy": strategy.value,
            "confidence_gap": resolution_report.confidence_gap
        })
        
        return "\n".join(explanation_parts)
    
    def get_reasoning_history(self, last_n: int = 10) -> List[Dict[str, Any]]:
        """Get recent reasoning history"""
        return self.reasoning_history[-last_n:]

# ========== Scar and Overlay Detection ==========

class MeshOverlayManager:
    """Manage visual overlays for mesh state (scarred, deprecated, trusted)"""
    
    def __init__(self, mesh: TemporalConceptMesh):
        self.mesh = mesh
        self.overlays = {
            'scarred': set(),
            'deprecated': set(),
            'trusted': set(),
            'recent': set(),
            'contested': set()
        }
    
    def update_overlays(self):
        """Update all overlay categories"""
        now = datetime.now(timezone.utc)
        
        for node_id, node in self.mesh.nodes.items():
            # Check if scarred (old)
            is_old = False
            for source in node.sources:
                if "T" in source:
                    try:
                        source_time = datetime.fromisoformat(source)
                        if (now - source_time).days > 365:
                            is_old = True
                            break
                    except:
                        pass
            
            if is_old:
                self.overlays['scarred'].add(node_id)
            
            # Check if deprecated
            if hasattr(node, 'metadata') and isinstance(node.metadata, dict):
                if 'deprecated' in node.metadata:
                    self.overlays['deprecated'].add(node_id)
            
            # Check if recent (< 30 days)
            is_recent = False
            for source in node.sources:
                if "T" in source:
                    try:
                        source_time = datetime.fromisoformat(source)
                        if (now - source_time).days < 30:
                            is_recent = True
                            break
                    except:
                        pass
            
            if is_recent:
                self.overlays['recent'].add(node_id)
            
            # Check if trusted (high-quality sources)
            trusted_sources = ["nature", "science", "ieee", "acm"]
            if any(trusted in str(node.sources).lower() for trusted in trusted_sources):
                self.overlays['trusted'].add(node_id)
        
        # Find contested nodes (multiple conflicting edges)
        for node_id, node in self.mesh.nodes.items():
            edge_types = [edge.relation for edge in node.edges]
            if EdgeType.CONTRADICTS in edge_types and EdgeType.SUPPORTS in edge_types:
                self.overlays['contested'].add(node_id)
    
    def get_node_status(self, node_id: str) -> Dict[str, bool]:
        """Get overlay status for a specific node"""
        return {
            'scarred': node_id in self.overlays['scarred'],
            'deprecated': node_id in self.overlays['deprecated'],
            'trusted': node_id in self.overlays['trusted'],
            'recent': node_id in self.overlays['recent'],
            'contested': node_id in self.overlays['contested']
        }
    
    def filter_paths_by_overlay(self, paths: List[ReasoningPath], 
                               exclude: List[str] = None,
                               require: List[str] = None) -> List[ReasoningPath]:
        """Filter paths based on overlay criteria"""
        exclude = exclude or []
        require = require or []
        
        filtered = []
        for path in paths:
            # Check exclusions
            excluded = False
            for node in path.chain:
                node_status = self.get_node_status(node.id)
                if any(node_status.get(ex, False) for ex in exclude):
                    excluded = True
                    break
            
            if excluded:
                continue
            
            # Check requirements
            if require:
                has_required = True
                for node in path.chain:
                    node_status = self.get_node_status(node.id)
                    if not any(node_status.get(req, False) for req in require):
                        has_required = False
                        break
                
                if not has_required:
                    continue
            
            filtered.append(path)
        
        return filtered
    
    def visualize_overlay(self, output_path: str = "mesh_overlay.json"):
        """Export overlay data for visualization"""
        overlay_data = {
            "nodes": {},
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
        for node_id in self.mesh.nodes:
            status = self.get_node_status(node_id)
            if any(status.values()):  # Only include nodes with some status
                overlay_data["nodes"][node_id] = {
                    "status": status,
                    "color": self._get_node_color(status)
                }
        
        with open(output_path, 'w') as f:
            json.dump(overlay_data, f, indent=2)
        
        return overlay_data
    
    def _get_node_color(self, status: Dict[str, bool]) -> str:
        """Get visualization color based on status"""
        if status['deprecated']:
            return "#FF0000"  # Red
        elif status['scarred']:
            return "#FFA500"  # Orange
        elif status['contested']:
            return "#FFFF00"  # Yellow
        elif status['trusted'] and status['recent']:
            return "#00FF00"  # Green
        elif status['trusted']:
            return "#0000FF"  # Blue
        elif status['recent']:
            return "#00FFFF"  # Cyan
        else:
            return "#808080"  # Gray

# ========== Integration Example ==========

def demonstrate_intent_driven_reasoning():
    """Demonstrate intent-driven reasoning with conflict resolution"""
    from python.core.reasoning_traversal import ConceptNode, EdgeType
    
    print("🧠 Intent-Driven Reasoning Demo")
    print("=" * 60)
    
    # Create mesh with conflicting paths
    mesh = TemporalConceptMesh()
    
    # Add nodes
    ai = ConceptNode("ai", "Artificial Intelligence", 
                    "Systems that exhibit intelligent behavior",
                    ["textbook_2024", "recent_paper_2024-12-01T10:00:00Z"])
    
    beneficial = ConceptNode("beneficial", "Beneficial AI",
                           "AI that helps humanity",
                           ["ethics_paper_2024-11-15T10:00:00Z"])
    
    risky = ConceptNode("risky", "AI Risks",
                       "Potential dangers from AI",
                       ["safety_paper_2024-10-01T10:00:00Z"])
    
    regulation = ConceptNode("regulation", "AI Regulation",
                           "Legal frameworks for AI",
                           ["policy_doc_2024-12-15T10:00:00Z"])
    
    # Add to mesh
    for node in [ai, beneficial, risky, regulation]:
        mesh.add_node(node)
    
    # Add conflicting edges
    mesh.add_temporal_edge("ai", "beneficial", EdgeType.ENABLES,
                          justification="AI can be designed to help humanity")
    mesh.add_temporal_edge("ai", "risky", EdgeType.CAUSES,
                          justification="AI development poses risks")
    mesh.add_temporal_edge("beneficial", "regulation", EdgeType.PREVENTS,
                          justification="beneficial AI might not need heavy regulation")
    mesh.add_temporal_edge("risky", "regulation", EdgeType.CAUSES,
                          justification="AI risks necessitate regulation")
    
    # Initialize components
    intent_parser = ReasoningIntentParser()
    resolution_engine = CognitiveResolutionEngine(mesh)
    reflective_reasoner = SelfReflectiveReasoner(resolution_engine, intent_parser)
    overlay_manager = MeshOverlayManager(mesh)
    
    # Update overlays
    overlay_manager.update_overlays()
    
    # Test different queries with different intents
    test_queries = [
        {
            "query": "Why should we regulate AI?",
            "expected_intent": ReasoningIntent.JUSTIFY
        },
        {
            "query": "What causes the need for AI regulation?",
            "expected_intent": ReasoningIntent.CAUSAL
        },
        {
            "query": "Compare the arguments for and against AI regulation",
            "expected_intent": ReasoningIntent.COMPARE
        }
    ]
    
    for test in test_queries:
        print(f"\n{'='*60}")
        print(f"Query: {test['query']}")
        print("-" * 60)
        
        # Parse intent
        intent, strategy = intent_parser.parse_intent(test['query'])
        print(f"Intent: {intent.value}, Strategy: {strategy.value}")
        
        # Get paths
        paths = mesh.traverse_temporal("ai", max_depth=3)
        
        # Filter based on overlay (exclude deprecated, prefer recent)
        filtered_paths = overlay_manager.filter_paths_by_overlay(
            paths,
            exclude=['deprecated'],
            require=['recent']
        )
        
        print(f"Found {len(filtered_paths)} valid paths")
        
        # Resolve conflicts
        resolution = resolution_engine.resolve_conflicts(
            filtered_paths,
            intent=intent,
            strategy=strategy
        )
        
        print(f"\nResolution Report:")
        print(f"  Winner: {' → '.join([n.name for n in resolution.winning_path.chain]) if resolution.winning_path else 'None'}")
        print(f"  Confidence gap: {resolution.confidence_gap:.3f}")
        print(f"  Conflicts found: {len(resolution.conflicts)}")
        print(f"  Explanation: {resolution.explanation}")
        
        # Self-reflection
        if test['query'] == "Why should we regulate AI?":
            print("\n🤔 Self-Reflection:")
            reflection = reflective_reasoner.explain_reasoning_decision(
                test['query'],
                "AI should be regulated because...",
                resolution
            )
            print(reflection)
    
    # Show overlay visualization
    print(f"\n📊 Mesh Overlay Status:")
    overlay_data = overlay_manager.visualize_overlay()
    for node_id, data in overlay_data["nodes"].items():
        print(f"  {node_id}: {data['status']}")
    
    # Show reasoning history
    print(f"\n📜 Reasoning History:")
    history = reflective_reasoner.get_reasoning_history(last_n=3)
    for entry in history:
        print(f"  - {entry['query'][:50]}... (intent: {entry['intent']}, gap: {entry['confidence_gap']:.3f})")

if __name__ == "__main__":
    demonstrate_intent_driven_reasoning()
