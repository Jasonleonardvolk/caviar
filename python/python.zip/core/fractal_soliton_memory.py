"""
FractalSolitonMemory with Penrose integration
Unified wave-based memory lattice with O(n^2.32) similarity operations
"""
import numpy as np
import asyncio
import json
import time
import logging
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path
import pickle
import gzip

logger = logging.getLogger(__name__)

@dataclass
class SolitonWave:
    """Single soliton wave packet"""
    id: str
    position: np.ndarray  # Lattice position
    amplitude: float
    wavelength: float
    momentum: np.ndarray
    memory_content: Any
    embedding: Optional[np.ndarray] = None
    creation_time: float = 0.0
    coherence: float = 1.0

class FractalSolitonMemory:
    """Fractal soliton memory system with Penrose acceleration"""
    
    _instance = None
    
    @classmethod
    def get_instance(cls, config: Dict[str, Any] = None):
        if cls._instance is None:
            cls._instance = cls(config or {})
        return cls._instance
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.lattice_size = config.get('lattice_size', 100)
        self.coupling_strength = config.get('coupling_strength', 0.1)
        self.enable_penrose = config.get('enable_penrose', True)
        
        # Initialize lattice
        self.waves: Dict[str, SolitonWave] = {}
        self.lattice_field = np.zeros((self.lattice_size, self.lattice_size), dtype=np.complex128)
        
        # Penrose adapter
        self.penrose = None
        if self.enable_penrose:
            self._init_penrose()
        
        # Vault bridge
        self.vault_bridge = None
        
        # Persistence
        self.data_file = Path("fractal_soliton_memory.pkl.gz")
        self._load_state()
        
        logger.info(f"✅ FractalSolitonMemory initialized (lattice={self.lattice_size}x{self.lattice_size})")
    
    def _init_penrose(self):
        """Initialize Penrose adapter"""
        try:
            from python.core.penrose_adapter import PenroseAdapter
            self.penrose = PenroseAdapter.get_instance()
            logger.info("✅ Penrose acceleration enabled for soliton interactions")
        except ImportError:
            logger.warning("⚠️ Penrose not available, using standard operations")
    
    def set_vault_bridge(self, vault):
        """Bridge with UnifiedMemoryVault"""
        self.vault_bridge = vault
        logger.info("✅ Connected to UnifiedMemoryVault")
    
    def create_soliton(self, memory_id: str, content: Any, embedding: Optional[np.ndarray] = None) -> SolitonWave:
        """Create new soliton wave"""
        # Generate position on lattice
        position = np.random.rand(2) * self.lattice_size
        
        # Wave properties from content hash
        content_hash = hash(str(content))
        wavelength = 10.0 + (content_hash % 20)
        amplitude = 0.5 + 0.5 * np.random.rand()
        
        # Initial momentum
        momentum = np.random.randn(2) * 0.1
        
        wave = SolitonWave(
            id=memory_id,
            position=position,
            amplitude=amplitude,
            wavelength=wavelength,
            momentum=momentum,
            memory_content=content,
            embedding=embedding,
            creation_time=time.time()
        )
        
        self.waves[memory_id] = wave
        
        # Update lattice field
        self._update_lattice_field()
        
        # Sync with vault if connected
        if self.vault_bridge:
            self.vault_bridge.store_memory(
                memory_type="soliton",
                content=content,
                metadata={"soliton_id": memory_id, "wavelength": wavelength}
            )
        
        return wave
    
    def _update_lattice_field(self):
        """Update the quantum field on the lattice"""
        self.lattice_field.fill(0)
        
        for wave in self.waves.values():
            # Create wave packet on lattice
            x, y = wave.position
            for i in range(self.lattice_size):
                for j in range(self.lattice_size):
                    dx = i - x
                    dy = j - y
                    r = np.sqrt(dx**2 + dy**2)
                    
                    # Soliton wave function
                    phase = 2 * np.pi * r / wave.wavelength
                    envelope = wave.amplitude * np.exp(-r**2 / (2 * wave.wavelength**2))
                    
                    self.lattice_field[i, j] += envelope * np.exp(1j * phase)
    
    def find_resonant_memories(self, query_embedding: np.ndarray, k: int = 5) -> List[Tuple[str, float]]:
        """Find memories that resonate with query using Penrose acceleration"""
        if not self.waves:
            return []
        
        # Collect embeddings
        wave_ids = []
        embeddings = []
        
        for wave_id, wave in self.waves.items():
            if wave.embedding is not None:
                wave_ids.append(wave_id)
                embeddings.append(wave.embedding)
        
        if not embeddings:
            return []
        
        embeddings_matrix = np.array(embeddings)
        
        # Use Penrose for similarity if available
        if self.penrose:
            # Add query to matrix for batch computation
            full_matrix = np.vstack([query_embedding, embeddings_matrix])
            similarity_matrix = self.penrose.similarity_matrix(full_matrix)
            
            # Extract query similarities (first row, skip self)
            similarities = similarity_matrix[0, 1:]
        else:
            # Fallback to standard cosine similarity
            query_norm = query_embedding / (np.linalg.norm(query_embedding) + 1e-8)
            embeddings_norm = embeddings_matrix / (np.linalg.norm(embeddings_matrix, axis=1, keepdims=True) + 1e-8)
            similarities = embeddings_norm @ query_norm
        
        # Apply wave coherence weighting
        weighted_scores = []
        for i, (wave_id, sim) in enumerate(zip(wave_ids, similarities)):
            wave = self.waves[wave_id]
            # Weight by coherence and recency
            age_factor = np.exp(-0.1 * (time.time() - wave.creation_time) / 3600)  # Decay over hours
            score = sim * wave.coherence * age_factor
            weighted_scores.append((wave_id, float(score)))
        
        # Sort and return top k
        weighted_scores.sort(key=lambda x: x[1], reverse=True)
        return weighted_scores[:k]
    
    async def evolve_lattice(self, dt: float = 0.1):
        """Evolve the soliton lattice dynamics"""
        # Update wave positions
        for wave in self.waves.values():
            # Nonlinear dynamics
            wave.position += wave.momentum * dt
            
            # Boundary conditions (periodic)
            wave.position[0] = wave.position[0] % self.lattice_size
            wave.position[1] = wave.position[1] % self.lattice_size
            
            # Coherence decay
            wave.coherence *= 0.999
            
            # Interaction forces from field gradient
            x, y = int(wave.position[0]), int(wave.position[1])
            if 0 < x < self.lattice_size-1 and 0 < y < self.lattice_size-1:
                # Compute field gradient
                fx = np.real(self.lattice_field[x+1, y] - self.lattice_field[x-1, y])
                fy = np.real(self.lattice_field[x, y+1] - self.lattice_field[x, y-1])
                
                # Update momentum
                wave.momentum += self.coupling_strength * np.array([fx, fy]) * dt
                
                # Damping
                wave.momentum *= 0.99
        
        # Update field
        self._update_lattice_field()
    
    def get_lattice_snapshot(self) -> Dict[str, Any]:
        """Get current state snapshot"""
        return {
            "num_waves": len(self.waves),
            "field_energy": float(np.sum(np.abs(self.lattice_field)**2)),
            "waves": {
                wave_id: {
                    "position": wave.position.tolist(),
                    "amplitude": wave.amplitude,
                    "coherence": wave.coherence
                }
                for wave_id, wave in self.waves.items()
            }
        }
    
    def _save_state(self):
        """Save memory state to disk"""
        try:
            state = {
                "waves": self.waves,
                "config": self.config,
                "timestamp": time.time()
            }
            
            with gzip.open(self.data_file, 'wb') as f:
                pickle.dump(state, f)
                
        except Exception as e:
            logger.error(f"Failed to save soliton memory: {e}")
    
    def _load_state(self):
        """Load memory state from disk"""
        try:
            if self.data_file.exists():
                with gzip.open(self.data_file, 'rb') as f:
                    state = pickle.load(f)
                    self.waves = state.get("waves", {})
                    logger.info(f"Loaded {len(self.waves)} soliton waves")
                    
                    # Rebuild lattice field
                    self._update_lattice_field()
        except Exception as e:
            logger.error(f"Failed to load soliton memory: {e}")
    
    def shutdown(self):
        """Clean shutdown"""
        self._save_state()
        logger.info("FractalSolitonMemory shutdown complete")
