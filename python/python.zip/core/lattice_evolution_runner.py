#!/usr/bin/env python3
"""
Async background task that ticks the global OscillatorLattice every Δt.
"""
import asyncio
import time
import logging
from python.core.oscillator_lattice import get_global_lattice

logger = logging.getLogger(__name__)

DT = 0.05        # 50 ms step
LOG_PERIOD = 5   # seconds


async def run_forever() -> None:
    """Run the oscillator lattice evolution loop forever."""
    lattice = get_global_lattice()
    last_log = time.time()
    
    logger.info("Starting oscillator lattice evolution runner")
    
    while True:
        # Step the lattice dynamics
        lattice.step(DT)
        
        # Periodic logging
        now = time.time()
        if now - last_log >= LOG_PERIOD:
            R = lattice.order_parameter()
            H = lattice.phase_entropy()
            N = len(lattice.oscillators)
            
            logger.info(f"[lattice] oscillators={N} R={R:.3f} H={H:.3f}")
            print(f"[lattice] oscillators={N} R={R:.3f} H={H:.3f}")
            
            last_log = now
        
        await asyncio.sleep(DT)


if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Run the evolution loop
    asyncio.run(run_forever())
